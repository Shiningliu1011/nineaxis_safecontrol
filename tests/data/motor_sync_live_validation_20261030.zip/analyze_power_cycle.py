from hashlib import sha256
import json
from pathlib import Path

import numpy as np

from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
reports = {}
sources = {}
fixed_names = (
    "node_id", "serial_number_l", "hw_version", "fw_version", "auto_reply", "can_timeout_ms",
    "traj_mode", "gear_ratio", "cpr", "pole_pairs", "output_vel_limit_rpm", "circular_min_deg",
    "circular_max_deg", "circular_limit_enabled", "multi_circle_enabled", "zero_offset_counts",
)
errors = ("axis_error", "can_error", "motor_error", "encoder_error", "controller_error")
for phase in ("before", "after"):
    content = (folder / f"{phase}-power-cycle.json").read_bytes()
    source = json.loads(content)
    replay = replay_readonly_report(content)
    if source["status"] != "readonly_completed" or replay["status"] != "replayed_completed":
        raise ValueError(f"{phase} 原始读取回放未完成")
    if source["motion_commands_sent"] or source["parameter_writes_sent"]:
        raise ValueError("断电核验包含运动或参数写入")
    for name, digest in source["configuration_sha256"].items():
        if sha256((root / "config" / name).read_bytes()).hexdigest() != digest:
            raise ValueError("本地坐标配置与原始记录不一致")
    joints = {}
    for joint in DEFAULT_JOINT_NAMES:
        props = source["properties"][joint]
        if props["axis_state"] != 8 or any(props[name] for name in errors):
            raise ValueError(f"{joint} {phase} 设备存在故障或状态异常")
        rows = [row for row in source["samples"][9:] if row["joint"] == joint]
        if any(not row["traj_done"] or row["axis_error"] for row in rows):
            raise ValueError(f"{joint} {phase} 快速反馈状态异常")
        divisor = 72 if joint == "J1" else 1
        positions = np.array([row["state"]["angle_deg"] / divisor for row in rows])
        duration = rows[-1]["received_s"] - rows[0]["received_s"]
        if duration < 5:
            raise ValueError(f"{joint} 观察时间不足五秒")
        joints[joint] = {
            "median_position": float(np.median(positions)), "unit": "mm" if joint == "J1" else "deg",
            "minimum_position": float(np.min(positions)), "maximum_position": float(np.max(positions)),
            "position_span": float(np.ptp(positions)), "observed_duration_s": duration,
            "feedback_count": len(rows), "properties": props,
        }
    reports[phase] = {"source_sha256": sha256(content).hexdigest(), "joints": joints,
                      "replay_status": replay["status"], "feedback_count": len(source["samples"])}
    sources[phase] = source
if sources["before"]["configuration_sha256"] != sources["after"]["configuration_sha256"]:
    raise ValueError("断电前后配置身份不同")
changes = {}
for joint in DEFAULT_JOINT_NAMES:
    before = reports["before"]["joints"][joint]
    after = reports["after"]["joints"][joint]
    if any(before["properties"][name] != after["properties"][name] for name in fixed_names):
        raise ValueError(f"{joint} 断电前后身份、零位或固定配置变化")
    changes[joint] = {
        "median_coordinate_change": after["median_position"] - before["median_position"],
        "unit": after["unit"],
        "runtime_parameter_changes": {
            name: {"before": before["properties"][name], "after": after["properties"][name]}
            for name in ("trap_velocity_rpm", "trap_acceleration_rpm_s", "trap_deceleration_rpm_s")
            if before["properties"][name] != after["properties"][name]
        },
        "encoder_turn_abs": {phase: reports[phase]["joints"][joint]["properties"]["encoder_turn_abs"]
                             for phase in reports},
        "battery_voltage": {phase: reports[phase]["joints"][joint]["properties"]["battery_voltage"]
                            for phase in reports},
    }
operator = json.loads((folder / "power-cycle-operator.json").read_bytes())
result = {
    "evidence_kind": "single_supported_nonzero_power_cycle_with_raw_feedback_replay",
    "status": "reviewed", "reports": reports, "changes": changes, "operator": operator,
    "fixed_device_configuration_unchanged": True, "nineaxis_faults_zero": True,
    "local_configuration_sha256": sources["after"]["configuration_sha256"],
    "motion_commands_sent": 0, "parameter_writes_sent": 0,
    "device_sample_time_known": False, "independent_physical_precision_verified": False,
    "thirty_day_retention_verified": False, "hardware_qualified": False,
    "execution_blocker": "power_cycle_restored_saved_trapezoid_parameters_requires_startup_review",
}
with (folder / "power-cycle.analysis.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps({"changes": changes, "after_positions": {
    joint: {key: value for key, value in row.items() if key != "properties"}
    for joint, row in reports["after"]["joints"].items()}, "status": result["status"]},
    ensure_ascii=False, indent=2, allow_nan=False))

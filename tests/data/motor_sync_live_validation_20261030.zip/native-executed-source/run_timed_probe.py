import argparse
from dataclasses import asdict, dataclass
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import time
from zoneinfo import ZoneInfo

import numpy as np
from robot_static_fcl import Body

from robot_safecontrol_moveit.attended_positioning import AttendedPositioning
from robot_safecontrol_moveit.drempower_serial import DrEmpowerSerial
from robot_safecontrol_moveit.joint_positioning import positioning_limits, single_target_table
from robot_safecontrol_moveit.joint_table_execution import JointTableControl, JointTableExecutor
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import (
    ArrivalWindow, MotionRejected, SingleJointMonitor, VendorFeedbackReader, VelocityWindow, stationary_conditions,
)
from work.kinematics_data import JOINT_CHAIN
from work.nineaxis_kinematics import NineaxisKinematics
from work.nineaxis_model import NineaxisModel
from work.robot_units import joints_mm_deg_to_si
from work.static_collision import distance_between
from work.static_collision_meshes import load_meshes, mesh_sources


@dataclass(frozen=True)
class ProbeHardware:
    vendor: DrEmpowerSerial
    executor: JointTableExecutor


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
parser = argparse.ArgumentParser()
parser.add_argument("--kind", choices=("hold", "forward", "return"), required=True)
parser.add_argument("--check-only", action="store_true")
args = parser.parse_args()
values = [1.5, 0., 0., 0., 0., 0., .3, .4, .5] if args.kind == "forward" else [1., *([0.] * 8)]
model = NineaxisModel.load(root=root)
table = single_target_table(dict(zip(DEFAULT_JOINT_NAMES, values)), model)
control = JointTableControl(root)
port = "/dev/serial/by-id/usb-Dr-Tech_DR-USB_CAN_87949380174B-if00"
session = AttendedPositioning.load(
    root, root / ".scratch/motor_control/attended-positioning.json", table, model, port=port,
    limits=positioning_limits(root, dict(zip(DEFAULT_JOINT_NAMES, [.05, *([.3] * 8)])),
                              dict(zip(DEFAULT_JOINT_NAMES, [.01, *([.3] * 8)]))))
executor = JointTableExecutor(table, model, measurement_kind="positioning", task_id="issue-186-timed-probe",
                              feedback_source="hardware_feedback", limits=session.limits, manual_positioning=True)
lower = joints_mm_deg_to_si([.8, *([-.15] * 8)])
upper = joints_mm_deg_to_si([1.7, *([.15] * 5), .65, .75, .85])
center, radius = (lower + upper) / 2, (upper - lower) / 2
sources = mesh_sources(root / "portable_oscbf/config/collision_geometry_sources.json")
meshes = load_meshes(sources)
transforms = NineaxisKinematics().forward_kinematics(center)
bodies = []
for mesh in meshes:
    body = Body.convex(mesh.vertices, mesh.faces)
    transform = transforms[mesh.link]
    body.set_transform(transform[:3, :3], transform[:3, 3])
    bodies.append(body)
offsets = np.array([np.linalg.norm(row[3:6]) for row in JOINT_CHAIN if row[2] in ("prismatic", "revolute")])
distances = []
for first, second in sources["pairs"]:
    coefficients = np.zeros(9)
    coefficients[0] = 1
    for joint in range(1, second):
        coefficients[joint] = np.sum(offsets[joint + 1:second]) + meshes[second].radius_m
    coefficients[:first] = 0
    distance = distance_between(bodies[first], bodies[second])
    margin = distance.distance_m - float(coefficients @ radius) - .01
    if not distance.valid or margin <= 0:
        raise ValueError(f"共同时间实验的完整自身几何范围未证明：{first}/{second}")
    distances.append({"pair": [meshes[first].link, meshes[second].link], "interval_margin_m": margin})
targets = {index + 1: control.position_arguments(joint, control.target_deg(joint, table.rows[0].q_si[index]),
                                                session.limits[joint])["angle"]
           for index, joint in enumerate(DEFAULT_JOINT_NAMES)}
capture = {"status": "prepared", "started_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
           "scope": "attended_small_timed_preset_broadcast_characterisation", "kind": args.kind,
           "target_mm_deg": values, "target_device_deg": targets, "duration_s": 30., "accel_rpm_s": .05,
           "model_hash": model.model_hash, "table_sha256": table.source_sha256, "policy": session.report(),
           "self_collision_sources": sources, "whole_box_self_collision": distances,
           "lower_si": lower.tolist(), "upper_si": upper.tolist(), "external_scene_checked": False,
           "device_sample_time_known": False, "hardware_qualified": False,
           "physical_stop_independently_verified": False, "parameter_writes_sent": 0,
           "user_instruction": "#184，继续用实机验证，仿真发现不了问题",
           "source_sha256": sha256(Path(__file__).read_bytes()).hexdigest()}
print(json.dumps({"kind": args.kind, "targets_mm_deg": values,
                  "minimum_self_interval_margin_mm": min(row["interval_margin_m"] for row in distances) * 1000},
                 ensure_ascii=False), flush=True)
if args.check_only:
    raise SystemExit(0)
log_path = folder / f"timed-{args.kind}.jsonl"
capture_path = folder / f"timed-{args.kind}.capture.json"
if log_path.exists() or capture_path.exists():
    raise FileExistsError("共同时间实验的输出已经存在")
windows = {joint: VelocityWindow(1., 5.) for joint in DEFAULT_JOINT_NAMES}
monitors = {joint: SingleJointMonitor(index + 1, session.limits[joint]) for index, joint in enumerate(DEFAULT_JOINT_NAMES)}
with log_path.open("x", encoding="utf-8") as log:
    def record(event, **fields):
        log.write(json.dumps({"event": event, "monotonic_s": time.monotonic(), **fields},
                             ensure_ascii=False, allow_nan=False) + "\n")
        log.flush()

    with DrEmpowerSerial(port, position_nodes={1: "prismatic", **{node: "revolute" for node in range(2, 10)}},
                        timed_probe=True) as vendor:
        reader = VendorFeedbackReader(vendor, control, .2)

        def observe():
            session.check_stop()
            observed = {}
            positions = []
            for joint in DEFAULT_JOINT_NAMES:
                reader.require_closed_loop(joint)
                sample = windows[joint].add(reader.read(joint))
                if sample.window_duration_s < 1:
                    monitors[joint].validate_hold_feedback(sample, time.monotonic())
                else:
                    monitors[joint].validate_feedback(sample, time.monotonic())
                observed[joint] = sample
                positions.append(control.project_position(joint, sample.state.angle_deg))
            q = joints_mm_deg_to_si(positions)
            if np.any(q < lower) or np.any(q > upper):
                raise MotionRejected("outside_complete_probe_self_interval")
            if max(time.monotonic() - sample.request_s for sample in observed.values()) > .2:
                raise MotionRejected("nineaxis_feedback_timeout")
            record("feedback", samples={joint: asdict(sample) for joint, sample in observed.items()})
            return observed

        attempted = False
        try:
            for node in range(1, 10):
                vendor.prepare_motion(node)
            capture["device_properties"] = session.verify_device(ProbeHardware(vendor, executor))
            until = time.monotonic() + 11
            while True:
                observed = observe()
                if all(all(stationary_conditions(sample, session.limits[joint]).values())
                       for joint, sample in observed.items()):
                    break
                if time.monotonic() > until:
                    raise MotionRejected("initial_nineaxis_not_stationary")
                time.sleep(.02)
            capture["initial_feedback"] = {joint: asdict(sample) for joint, sample in observed.items()}
            record("timed_probe_requested", targets_device_deg=targets, duration_s=30., accel_rpm_s=.05)
            attempted = True
            capture["broadcast"] = vendor.set_timed_probe(targets, duration_s=30., accel_rpm_s=.05)
            record("broadcast_write_returned", **capture["broadcast"])
            start = capture["broadcast"]["broadcast_write_finished_s"]
            arrivals = {joint: ArrivalWindow(control.target_deg(joint, table.rows[0].q_si[index]), session.limits[joint])
                        for index, joint in enumerate(DEFAULT_JOINT_NAMES)}
            while True:
                observed = observe()
                stable = {joint: arrivals[joint].observe(sample, time.monotonic()) for joint, sample in observed.items()}
                elapsed = time.monotonic() - start
                if elapsed >= 6 and all(stable.values()):
                    capture.update(status="completed", completed_after_broadcast_s=elapsed,
                                   final_feedback={joint: asdict(sample) for joint, sample in observed.items()})
                    record("completed", elapsed_s=elapsed)
                    print(f"共同时间 {args.kind} 实验完成；九轴到位并保持静止。", flush=True)
                    break
                if elapsed > 55:
                    raise MotionRejected("timed_probe_arrival_timeout")
                time.sleep(.02)
        except BaseException as error:
            capture.update(status="aborted", reason=str(error))
            if attempted:
                try:
                    current = observe()
                    stopping = {joint: ArrivalWindow(sample.state.angle_deg, session.limits[joint])
                                for joint, sample in current.items()}
                    for joint, sample in current.items():
                        limit = session.limits[joint]
                        arguments = control.position_arguments(joint, sample.state.angle_deg, limit)
                        record("hold_requested", joint=joint, arguments=arguments)
                        vendor.set_angle(**arguments)
                    until = time.monotonic() + 20
                    while True:
                        stopped = observe()
                        stable = {joint: stopping[joint].observe(sample, time.monotonic())
                                  for joint, sample in stopped.items()}
                        if all(stable.values()):
                            capture["stop_result"] = "hold_observed"
                            break
                        if time.monotonic() > until:
                            raise MotionRejected("timed_probe_hold_not_confirmed")
                        time.sleep(.02)
                except BaseException as stop_error:
                    capture.update(stop_result="external_stop_required", stop_error=str(stop_error))
                    print("无法确认停止，请立即操作现场急停。", flush=True)
            session.stop_latch.trip(reason=str(error), log_path=log_path)
            record("aborted", reason=str(error), stop_result=capture.get("stop_result", "no_motion_attempted"))
            raise
        finally:
            capture["frames"] = vendor.frames
            capture["log_sha256"] = sha256(log_path.read_bytes()).hexdigest()
            with capture_path.open("x", encoding="utf-8") as stream:
                json.dump(capture, stream, ensure_ascii=False, indent=2, allow_nan=False)
                stream.write("\n")

from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
paths = [folder / "run_timed_probe.py", *[
    root / "src/robot_safecontrol_moveit" / name for name in ("drempower_serial.py", "drempower_can.py")]]
manifest = {"evidence_kind": "executed_tracking_probe_source_snapshot", "files": []}
with ZipFile(folder / "tracking-executed-source.zip", "x", compression=ZIP_DEFLATED) as archive:
    for path in paths:
        data = path.read_bytes()
        member = path.name if path.parent == folder else str(path.relative_to(root))
        manifest["files"].append({"member": member, "bytes": len(data), "sha256": sha256(data).hexdigest()})
        archive.writestr(member, data)
    archive.writestr("provenance.json", json.dumps(manifest, indent=2))
print(json.dumps(manifest, indent=2))

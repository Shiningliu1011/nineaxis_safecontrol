from dataclasses import asdict, replace
from hashlib import sha256
import json
from pathlib import Path

import numpy as np

from robot_safecontrol_moveit.drempower_joint_control import JointFeedback
from robot_safecontrol_moveit.joint_positioning import positioning_limits
from robot_safecontrol_moveit.joint_table_commissioning import stationary_noise
from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.motor_motion_limits import MotionBounds
from robot_safecontrol_moveit.motor_stop_latch import MotorStopLatch
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import (
    ObservedFeedback, SingleJointMonitor, VelocityWindow, stationary_conditions,
)


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
source_bytes = (folder / "current-preflight.json").read_bytes()
source = json.loads(source_bytes)
replay = replay_readonly_report(source_bytes)
if source["status"] != "readonly_completed" or replay["status"] != "replayed_completed":
    raise ValueError("当前完整设备读取未完成")
policy_path = root / ".scratch/motor_control/attended-positioning.json"
policy_bytes = policy_path.read_bytes()
policy = json.loads(policy_bytes)
for name, digest in source["configuration_sha256"].items():
    if sha256((root / "config" / name).read_bytes()).hexdigest() != digest or policy["config_hashes"][name] != digest:
        raise ValueError(f"坐标配置变化：{name}")
if sha256((root / ".scratch/motor_control/stop.json").read_bytes()).hexdigest() != policy["reviewed_stop_sha256"]:
    raise ValueError("主停止记录变化")
for joint in DEFAULT_JOINT_NAMES:
    values = source["properties"][joint]
    if values["axis_state"] != 8 or any(values[name] for name in (
            "axis_error", "can_error", "motor_error", "encoder_error", "controller_error")):
        raise ValueError(f"{joint} 设备状态无效")
if (source["properties"]["J1"]["zero_offset_counts"] != policy["expected_j1_zero_offset_counts"]
        or source["properties"]["J1"]["serial_number_l"] != policy["expected_j1_serial_number_l"]):
    raise ValueError("J1 身份或零位改变")
noise = stationary_noise(root, root / policy["noise_evidence_path"],
                         policy["noise_evidence_sha256"], policy["model_hash"])
limits = positioning_limits(root, dict(zip(DEFAULT_JOINT_NAMES, [.05, *([2.46] * 8)])),
                            dict(zip(DEFAULT_JOINT_NAMES, [.01, *([.3] * 8)])))
for joint, limit in limits.items():
    bounds = (None if joint == "J1" else
              MotionBounds(limit.speed_rpm, limit.accel_rpm_s, 5 / 6, sha256(policy_bytes).hexdigest()))
    limits[joint] = replace(limit, stationary_window_s=5., stationary_velocity_noise_rpm=noise[joint],
                            bounds=bounds, max_feedback_rpm=limit.max_feedback_rpm if bounds is None else 5 / 6)
windows = {joint: VelocityWindow(1., 5.) for joint in DEFAULT_JOINT_NAMES}
monitors = {joint: SingleJointMonitor(index + 1, limits[joint]) for index, joint in enumerate(DEFAULT_JOINT_NAMES)}
latest = {}
for row in source["samples"][9:]:
    joint = row["joint"]
    sample = ObservedFeedback(**{key: value for key, value in row.items() if key not in ("joint", "state")},
                              state=JointFeedback(**row["state"]))
    observed = windows[joint].add(sample)
    if observed.window_duration_s < 1:
        monitors[joint].validate_hold_feedback(observed, observed.received_s)
    else:
        monitors[joint].validate_feedback(observed, observed.received_s)
    latest[joint] = observed
if set(latest) != set(DEFAULT_JOINT_NAMES) or not all(
        all(stationary_conditions(latest[joint], limits[joint]).values()) for joint in DEFAULT_JOINT_NAMES):
    raise ValueError("九轴真实静止条件未成立")
interval = json.loads((root / ".scratch/issue-184-experiments/j1-probe-self-interval.json").read_bytes())
for index, joint in enumerate(DEFAULT_JOINT_NAMES[1:], start=1):
    if abs(latest[joint].state.angle_deg - np.rad2deg(interval["reference_si"][index])) > .01:
        raise ValueError(f"{joint} 当前姿态超出已有完整自身几何范围")
stop_path = root / ".scratch/motor_control/attended-positioning-stop.json"
stop_bytes = stop_path.read_bytes()
stop = json.loads(stop_bytes)
if stop["reason"] != "bounded_J1_encoder_experiment_completed":
    raise ValueError("待审查停止原因变化")
review = {"scope": "attended_bounded_J1_0_to_1mm_probe", "reviewed_stop": stop,
          "reviewed_stop_sha256": sha256(stop_bytes).hexdigest(),
          "source_sha256": sha256(source_bytes).hexdigest(),
          "policy_sha256": sha256(policy_bytes).hexdigest(),
          "user_instruction": "#184，继续用实机验证，仿真发现不了问题",
          "feedback": {joint: asdict(sample) for joint, sample in latest.items()},
          "motion_commands_sent": 0, "hardware_qualified": False,
          "physical_stop_independently_verified": False}
with (folder / "recovery-review.json").open("x", encoding="utf-8") as stream:
    json.dump(review, stream, ensure_ascii=False, indent=2, allow_nan=False)
MotorStopLatch(stop_path).acknowledge_stop(expected_sha256=sha256(stop_bytes).hexdigest(),
                                         archive_path=folder / "previous-attended-stop.json")
print(json.dumps({"nineaxis_stationary": True, "previous_completion_reviewed": True,
                  "positions_deg": {joint: sample.state.angle_deg for joint, sample in latest.items()}},
                 ensure_ascii=False))

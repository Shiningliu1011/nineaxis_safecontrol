from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
output = root / "tests/data/motor_sync_live_validation_20261030.zip"
paths = [folder / name for name in (
    "run_timed_probe.py", "analyze_timed_probe.py", "analyze_power_cycle.py", "prepare_power_cycle.py",
    "prepare_probe.py", "archive_live_validation.py", "archive_executed_tracking_source.py",
    "current-preflight.json", "recovery-review.json", "previous-attended-stop.json", "operator-readings.json",
    "j1-outward-1mm.jsonl", "j1-outward-1mm.frames.json", "j1-outward-1mm.capture.json",
    "before-power-cycle.json", "after-power-cycle.json", "power-cycle-prepared.json",
    "power-cycle-operator.json", "power-cycle.analysis.json", "final-regression.xml", "post-review-regression.xml",
)]
for prefix in ("timed", "tracking"):
    for kind in ("hold", "forward", "return"):
        paths += [folder / f"{prefix}-{kind}{suffix}" for suffix in (".jsonl", ".capture.json", ".replay.json")]
paths += [root / "config" / name for name in ("drempower.yaml", "hardware_joint_zero.yaml", "j1_transmission.yaml")]
paths += [root / "src/robot_safecontrol_moveit" / name for name in ("drempower_serial.py", "drempower_can.py")]
paths += [root / "tests" / name for name in ("test_drempower_can.py", "test_joint_table_execution.py")]
paths += [root / ".scratch/motor_control" / name for name in (
    "attended-positioning.json", "attended-positioning-stop.json")]
members = {}
for path in paths:
    member = path.name if path.parent == folder else str(path.relative_to(root))
    members[member] = path.read_bytes()
source_archives = (
    (root / "tests/data/motor_sync_timed_experiments_20261030.zip", "native-executed-source"),
    (folder / "tracking-executed-source.zip", "tracking-executed-source"),
)
parents = []
for path, prefix in source_archives:
    with ZipFile(path) as archive:
        manifest = json.loads(archive.read("provenance.json"))
        for entry in manifest["files"]:
            data = archive.read(entry["member"])
            if len(data) != entry["bytes"] or sha256(data).hexdigest() != entry["sha256"]:
                raise ValueError("已执行源码归档的成员校验失败")
        for member in ("run_timed_probe.py", "src/robot_safecontrol_moveit/drempower_serial.py",
                       "src/robot_safecontrol_moveit/drempower_can.py"):
            members[f"{prefix}/{member}"] = archive.read(member)
    parents.append({"name": path.name, "sha256": sha256(path.read_bytes()).hexdigest()})
for prefix, source_prefix in (("timed", "native-executed-source"), ("tracking", "tracking-executed-source")):
    digest = sha256(members[f"{source_prefix}/run_timed_probe.py"]).hexdigest()
    for kind in ("hold", "forward", "return"):
        if json.loads(members[f"{prefix}-{kind}.capture.json"])["source_sha256"] != digest:
            raise ValueError("实际实验与归档源码身份不一致")
provenance = {
    "evidence_kind": "real_attended_native_and_continuous_reference_and_supported_power_cycle",
    "hardware_qualified": False, "independent_physical_precision_verified": False,
    "device_sample_time_known": False, "thirty_day_retention_verified": False,
    "source_archives": parents,
    "source_scope": {
        "native-executed-source": "共同时间三组实验实际执行的源码",
        "tracking-executed-source": "连续参考三组实验实际执行的源码",
        "src/robot_safecontrol_moveit": "审阅后工作区源码，包含广播前再次检查反馈时效",
    },
    "files": [{"member": name, "bytes": len(data), "sha256": sha256(data).hexdigest()}
              for name, data in members.items()],
}
with ZipFile(output, "x", compression=ZIP_DEFLATED) as archive:
    for name, data in members.items():
        archive.writestr(name, data)
    archive.writestr("provenance.json", json.dumps(provenance, ensure_ascii=False, indent=2, allow_nan=False))
with ZipFile(output) as archive:
    if archive.testzip() is not None or len(set(archive.namelist())) != len(archive.namelist()):
        raise ValueError("完整实验归档完整性无效")
    for entry in provenance["files"]:
        content = archive.read(entry["member"])
        if len(content) != entry["bytes"] or sha256(content).hexdigest() != entry["sha256"]:
            raise ValueError("完整实验归档成员验证失败")
print(json.dumps({"archive": str(output), "sha256": sha256(output.read_bytes()).hexdigest(),
                  "members": len(members), "all_members_verified": True}, ensure_ascii=False, indent=2))

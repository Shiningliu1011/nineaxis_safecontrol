import argparse
from bisect import bisect_left
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path

from construct import Float32l, Int16sl, Struct, Terminated
import numpy as np

from robot_safecontrol_moveit.drempower_can import can_node_id, decode_feedback
from robot_safecontrol_moveit.drempower_serial import SERIAL_CAN_FRAME
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import ObservedFeedback, VelocityWindow


folder = Path(__file__).parent
parser = argparse.ArgumentParser()
parser.add_argument("--kind", choices=("hold", "forward", "return"), required=True)
parser.add_argument("--tracking", action="store_true")
parser.add_argument("--output", type=Path)
args = parser.parse_args()
prefix = "tracking" if args.tracking else "timed"
capture_path = folder / f"{prefix}-{args.kind}.capture.json"
capture = json.loads(capture_path.read_bytes())
log_path = folder / f"{prefix}-{args.kind}.jsonl"
log_bytes = log_path.read_bytes()
if sha256(log_bytes).hexdigest() != capture["log_sha256"] or capture["status"] != "completed":
    raise ValueError("共同时间实验未完成或日志身份变化")
events = [json.loads(line) for line in log_bytes.splitlines()]
observations = [row for row in events if row["event"] == "feedback"]
raw_feedback = {node: [] for node in range(1, 10)}
last_s = 0.
for row in capture["frames"]:
    if row["monotonic_s"] < last_s:
        raise ValueError("原始帧主机时间顺序无效")
    last_s = row["monotonic_s"]
    frame = SERIAL_CAN_FRAME.parse(bytes.fromhex(row["raw_hex"]))
    node, command = can_node_id(frame.frame_id)
    if row["direction"] == "rx" and command in (1, 3, 5, 7):
        raw_feedback[node].append((row["monotonic_s"], decode_feedback(frame.frame_id, frame.data)))
control = JointTableControl(folder.parents[1])
raw_times = {node: [stamp for stamp, _ in data] for node, data in raw_feedback.items()}
windows = {joint: VelocityWindow(1., 5.) for joint in DEFAULT_JOINT_NAMES}
matched = 0
for row in observations:
    if set(row["samples"]) != set(DEFAULT_JOINT_NAMES):
        raise ValueError("日志反馈缺少九轴")
    for joint, sample in row["samples"].items():
        node = control._node(joint)
        index = bisect_left(raw_times[node], sample["request_s"])
        if index >= len(raw_times[node]):
            raise ValueError("日志反馈没有对应原始回复")
        stamp, feedback = raw_feedback[node][index]
        decoded = control.decode_state(joint, feedback.pos_deg, feedback.vel_rpm)
        if (not sample["request_s"] <= stamp <= sample["received_s"] or sample["node_id"] != node
                or sample["state"] != {"angle_deg": decoded.angle_deg, "speed_rpm": decoded.speed_rpm}
                or sample["traj_done"] != feedback.traj_done or sample["axis_error"] != feedback.axis_error):
            raise ValueError(f"{joint} 日志位置、速度、状态或时间与原始回复不符")
        replayed = windows[joint].add(ObservedFeedback(
            node, decoded, sample["request_s"], sample["received_s"], feedback.traj_done, feedback.axis_error))
        if asdict(replayed) != sample:
            raise ValueError(f"{joint} 原始速度、位置及静止窗口复算与日志不符")
        matched += 1
start = capture["broadcast"]["broadcast_write_finished_s"]
rows = {}
for joint in DEFAULT_JOINT_NAMES:
    data = [row["samples"][joint] for row in observations]
    times = np.array([(row["request_s"] + row["received_s"]) / 2 - start for row in data])
    positions = np.array([row["state"]["angle_deg"] / (72 if joint == "J1" else 1) for row in data])
    before = positions[(times >= -4) & (times < 0)]
    after = positions[times >= times[-1] - 4]
    initial, final = float(np.median(before)), float(np.median(after))
    rows[joint] = {"initial": initial, "final": final, "before_span": float(np.ptp(before)),
                   "after_span": float(np.ptp(after)), "samples": len(data),
                   "unit": "mm" if joint == "J1" else "deg",
                   "target_error": final - capture["target_mm_deg"][DEFAULT_JOINT_NAMES.index(joint)]}
    rows[joint]["maximum_position_window_speed"] = max(
        abs(row["position_speed_rpm"]) * 6 / (72 if joint == "J1" else 1)
        for row in data if row["position_speed_rpm"] is not None)
    if args.kind != "hold" and joint in ("J1", "J7", "J8", "J9"):
        progress = (positions - initial) / (final - initial)
        rows[joint]["progress"] = np.interp(np.arange(0., 30.001, .05), times, progress)
        for threshold in (.1, .5, .9, .95):
            crossing = np.flatnonzero((times >= 0) & (progress >= threshold))
            rows[joint][f"t{round(threshold * 100)}_host_s"] = float(times[crossing[0]]) if len(crossing) else None
        rows[joint]["relative_baseline_span"] = rows[joint]["before_span"] / abs(final - initial)
report = {"kind": args.kind, "status": capture["status"], "broadcast": capture["broadcast"],
          "protocol_kind": prefix, "matched_original_feedback": matched,
          "completed_after_broadcast_s": capture["completed_after_broadcast_s"], "joints": rows,
          "device_sample_time_known": False, "hardware_qualified": False,
          "independent_physical_precision_verified": False,
          "progress_normalization": "observed_four_second_median_start_and_end",
          "host_grid_interval_s": .05, "source_sha256": sha256(capture_path.read_bytes()).hexdigest()}
if args.kind != "hold":
    active = ("J1", "J7", "J8", "J9")
    progress = np.stack([rows[joint].pop("progress") for joint in active])
    grid = np.arange(0., 30.001, .05)
    spread = np.ptp(progress, axis=0)
    index = int(np.argmax(spread))
    report["maximum_progress_spread"] = float(spread[index])
    report["maximum_spread_host_s"] = float(grid[index])
    report["progress_at_maximum_spread"] = dict(zip(active, progress[:, index].tolist()))
    report["progress_samples"] = [{"host_s": float(value), "normalized_progress": dict(zip(active, column.tolist()))}
                                  for value, column in zip(grid, progress.T)]
payload = Struct("angle" / Float32l, "duration_100" / Int16sl, "accel_100" / Int16sl, Terminated)
counts = {}
presets, broadcasts, replies = [], [], {}
pending_presets = []
latest_feedback_s = {}
broadcast_feedback_ages = []
batch_requests = [row for row in events if row["event"] in (
    "broadcast_write_returned", "tracking_broadcast", "restore_bandwidths")]
for row in capture["frames"]:
    frame = SERIAL_CAN_FRAME.parse(bytes.fromhex(row["raw_hex"]))
    node, command = can_node_id(frame.frame_id)
    if row["direction"] == "tx":
        counts[f"0x{command:02x}"] = counts.get(f"0x{command:02x}", 0) + 1
        if command == 0x0c:
            decoded = payload.parse(frame.data)
            entry = {"node": node, "angle": decoded.angle, "requested_s": row["monotonic_s"]}
            entry.update({"filter_bandwidth": decoded.accel_100 / 100} if args.tracking else {
                "duration_s": decoded.duration_100 / 100, "accel_rpm_s": decoded.accel_100 / 100})
            presets.append(entry)
            pending_presets.append((node, decoded))
        elif command == 0x08:
            expected = "1000000000000000" if args.tracking else "1100000000000000"
            if node != 0 or frame.data != bytes.fromhex(expected):
                raise ValueError("共同时间启动帧无效")
            if [item[0] for item in pending_presets] != list(range(1, 10)):
                raise ValueError("广播之前没有按顺序准备全部九轴预设")
            if len(broadcasts) >= len(batch_requests):
                raise ValueError("广播没有对应的原始命令记录")
            request = batch_requests[len(broadcasts)]
            for target_node, item in pending_presets:
                target = request["targets_device_deg"][str(target_node)]
                if item.angle != Float32l.parse(Float32l.build(target)):
                    raise ValueError("预设目标与完整九轴命令记录不符")
                if args.tracking:
                    if item.duration_100 != 0 or item.accel_100 != round(
                            request["bandwidths"][str(target_node)] * 100):
                        raise ValueError("连续参考预设的带宽或第二字段不符")
                elif item.duration_100 != 3000 or item.accel_100 != 5:
                    raise ValueError("共同时间的时间或加速度与实验声明不符")
            if set(latest_feedback_s) != set(range(1, 10)):
                raise ValueError("广播前没有取得全部九轴反馈")
            age = max(row["monotonic_s"] - value for value in latest_feedback_s.values())
            if age > .2:
                raise ValueError("广播前九轴原始反馈超过 200 ms")
            broadcast_feedback_ages.append(age)
            pending_presets.clear()
            broadcasts.append(row["monotonic_s"])
        elif command not in (0x1a, 0x1e):
            raise ValueError("原始记录包含实验范围外的写入命令")
    else:
        replies[str(node)] = replies.get(str(node), 0) + 1
        if command in (1, 3, 5, 7):
            latest_feedback_s[node] = row["monotonic_s"]
if ((not args.tracking and (len(presets) != 9 or len(broadcasts) != 1))
        or (args.tracking and (len(presets) != 9 * len(broadcasts) or len(broadcasts) < 20))
        or counts.get("0x1f", 0) != 0):
    raise ValueError("原始实验命令数量或参数写入不符")
if pending_presets or len(broadcasts) != len(batch_requests):
    raise ValueError("原始预设批次或广播记录未完成")
report["maximum_broadcast_feedback_age_s"] = max(broadcast_feedback_ages)
if args.tracking:
    intervals = np.diff(broadcasts)
    if np.any(intervals < .04) or np.any(intervals > .2):
        raise ValueError("原始连续广播间隔超出 40–200 ms")
    report["broadcast_intervals_s"] = {
        "minimum": float(np.min(intervals)), "median": float(np.median(intervals)),
        "maximum": float(np.max(intervals)), "p99": float(np.percentile(intervals, 99)),
    }
    if capture["original_operating_properties"] != capture["restored_operating_properties"]:
        raise ValueError("原始输入模式或带宽没有恢复")
    if counts.get("0x1a", 0) != 9:
        raise ValueError("连续参考之后缺少九轴梯形终点保持")
report.update(tx_commands=counts, presets=presets, broadcasts=broadcasts, rx_by_node=replies)
with (args.output or folder / f"{prefix}-{args.kind}.analysis.json").open("x", encoding="utf-8") as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write("\n")
summary = {key: value for key, value in report.items() if key not in ("progress_samples", "presets", "broadcasts")}
print(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False))

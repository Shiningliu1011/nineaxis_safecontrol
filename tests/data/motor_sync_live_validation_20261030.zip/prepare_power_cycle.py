from hashlib import sha256
import json
from pathlib import Path

import numpy as np

from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.motor_stop_latch import MotorStopLatch
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
source_bytes = (folder / "before-power-cycle.json").read_bytes()
source = json.loads(source_bytes)
replay = replay_readonly_report(source_bytes)
if source["status"] != "readonly_completed" or replay["status"] != "replayed_completed":
    raise ValueError("断电前读取未完成")
for name, digest in source["configuration_sha256"].items():
    if sha256((root / "config" / name).read_bytes()).hexdigest() != digest:
        raise ValueError("断电前坐标配置发生变化")
spans = {}
for joint in DEFAULT_JOINT_NAMES:
    values = source["properties"][joint]
    if values["axis_state"] != 8 or any(values[name] != 0 for name in (
            "axis_error", "can_error", "motor_error", "encoder_error", "controller_error")):
        raise ValueError(f"{joint} 断电前状态无效")
    rows = [row for row in source["samples"][9:] if row["joint"] == joint]
    if any(not row["traj_done"] or row["axis_error"] for row in rows):
        raise ValueError(f"{joint} 断电前反馈状态无效")
    spans[joint] = float(np.ptp([row["state"]["angle_deg"] for row in rows]))
    if spans[joint] > .01 or rows[-1]["received_s"] - rows[0]["received_s"] < 5:
        raise ValueError(f"{joint} 断电前位置未持续稳定")
j1 = source["properties"]["J1"]
if abs(-j1["output_pos_deg"] / 72 - 1) > .001:
    raise ValueError("J1 未保持本次 1 mm 非零参考位置")
checkpoint = {"status": "awaiting_operator_power_cycle", "j1_target_mm": 1.,
              "j1_properties": j1, "stationary_spans_deg": spans,
              "source_sha256": sha256(source_bytes).hexdigest(), "device_sample_time_known": False,
              "actual_power_off_duration_s": None, "independent_physical_precision_verified": False,
              "hardware_qualified": False,
              "user_statement": "能够固定姿态并操作电源"}
latch = MotorStopLatch(root / ".scratch/motor_control/attended-positioning-stop.json")
latch.require_clear()
with (folder / "power-cycle-prepared.json").open("x", encoding="utf-8") as stream:
    json.dump(checkpoint, stream, ensure_ascii=False, indent=2, allow_nan=False)
latch.trip(reason="power_cycle_coordinate_verification_in_progress", log_path=folder / "before-power-cycle.json")
print(json.dumps({"j1_mm": -j1["output_pos_deg"] / 72, "turn_abs": j1["encoder_turn_abs"],
                  "zero_offset_counts": j1["zero_offset_counts"], "nineaxis_stationary": True,
                  "serial_connection_closed": True}, ensure_ascii=False))

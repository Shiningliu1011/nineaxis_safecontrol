import argparse
from dataclasses import asdict, replace
from hashlib import sha256
import json
from pathlib import Path
import time

from robot_safecontrol_moveit.drempower_can import (
    CMD_PROPERTY_WRITE, CMD_SYSTEM, SYSTEM_ORDER_SET_ZERO,
    encode_property_write, encode_system,
)
from robot_safecontrol_moveit.drempower_joint_control import JointFeedback
from robot_safecontrol_moveit.drempower_serial import DrEmpowerSerial
from robot_safecontrol_moveit.joint_positioning import positioning_limits
from robot_safecontrol_moveit.joint_table_commissioning import stationary_noise
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.joint_table_readonly import (
    ENCODER_PROPERTIES, SERVO_PROPERTIES, replay_readonly_report,
)
from robot_safecontrol_moveit.motor_motion_limits import MotionBounds
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import (
    ArrivalWindow, MotionRejected, ObservedFeedback, SingleJointMonitor,
    VendorFeedbackReader, VelocityWindow, stationary_conditions,
)
from work.nineaxis_model import NineaxisModel


FOLDER = Path(__file__).resolve().parent
ROOT = FOLDER.parents[1]
ERRORS = ("axis_error", "can_error", "motor_error", "encoder_error", "controller_error")
FIELDS = {**ENCODER_PROPERTIES, **SERVO_PROPERTIES}
IDENTITY = ("node_id", "serial_number_l", "hw_version", "fw_version", "gear_ratio", "cpr",
            "pole_pairs", "zero_offset_counts", "circular_min_deg", "circular_max_deg",
            "circular_limit_enabled", "auto_reply", "can_timeout_ms", "traj_mode",
            "pos_gain", "vel_gain", "vel_integrator_gain", "current_control_bandwidth")


def sources():
    plan_source = (FOLDER / "counter-experiment-plan.json").read_bytes()
    plan = json.loads(plan_source)
    capture_source = (FOLDER / "nineaxis-encoder-readonly.json").read_bytes()
    servo_source = (FOLDER / "nineaxis-servo-readonly.json").read_bytes()
    geometry_source = (FOLDER / "j1-40-geometry-review.json").read_bytes()
    policy_source = (ROOT / ".scratch/motor_control/attended-positioning.json").read_bytes()
    stop_source = (ROOT / ".scratch/motor_control/attended-positioning-stop.json").read_bytes()
    for content, key in ((capture_source, "encoder_readonly_sha256"), (servo_source, "servo_readonly_sha256"),
                         (geometry_source, "geometry_review_sha256"), (policy_source, "policy_sha256"),
                         (stop_source, "stop_sha256")):
        if sha256(content).hexdigest() != plan[key]:
            raise ValueError(f"实验来源变化：{key}")
    for name, digest in plan["configuration_sha256"].items():
        if sha256((ROOT / "config" / name).read_bytes()).hexdigest() != digest:
            raise ValueError("实验设备坐标配置变化")
    model = NineaxisModel.load(root=ROOT)
    geometry = json.loads(geometry_source)
    if (model.model_hash != plan["model_hash"] or geometry["model_hash"] != model.model_hash
            or len(geometry["whole_box_self_collision"]) != 36
            or any(item["interval_margin_m"] <= 0 for item in geometry["whole_box_self_collision"])
            or plan["targets_mm"] != [0, 40, 0]
            or plan["speed_rpm"] != 3 or plan["acceleration_rpm_s"] != .6):
        raise ValueError("实验目标或范围检查变化")
    for content in (capture_source, servo_source):
        if replay_readonly_report(content)["status"] != "replayed_completed":
            raise ValueError("实验原始采集不完整")
    capture, servo = json.loads(capture_source), json.loads(servo_source)
    expected = {joint: {**capture["properties"][joint], **servo["properties"][joint]}
                for joint in DEFAULT_JOINT_NAMES}
    return plan_source, plan, json.loads(policy_source), expected, capture


def experiment_limits(policy):
    base = positioning_limits(ROOT, dict(zip(DEFAULT_JOINT_NAMES, [.25, *([2.46] * 8)])),
                              dict(zip(DEFAULT_JOINT_NAMES, [.05, *([.3] * 8)])))
    noise = stationary_noise(ROOT, ROOT / policy["noise_evidence_path"],
                             policy["noise_evidence_sha256"], policy["model_hash"])
    result = {}
    for joint, limit in base.items():
        bounds = (None if joint == "J1" else MotionBounds(
            limit.speed_rpm, limit.accel_rpm_s, policy["maximum_feedback_deg_s"] / 6,
            sha256((ROOT / ".scratch/motor_control/attended-positioning.json").read_bytes()).hexdigest()))
        result[joint] = replace(
            limit, lower_deg=limit.lower_deg if joint == "J1" else -.1,
            upper_deg=40.1 * 72 if joint == "J1" else .1,
            max_step_deg=(limit.max_step_deg + limit.position_noise_deg) if joint == "J1" else limit.max_step_deg,
            stationary_window_s=5., stationary_velocity_noise_rpm=noise[joint],
            tolerance_deg=limit.tolerance_deg if joint == "J1" else .01, settle_s=5.,
            bounds=bounds, max_feedback_rpm=limit.max_feedback_rpm if bounds is None else bounds.feedback_rpm,
        )
    return result


class Observations:
    def __init__(self, limits):
        self.limits = limits
        self.windows = {joint: VelocityWindow(limit.velocity_window_s, limit.stationary_window_s)
                        for joint, limit in limits.items()}
        self.monitors = {joint: SingleJointMonitor(index + 1, limits[joint])
                         for index, joint in enumerate(DEFAULT_JOINT_NAMES)}
        self.latest = {}

    def add(self, joint, original, now):
        sample = self.windows[joint].add(original)
        monitor = self.monitors[joint]
        if sample.window_duration_s < self.limits[joint].velocity_window_s:
            monitor.validate_hold_feedback(sample, now)
        else:
            monitor.validate_feedback(sample, now)
        if joint != "J1" and (not sample.traj_done or abs(sample.state.angle_deg) > .1):
            raise MotionRejected(f"{joint} 保持状态变化")
        self.latest[joint] = sample
        return sample

    def stationary(self):
        return (set(self.latest) == set(DEFAULT_JOINT_NAMES)
                and all(sample.traj_done and all(stationary_conditions(sample, self.limits[joint]).values())
                        for joint, sample in self.latest.items()))


class Experiment:
    def __init__(self, vendor, report, stream, plan, expected, limits):
        self.vendor, self.report, self.stream = vendor, report, stream
        self.plan, self.expected, self.limits = plan, expected, limits
        self.control = JointTableControl(ROOT)
        self.reader = VendorFeedbackReader(vendor, self.control, .2)
        self.observations = Observations(limits)
        self.multi = 1
        self.mode = expected["J1"]["input_mode"]
        self.last_progress_s = 0.

    def record(self, event, **values):
        self.stream.write(json.dumps({"event": event, "monotonic_s": time.monotonic(), **values},
                                     ensure_ascii=False, allow_nan=False) + "\n")
        self.stream.flush()

    def read(self, joint, name):
        address, kind = FIELDS[name]
        start = time.monotonic()
        value = self.vendor.read_property(self.control._node(joint), address, kind)
        end = time.monotonic()
        self.record("property", joint=joint, name=name, address=address, kind=kind, value=value,
                    request_s=start, received_s=end)
        if end - start > .2:
            raise MotionRejected("属性读取超过 0.2 秒")
        return value

    def snapshot(self, label):
        values = {joint: {name: self.read(joint, name) for name in FIELDS} for joint in DEFAULT_JOINT_NAMES}
        self.report.setdefault("snapshots", {})[label] = values
        for joint, group in values.items():
            self.check_properties(joint, group)
            for name in IDENTITY:
                if group[name] != self.expected[joint][name]:
                    raise MotionRejected(f"{joint} 属性变化：{name}")
            expected_multi = self.multi if joint == "J1" else self.expected[joint]["multi_circle_enabled"]
            if group["multi_circle_enabled"] != expected_multi:
                raise MotionRejected(f"{joint} 多圈使能不符")
        return values

    def check_properties(self, joint, values):
        if values["axis_state"] != 8 or any(values[name] for name in ERRORS):
            raise MotionRejected(f"{joint} 状态或错误字段无效")
        if values["control_mode"] != 3:
            raise MotionRejected(f"{joint} 未处于位置控制")

    def poll(self, detailed=True):
        for joint in DEFAULT_JOINT_NAMES:
            sample = self.reader.read(joint)
            self.record("feedback", joint=joint, sample=asdict(sample))
            self.observations.add(joint, sample, time.monotonic())
        if detailed:
            # 每轮读取九轴状态；故障标志同时由每条快速反馈核验。
            for joint in DEFAULT_JOINT_NAMES:
                if self.read(joint, "axis_state") != 8:
                    raise MotionRejected(f"{joint} 离开闭环状态")
            names = ("multi_circle_enabled", "zero_offset_counts", "circular_limit_enabled",
                     "circular_min_deg", "circular_max_deg", "control_mode", "input_mode",
                     "encoder_turn_abs", "encoder_pos_abs", "rotor_pos_turns",
                     "output_input_pos_deg", "output_pos_setpoint_deg", "output_pos_deg",
                     "output_input_vel_rpm", "output_vel_setpoint_rpm",
                     "output_torque_setpoint_nm", "output_torque_estimate_nm",
                     "output_vel_rpm", "axis_error", "encoder_error")
            values = {name: self.read("J1", name) for name in names}
            if (values["multi_circle_enabled"] != self.multi or values["control_mode"] != 3
                    or values["input_mode"] != self.mode or values["axis_error"] or values["encoder_error"]):
                raise MotionRejected("J1 计数配置、模式或错误字段变化")
            for name in ("zero_offset_counts", "circular_limit_enabled", "circular_min_deg", "circular_max_deg"):
                if values[name] != self.expected["J1"][name]:
                    raise MotionRejected(f"J1 配置变化：{name}")
            self.report["latest_j1_properties"] = values
        now = time.monotonic()
        if any(now - row.request_s > .2 for row in self.observations.latest.values()):
            raise MotionRejected("九轴反馈超过 0.2 秒")
        if now - self.last_progress_s >= 10:
            position = self.observations.latest["J1"].state.angle_deg / 72
            print(f"{self.report['phase']}：J1 {position:.6f} mm，多圈使能 {self.multi}", flush=True)
            self.last_progress_s = now

    def wait_stationary_zero(self, target_mm=0.):
        until = time.monotonic() + 12
        while time.monotonic() < until:
            self.poll()
            if abs(self.observations.latest["J1"].state.angle_deg - target_mm * 72) > .072:
                raise MotionRejected("J1 当前反馈不在本次起点核验范围内")
            if self.observations.stationary():
                return
            time.sleep(.02)
        raise MotionRejected("九轴零位静止核验未完成")

    def move(self, target_mm, label):
        if target_mm not in (0, 40):
            raise ValueError("本次实验仅允许 0 mm 与 40 mm")
        self.report["phase"] = label
        self.poll()
        if not self.observations.stationary():
            raise MotionRejected("发送位置命令前九轴未确认静止")
        initial = self.observations.latest["J1"]
        delta = target_mm * 72 - initial.state.angle_deg
        limit = self.limits["J1"].for_motion(delta) if delta else self.limits["J1"]
        monitor = SingleJointMonitor(1, limit)
        monitor.start_absolute(initial, target_mm * 72, time.monotonic())
        angle = self.control.encoder_targets([target_mm / 1000, *([0.] * 8)])[1]
        self.record("position_command_requested", target_mm=target_mm, device_angle_deg=angle,
                    speed_rpm=3., accel_rpm_s=.6)
        self.report["writes_attempted"] += 1
        self.vendor.set_angle(1, angle, 3., .6, 1)
        self.mode = 5
        while True:
            time.sleep(.02)
            self.poll()
            if monitor.observe(self.observations.latest["J1"], time.monotonic()):
                self.record("position_completed", target_mm=target_mm)
                return

    def write_multi(self, value):
        self.poll()
        if (value not in (0, 1) or value == self.multi or not self.observations.stationary()
                or abs(self.observations.latest["J1"].state.angle_deg) > .072):
            raise MotionRejected("多圈切换需要已确认的静止零位")
        self.record("multi_circle_write_requested", value=value)
        self.report["writes_attempted"] += 1
        self.vendor._write_frame(1, CMD_PROPERTY_WRITE, encode_property_write(1, 31207, value, "u32"))
        if self.read("J1", "multi_circle_enabled") != value:
            raise MotionRejected("J1 多圈使能写入未采用")
        self.multi = value
        # 切换后的连续保持需要独立覆盖完整五秒。
        self.observations = Observations(self.limits)
        self.wait_stationary_zero()


def offline_check(plan, policy, capture):
    limits = experiment_limits(policy)
    observations = Observations(limits)
    for row in capture["samples"][9:]:
        sample = ObservedFeedback(row["node_id"], JointFeedback(**row["state"]), row["request_s"],
                                  row["received_s"], row["traj_done"], row["axis_error"])
        observations.add(row["joint"], sample, row["received_s"])
    if not observations.stationary():
        raise ValueError("原始六秒反馈没有通过实验的九轴静止检查")
    control = JointTableControl(ROOT)
    if control.encoder_targets([.04, *([0.] * 8)])[1] != -2880:
        raise ValueError("J1 设备目标换算不符")
    print(json.dumps({"status": "offline_checks_passed", "raw_feedback_samples": len(capture["samples"]) - 9,
                      "minimum_self_margin_mm": plan["minimum_self_margin_mm"],
                      "motion_commands_sent": 0, "parameter_writes_sent": 0}, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("check", "trial", "repeat", "return", "restore"), default="check")
    parser.add_argument("--operator", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    plan_source, plan, policy, expected, capture = sources()
    if args.phase == "check":
        offline_check(plan, policy, capture)
        return
    if args.operator is None or args.output is None:
        parser.error("实机实验需要本次现场授权记录与独立输出文件")
    authorization_source = args.operator.read_bytes()
    authorization = json.loads(authorization_source)
    if (authorization["plan_sha256"] != sha256(plan_source).hexdigest()
            or authorization["source_sha256"] != sha256(Path(__file__).read_bytes()).hexdigest()
            or authorization["parameter_and_motion_authorized"] is not True
            or not authorization["user_statement"].strip()
            or not 0 <= time.time() - authorization["recorded_unix_s"] <= 1800):
        raise ValueError("本次实验授权、程序身份或时间不符")
    if args.phase == "restore" and authorization.get("mechanical_zero_confirmed") is not True:
        raise ValueError("恢复多圈前需要操作者确认实际机械零位")
    report = {"scope": "j1_counter_experiment", "status": "started", "phase": args.phase,
              "experiment_phase": args.phase, "writes_attempted": 0,
              "plan_sha256": sha256(plan_source).hexdigest(), "authorization": authorization,
              "source_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
              "physical_stop_independently_verified": False, "full_stroke_verified": False}
    capture_path = args.output.with_suffix(".capture.json")
    limits = experiment_limits(policy)
    # 原有停止记录保持存在；本次授权仅用于此实验及其原始原因审查。
    with capture_path.open("x", encoding="utf-8") as raw_stream, args.output.open("x", encoding="utf-8") as stream:
        try:
            with DrEmpowerSerial(policy["port"], command_node=1, axis_type="prismatic") as vendor:
                experiment = Experiment(vendor, report, stream, plan, expected, limits)
                try:
                    if args.phase in ("repeat", "return", "restore"):
                        experiment.multi = 0
                        experiment.mode = 5
                    experiment.snapshot("before")
                    vendor.prepare_motion()
                    experiment.wait_stationary_zero(40. if args.phase == "return" else 0.)
                    if args.phase in ("trial", "repeat"):
                        experiment.move(0, "holding_zero")
                        if args.phase == "trial":
                            report["phase"] = "disabling_multi_circle"
                            experiment.write_multi(0)
                        experiment.move(40, "moving_to_40_mm")
                        experiment.move(0, "returning_to_zero")
                        experiment.wait_stationary_zero()
                        report["status"] = "awaiting_mechanical_zero_confirmation"
                    elif args.phase == "return":
                        experiment.move(0, "returning_to_zero")
                        experiment.wait_stationary_zero()
                        report["status"] = "awaiting_mechanical_zero_confirmation"
                    else:
                        report["phase"] = "restoring_multi_circle"
                        experiment.write_multi(1)
                        experiment.record("set_zero_requested", mechanical_zero_source="operator_statement")
                        report["writes_attempted"] += 1
                        vendor._write_frame(1, CMD_SYSTEM, encode_system(1, SYSTEM_ORDER_SET_ZERO))
                        new_zero = experiment.read("J1", "zero_offset_counts")
                        expected["J1"]["zero_offset_counts"] = new_zero
                        experiment.observations = Observations(limits)
                        experiment.wait_stationary_zero()
                        report["new_zero_offset_counts"] = new_zero
                        report["status"] = "multi_circle_restored_at_confirmed_zero"
                    experiment.snapshot("after")
                finally:
                    report["frames"] = vendor.frames
        except BaseException as error:
            report.update(status="aborted", reason=str(error),
                          stop_result="external_stop_required" if report["writes_attempted"] else "no_write_attempted")
            if report["writes_attempted"]:
                print(f"实验中止：{error}。无法确认停止，请立即操作现场急停。", flush=True)
            else:
                print(f"实验检查未通过：{error}；没有发送参数写入或运动命令。", flush=True)
            raise
        finally:
            json.dump(report, raw_stream, ensure_ascii=False, indent=2, allow_nan=False)
            raw_stream.write("\n")
    print(json.dumps({"status": report["status"], "capture": str(capture_path)}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()

from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report


folder = Path(__file__).resolve().parent
root = folder.parents[1]
contents = {}
for name in (
    "counter-experiment-plan.json", "j1-40-geometry-review.json", "prepare_counter_experiment.py",
    "counter-experiment-authorization.json", "counter-repeat-authorization.json",
    "counter-return-authorization.json", "counter-restore-authorization.json",
    "operator-statement.json", "manufacturer-availability.json",
    "counter-trial-01-source.zip", "counter-trial-02-source.zip",
    "counter-trial-01-monitor-review.json", "replay_counter_trial_checks.py",
    "run_counter_experiment.py", "restore_counter_zero.py", "verify_counter_experiment.py",
    "verify_counter_recovery.py", "counter-zero-recovery-01.capture.json", "counter-recovery-verified.json",
    "final-nineaxis-confirmed.json", "after-counter-trial-readonly.json",
    "after-counter-trial-02-servo.json", "after-counter-restore-j1.json",
    "nineaxis-encoder-readonly.json", "nineaxis-servo-readonly.json", "create_counter_archive.py",
):
    contents[name] = (folder / name).read_bytes()
trials = {}
for stem in ("counter-trial-01", "counter-trial-02", "counter-return-01", "counter-restore-01"):
    for suffix in (".jsonl", ".capture.json", "-verified.json"):
        contents[stem + suffix] = (folder / (stem + suffix)).read_bytes()
    capture = json.loads(contents[stem + ".capture.json"])
    verified = json.loads(contents[stem + "-verified.json"])
    if (verified["capture_sha256"] != sha256(contents[stem + ".capture.json"]).hexdigest()
            or verified["log_sha256"] != sha256(contents[stem + ".jsonl"]).hexdigest()):
        raise ValueError("实验核验结果与原始采集不符")
    if stem.startswith("counter-trial"):
        with ZipFile(folder / (stem + "-source.zip")) as archive:
            source = archive.read("run_counter_experiment.py")
    else:
        source = contents["run_counter_experiment.py"]
    if sha256(source).hexdigest() != capture["source_sha256"]:
        raise ValueError("实验归档源码与实际执行源码不符")
    trials[stem] = {key: verified[key] for key in (
        "source_status", "readonly_replay_status", "verified_write_commands",
        "property_reads", "matched_property_events", "feedback_samples", "incomplete_reads", "joints")}
readonly = {}
for name in ("final-nineaxis-confirmed.json", "after-counter-trial-readonly.json",
             "after-counter-trial-02-servo.json", "after-counter-restore-j1.json",
             "nineaxis-encoder-readonly.json", "nineaxis-servo-readonly.json"):
    replay = replay_readonly_report(contents[name])
    if replay["status"] != "replayed_completed":
        raise ValueError("独立只读记录不完整")
    readonly[name] = {"property_reads": len(replay["property_observations"]),
                      "feedback_samples": len(replay["feedback_observations"]), "device_fields": replay["nodes"]}
with ZipFile(root / "tests/data/motor_zero_reset_20261030.zip") as archive:
    contents["before/attended-positioning.json"] = archive.read("attended-positioning.json")
    contents["before/attended-positioning-stop.json"] = archive.read("attended-positioning-stop.json")
for name in ("attended-positioning.json", "attended-positioning-stop.json"):
    contents["after/" + name] = (root / ".scratch/motor_control" / name).read_bytes()
plan = json.loads(contents["counter-experiment-plan.json"])
if (sha256(contents["before/attended-positioning.json"]).hexdigest() != plan["policy_sha256"]
        or contents["before/attended-positioning-stop.json"] != contents["after/attended-positioning-stop.json"]):
    raise ValueError("初始策略或停止记录不符")
for name in plan["configuration_sha256"]:
    source = (root / "config" / name).read_bytes()
    if sha256(source).hexdigest() != plan["configuration_sha256"][name]:
        raise ValueError("设备坐标配置变化")
    contents["config/" + name] = source
for name in ("drempower_can.py", "drempower_serial.py", "joint_table_readonly.py",
             "joint_table_execution.py", "joint_positioning.py", "joint_table_commissioning.py",
             "single_joint_execution.py", "motor_motion_limits.py", "drempower_joint_control.py",
             "robot_spec.py", "unit_conversion.py"):
    contents["production-source/" + name] = (root / "src/robot_safecontrol_moveit" / name).read_bytes()
recovery = json.loads(contents["counter-recovery-verified.json"])
if (recovery["recovery_sha256"] != sha256(contents["counter-zero-recovery-01.capture.json"]).hexdigest()
        or recovery["final_capture_sha256"] != sha256(contents["final-nineaxis-confirmed.json"]).hexdigest()
        or recovery["policy_sha256"] != sha256(contents["after/attended-positioning.json"]).hexdigest()):
    raise ValueError("恢复核验与归档内容不符")
manifest = {
    "scope": "bounded_j1_multi_circle_experiment_and_zero_recovery",
    "trials": trials, "independent_readonly": readonly,
    "final_status": recovery["status"], "final_j1_zero_offset_counts": 11045,
    "single_uninterrupted_roundtrip_verified": False, "full_stroke_verified": False,
    "independent_physical_precision_verified": False, "physical_stop_independently_verified": False,
    "power_cycle_position_retention_verified": False, "motion_restart_qualified": False,
    "source_commit": "738b1f0b1917f299001a99b6182f94f0c6a5a231",
    "initial_zero_archive_sha256": sha256((root / "tests/data/motor_zero_reset_20261030.zip").read_bytes()).hexdigest(),
    "original_first_trial_evidence_limit": "首次记录在回程开始约 0.5 秒时中止，随后独立读取确认零位。",
    "original_second_trial_evidence_limit": "第二次记录在起步时因 joint_limit 中止，随后独立读取确认 40 mm。",
    "return_evidence": "counter-return-01 完整记录从 40 mm 返回 0 mm 并持续保持。",
    "restore_evidence": "恢复多圈后出现编码器错误 512；机械零位处设置零点、清错、恢复闭环后取得健康反馈。",
}
contents["experiment-verification.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()
provenance = [{"member": name, "bytes": len(value), "sha256": sha256(value).hexdigest()}
              for name, value in contents.items()]
output = root / "tests/data/j1_multi_circle_experiment_20261030.zip"
with ZipFile(output, "x", compression=ZIP_DEFLATED) as archive:
    for name, value in contents.items():
        archive.writestr(name, value)
    archive.writestr("provenance.json", json.dumps(provenance, ensure_ascii=False, indent=2))
with ZipFile(output) as archive:
    for item in json.loads(archive.read("provenance.json")):
        source = archive.read(item["member"])
        if len(source) != item["bytes"] or sha256(source).hexdigest() != item["sha256"]:
            raise ValueError("归档成员校验失败")
print(json.dumps({"archive": str(output), "members": len(contents), "bytes": output.stat().st_size,
                  "sha256": sha256(output.read_bytes()).hexdigest(), "final_status": manifest["final_status"]},
                 ensure_ascii=False, indent=2))

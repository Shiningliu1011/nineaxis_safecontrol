from dataclasses import replace
from hashlib import sha256
import json
from pathlib import Path

from robot_safecontrol_moveit.drempower_joint_control import JointFeedback
from robot_safecontrol_moveit.single_joint_execution import MotionRejected, ObservedFeedback, SingleJointMonitor
from run_counter_experiment import Observations, experiment_limits, sources


folder = Path(__file__).resolve().parent
_, _, policy, _, _ = sources()
capture_source = (folder / "counter-trial-01.capture.json").read_bytes()
log_source = (folder / "counter-trial-01.jsonl").read_bytes()
verified = json.loads((folder / "counter-trial-01-verified.json").read_bytes())
if (verified["capture_sha256"] != sha256(capture_source).hexdigest()
        or verified["log_sha256"] != sha256(log_source).hexdigest()):
    raise ValueError("已逐帧核对的实机记录发生变化")
events = [json.loads(line) for line in log_source.decode().splitlines()]
results = {}
for name, recorded_tolerance in (("recorded_experiment", .72), ("positioning_requirement", 72.)):
    limits = experiment_limits(policy)
    if limits["J1"].upper_deg != 40.1 * 72 or limits["J1"].lower_deg != -.01:
        raise ValueError("本次已检查的反馈范围变化")
    limits["J1"] = replace(limits["J1"], tolerance_deg=recorded_tolerance)
    observations = Observations(limits)
    motion = None
    result = {"tolerance_mm": recorded_tolerance / 72, "completed_targets_mm": [],
              "feedback_checked": 0, "reason": None}
    for event in events:
        try:
            if event["event"] == "feedback":
                row, joint = event["sample"], event["joint"]
                sample = ObservedFeedback(row["node_id"], JointFeedback(**row["state"]), row["request_s"],
                                          row["received_s"], row["traj_done"], row["axis_error"])
                observed = observations.add(joint, sample, event["monotonic_s"])
                result["feedback_checked"] += 1
                if joint == "J1" and motion is not None:
                    if motion.phase == "completed":
                        motion.validate_feedback(observed, event["monotonic_s"])
                    else:
                        motion.observe(observed, event["monotonic_s"])
            elif event["event"] == "position_command_requested":
                target_deg = event["target_mm"] * 72
                sample = observations.latest["J1"]
                delta = target_deg - sample.state.angle_deg
                limit = limits["J1"].for_motion(delta) if delta else limits["J1"]
                motion = SingleJointMonitor(1, limit)
                motion.start_absolute(sample, target_deg, event["monotonic_s"])
                result["current_target_mm"] = event["target_mm"]
                result["current_start_mm"] = sample.state.angle_deg / 72
            elif event["event"] == "position_completed":
                if motion is None or motion.phase != "completed":
                    raise ValueError("日志到位声明没有原始反馈支持")
                result["completed_targets_mm"].append(event["target_mm"])
                motion = None
        except MotionRejected as error:
            result.update(reason=str(error), rejected_position_mm=observations.latest["J1"].state.angle_deg / 72,
                          event_time_s=event["monotonic_s"])
            break
    results[name] = result
if results["recorded_experiment"]["reason"] != "motion_outside_requested_interval":
    raise ValueError("未复现实机实验的原始检查中止")
if (results["positioning_requirement"]["reason"] is not None
        or results["positioning_requirement"]["feedback_checked"] != verified["feedback_samples"]
        or results["positioning_requirement"]["completed_targets_mm"] != [0, 40]):
    raise ValueError("既定定位要求的真实反馈回归未通过")
results["evidence_limit"] = "记录在回程开始约 0.5 秒时结束；回放不证明完整回程完成"
with (folder / "counter-trial-01-monitor-review.json").open("x", encoding="utf-8") as stream:
    json.dump(results, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps(results, ensure_ascii=False, indent=2))

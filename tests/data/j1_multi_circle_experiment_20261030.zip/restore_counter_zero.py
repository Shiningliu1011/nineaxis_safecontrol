from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path
import time

from robot_safecontrol_moveit.drempower_can import (
    CMD_PROPERTY_WRITE, CMD_SYSTEM, SYSTEM_ORDER_SET_ZERO,
    can_node_id, enable_sequence, encode_system,
)
from robot_safecontrol_moveit.drempower_serial import DrEmpowerSerial
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.joint_table_readonly import ENCODER_PROPERTIES, SERVO_PROPERTIES
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import VendorFeedbackReader
from run_counter_experiment import Observations, experiment_limits, sources


folder = Path(__file__).resolve().parent
root = folder.parents[1]
plan_source, plan, policy, expected, _ = sources()
return_source = (folder / "counter-return-01.capture.json").read_bytes()
return_verified = json.loads((folder / "counter-return-01-verified.json").read_bytes())
return_capture = json.loads(return_source)
if (return_capture["status"] != "awaiting_mechanical_zero_confirmation"
        or return_verified["capture_sha256"] != sha256(return_source).hexdigest()
        or abs(return_verified["joints"]["J1"]["last"]) > .001):
    raise ValueError("缺少完整返回原机械零位的原始证据")
authorization = json.loads((folder / "counter-restore-authorization.json").read_bytes())
if not authorization["parameter_and_motion_authorized"] or not authorization["mechanical_zero_confirmed"]:
    raise ValueError("缺少本次实验恢复授权及机械零位确认")
output = folder / "counter-zero-recovery-01.capture.json"
report = {"scope": "restore_multi_circle_at_confirmed_mechanical_zero", "status": "started",
          "operator_statements": [authorization["user_statement"], authorization["mechanical_zero_statement"]],
          "return_capture_sha256": sha256(return_source).hexdigest(),
          "source_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
          "full_stroke_verified": False, "physical_stop_independently_verified": False,
          "property_observations": [], "samples": [], "commands": []}
fields = {**ENCODER_PROPERTIES, **SERVO_PROPERTIES}
control = JointTableControl(root)


def read(vendor, joint, name):
    address, kind = fields[name]
    start = time.monotonic()
    value = vendor.read_property(control._node(joint), address, kind)
    report["property_observations"].append({"joint": joint, "name": name, "value": value,
                                            "request_s": start, "received_s": time.monotonic()})
    return value


def command(vendor, node, cmd, payload, name):
    report["commands"].append({"name": name, "node_id": node, "command": cmd,
                               "payload_hex": payload.hex(), "requested_s": time.monotonic()})
    vendor._write_frame(node, cmd, payload)
    # 当前步骤为静止设备的参数恢复，给设备处理系统命令后再开始独立读取。
    time.sleep(.2)


with output.open("x", encoding="utf-8") as stream:
    try:
        with DrEmpowerSerial(policy["port"], command_node=1, axis_type="prismatic") as vendor:
            try:
                before = {joint: {name: read(vendor, joint, name) for name in fields}
                          for joint in DEFAULT_JOINT_NAMES}
                report["before"] = before
                errors = ("axis_error", "can_error", "motor_error", "encoder_error", "controller_error")
                for joint in DEFAULT_JOINT_NAMES:
                    group = before[joint]
                    for name in ("node_id", "hw_version", "fw_version", "gear_ratio", "cpr", "pole_pairs",
                                 "zero_offset_counts", "circular_min_deg", "circular_max_deg",
                                 "circular_limit_enabled", "multi_circle_enabled"):
                        if group[name] != expected[joint][name]:
                            raise ValueError(f"{joint} 恢复前设备配置变化：{name}")
                    if joint != "J1" and (group["axis_state"] != 8 or any(group[name] for name in errors)):
                        raise ValueError(f"{joint} 恢复前状态异常")
                j1 = before["J1"]
                if (j1["axis_state"] != 1 or j1["axis_error"] != 256 or j1["encoder_error"] != 512
                        or any(j1[name] for name in ("can_error", "motor_error", "controller_error"))
                        or j1["encoder_turn_abs"] != -2047
                        or abs(j1["output_input_pos_deg"]) > .001
                        or abs(j1["output_pos_setpoint_deg"]) > .001
                        or abs(j1["output_pos_deg"]) > .72
                        or j1["output_input_vel_rpm"] != 0 or j1["control_mode"] != 3 or j1["input_mode"] != 5):
                    raise ValueError("J1 恢复前故障、目标或原机械零位状态不符")
                command(vendor, 1, CMD_SYSTEM, encode_system(1, SYSTEM_ORDER_SET_ZERO), "set_zero")
                report["after_zero"] = {name: read(vendor, "J1", name) for name in (
                    "zero_offset_counts", "encoder_turn_abs", "encoder_error", "axis_error", "axis_state",
                    "output_pos_deg", "output_input_pos_deg", "output_pos_setpoint_deg", "multi_circle_enabled")}
                zero = report["after_zero"]
                if (zero["encoder_turn_abs"] not in (0, 1) or zero["multi_circle_enabled"] != 1
                        or not 0 <= zero["zero_offset_counts"] < 16384 or abs(zero["output_pos_deg"]) > .072
                        or abs(zero["output_input_pos_deg"]) > .001 or abs(zero["output_pos_setpoint_deg"]) > .001):
                    raise ValueError("设置零点后计数、实际位置或内部目标不符")
                clear, enable = enable_sequence(1)
                node, cmd = can_node_id(clear[0])
                command(vendor, node, cmd, clear[1], "clear_error")
                cleared = {name: read(vendor, "J1", name) for name in (*errors, "axis_state")}
                report["after_clear"] = cleared
                if any(cleared[name] for name in errors):
                    raise ValueError("重新设置零点并清错后仍存在故障")
                if cleared["axis_state"] == 1:
                    if abs(read(vendor, "J1", "output_input_pos_deg")) > .001:
                        raise ValueError("恢复闭环前目标不在零位")
                    node, cmd = can_node_id(enable[0])
                    if cmd != CMD_PROPERTY_WRITE:
                        raise ValueError("闭环恢复序列无效")
                    command(vendor, node, cmd, enable[1], "enable_zero_hold")
                elif cleared["axis_state"] != 8:
                    raise ValueError("清错后的设备状态无效")
                observations = Observations(experiment_limits(policy))
                reader = VendorFeedbackReader(vendor, control, .2)
                until = time.monotonic() + 6
                while time.monotonic() < until:
                    for joint in DEFAULT_JOINT_NAMES:
                        sample = reader.read(joint)
                        report["samples"].append({"joint": joint, **asdict(sample)})
                        observations.add(joint, sample, time.monotonic())
                        if joint == "J1" and abs(sample.state.angle_deg) > .072:
                            raise ValueError("恢复后的 J1 位置变化超过零位核验范围")
                    time.sleep(.02)
                if not observations.stationary():
                    raise ValueError("恢复后的九轴静止核验未通过")
                report["after"] = {joint: {name: read(vendor, joint, name) for name in (
                    "axis_state", *errors, "zero_offset_counts", "encoder_turn_abs", "multi_circle_enabled",
                    "circular_limit_enabled", "circular_min_deg", "circular_max_deg")}
                    for joint in DEFAULT_JOINT_NAMES}
                if any(group["axis_state"] != 8 or any(group[name] for name in errors)
                       for group in report["after"].values()):
                    raise ValueError("恢复后仍存在设备状态或故障异常")
                report["status"] = "restored_and_stationary"
            finally:
                report["frames"] = vendor.frames
    except BaseException as error:
        report.update(status="aborted", reason=str(error))
        print(f"零位恢复中止：{error}，需要保持现场支撑。", flush=True)
        raise
    finally:
        json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
print(json.dumps({"status": report["status"], "commands": [row["name"] for row in report["commands"]],
                  "j1": report["after"]["J1"], "output": str(output)}, ensure_ascii=False, indent=2))

import argparse
from bisect import bisect_left
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path

from construct import ConstructError

from robot_safecontrol_moveit.drempower_can import CMD_PROPERTY_READ, can_node_id
from robot_safecontrol_moveit.drempower_serial import SERIAL_CAN_FRAME
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--capture", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    capture_source, log_source = args.capture.read_bytes(), args.log.read_bytes()
    captured = json.loads(capture_source)
    events = [json.loads(line) for line in log_source.decode().splitlines()]
    plan_source = (Path(__file__).parent / "counter-experiment-plan.json").read_bytes()
    plan = json.loads(plan_source)
    if sha256(plan_source).hexdigest() != captured["plan_sha256"]:
        raise ValueError("实验计划摘要不符")
    reads, writes = [], []
    for index, frame in enumerate(captured["frames"]):
        try:
            parsed = SERIAL_CAN_FRAME.parse(bytes.fromhex(frame["raw_hex"]))
        except ConstructError:
            if (captured["status"] != "aborted" or index != len(captured["frames"]) - 1
                    or frame["direction"] != "rx"):
                raise
            reads.append(frame)
            continue
        node, command = can_node_id(parsed.frame_id)
        if frame["direction"] == "tx" and command != CMD_PROPERTY_READ:
            if node != 1:
                raise ValueError("出现 J1 以外的写入命令")
            writes.append(frame)
        else:
            reads.append(frame)
    planned = plan["commands_requiring_explicit_authorization"]
    if captured.get("experiment_phase") == "return":
        allowed = [planned[3]]
    elif captured.get("experiment_phase") == "repeat":
        allowed = [planned[index] for index in (0, 2, 3)]
    elif captured["authorization"].get("mechanical_zero_confirmed"):
        allowed = planned[4:]
    else:
        allowed = planned[:4]
    if (len(writes) > len(allowed)
            or [row["raw_hex"] for row in writes] != [row["raw_hex"] for row in allowed[:len(writes)]]):
        raise ValueError("实际发送命令与已审查序列不符")
    replay = replay_readonly_report(json.dumps({
        "frames": reads, "status": "readonly_failed" if captured["status"] == "aborted" else "readonly_completed",
    }).encode())
    control = JointTableControl(root)
    properties = replay["property_observations"]
    feedback = replay["feedback_observations"]
    property_times = [row["request_s"] for row in properties]
    feedback_times = [row["request_s"] for row in feedback]
    matched_properties, matched_feedback = set(), set()
    positions = {joint: [] for joint in DEFAULT_JOINT_NAMES}
    for event in events:
        if event["event"] == "property":
            index = bisect_left(property_times, event["request_s"])
            row = properties[index]
            if (index in matched_properties or row["received_s"] > event["received_s"]
                    or row["node_id"] != control._node(event["joint"])
                    or any(row[name] != event[name] for name in ("name", "address", "kind", "value"))):
                raise ValueError("属性日志与原始帧不符")
            matched_properties.add(index)
        elif event["event"] == "feedback":
            sample, joint = event["sample"], event["joint"]
            index = bisect_left(feedback_times, sample["request_s"])
            row = feedback[index]
            state = control.decode_state(joint, row["pos_deg"], row["vel_rpm"])
            if (index in matched_feedback or row["received_s"] > sample["received_s"]
                    or row["node_id"] != sample["node_id"] or asdict(state) != sample["state"]
                    or row["axis_error"] != sample["axis_error"] or row["traj_done"] != sample["traj_done"]):
                raise ValueError("反馈日志与原始帧不符")
            matched_feedback.add(index)
            positions[joint].append(control.project_position(joint, state.angle_deg))
    if len(matched_feedback) != len(feedback):
        raise ValueError("存在未核对的快速反馈")
    result = {
        "scope": "original_j1_counter_experiment_replay", "source_status": captured["status"],
        "capture_sha256": sha256(capture_source).hexdigest(), "log_sha256": sha256(log_source).hexdigest(),
        "plan_sha256": sha256(plan_source).hexdigest(), "readonly_replay_status": replay["status"],
        "verified_write_commands": [item["name"] for item in allowed[:len(writes)]],
        "property_reads": len(properties), "matched_property_events": len(matched_properties),
        "feedback_samples": len(feedback), "matched_feedback_events": len(matched_feedback),
        "joints": {joint: {"unit": "mm" if joint == "J1" else "deg", "samples": len(values),
                           "first": values[0], "last": values[-1], "min": min(values), "max": max(values)}
                   for joint, values in positions.items() if values},
        "incomplete_reads": replay["incomplete_reads"],
        "final_device_fields": replay["nodes"],
        "full_stroke_verified": False, "independent_physical_precision_verified": False,
    }
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({name: result[name] for name in (
        "source_status", "readonly_replay_status", "verified_write_commands", "property_reads",
        "matched_property_events", "feedback_samples", "matched_feedback_events", "joints")},
        ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

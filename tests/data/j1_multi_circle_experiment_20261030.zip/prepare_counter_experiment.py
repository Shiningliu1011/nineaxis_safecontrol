import argparse
from hashlib import sha256
import json
from pathlib import Path
import runpy

from robot_safecontrol_moveit.drempower_can import (
    CMD_POSITION_ANGLE_MODE1, CMD_PROPERTY_WRITE, CMD_SYSTEM, SYSTEM_ORDER_SET_ZERO,
    can_id, encode_property_write, encode_system, encode_trapezoid_position,
)
from robot_safecontrol_moveit.drempower_serial import SERIAL_CAN_FRAME
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.motor_motion_limits import validate_motion_parameters
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from work.nineaxis_model import NineaxisModel


def main():
    parser = argparse.ArgumentParser(description="仅生成 J1 多圈计数实验的离线检查结果")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    folder = Path(__file__).resolve().parent
    root = folder.parents[1]
    source = (folder / "nineaxis-encoder-readonly.json").read_bytes()
    servo_source = (folder / "nineaxis-servo-readonly.json").read_bytes()
    capture, servo = json.loads(source), json.loads(servo_source)
    geometry_source = (folder / "j1-40-geometry-review.json").read_bytes()
    geometry = json.loads(geometry_source)
    stop_source = (root / ".scratch/motor_control/attended-positioning-stop.json").read_bytes()
    policy_source = (root / ".scratch/motor_control/attended-positioning.json").read_bytes()
    model = NineaxisModel.load(root=root)
    control = JointTableControl(root)
    for recorded, content in ((capture, source), (servo, servo_source)):
        replay = replay_readonly_report(content)
        if recorded["status"] != "readonly_completed" or replay["status"] != "replayed_completed":
            raise ValueError("实验准备需要完整原始九轴回读")
        for joint in DEFAULT_JOINT_NAMES:
            values = recorded["properties"][joint]
            if (values["node_id"] != control._node(joint) or values["axis_state"] != 8
                    or any(values[name] for name in (
                        "axis_error", "can_error", "motor_error", "encoder_error", "controller_error"))):
                raise ValueError(f"{joint} 设备状态无效")
        for name, digest in recorded["configuration_sha256"].items():
            if sha256((root / "config" / name).read_bytes()).hexdigest() != digest:
                raise ValueError("当前坐标配置与读取记录不符")
    properties = capture["properties"]["J1"]
    if (properties["zero_offset_counts"] != 11078 or properties["encoder_turn_abs"] != 0
            or properties["multi_circle_enabled"] != 1 or properties["circular_limit_enabled"] != 1
            or properties["gear_ratio"] != 36 or properties["cpr"] != 16384
            or json.loads(policy_source)["expected_j1_zero_offset_counts"] != 11078):
        raise ValueError("本次实验仅对应已核验的 J1 零位与计数配置")
    if (geometry["model_hash"] != model.model_hash
            or geometry["readonly_sha256"] != sha256(source).hexdigest()
            or geometry["configuration_sha256"] != capture["configuration_sha256"]
            or geometry["target_mm_deg"] != [40, 0, 0, 0, 0, 0, 0, 0, 0]
            or geometry["reviewed_stop_sha256"] != sha256(stop_source).hexdigest()
            or not json.loads(stop_source)["manual_review_required"]
            or len(geometry["whole_box_self_collision"]) != 36
            or any(item["interval_margin_m"] <= 0 for item in geometry["whole_box_self_collision"])):
        raise ValueError("实验的原始起点、范围、模型或停止记录不符")
    geometry_program = root / ".scratch/issue-184-nineaxis-continuous/prepare_direct_position.py"
    if sha256(geometry_program.read_bytes()).hexdigest() != geometry["source_sha256"]:
        raise ValueError("范围检查程序身份变化")
    # 此文件只有常量、字典和函数定义，没有控制接口或模块级设备连接。
    enum_path = root / "大然电机/大然电机所有资料/drempower-wiki-master/4-库函数/python/linux-socketcan/interface_enums.py"
    enums = runpy.run_path(str(enum_path))
    parameter = "axis0.config.extra_setting.enable_multi_circle"
    if enums["property_addresss"][parameter] != 31207 or enums["property_type"][parameter] != "u32":
        raise ValueError("本地 SDK 的多圈使能地址或类型不符")
    target_deg = control.encoder_targets([.04, 0, 0, 0, 0, 0, 0, 0, 0])[1]
    zero_deg = control.encoder_targets([0.] * 9)[1]
    if target_deg != -2880 or zero_deg != 0:
        raise ValueError("当前 J1 目标换算与已测量传动不符")
    speed_rpm, acceleration_rpm_s = 3., .6
    validate_motion_parameters(speed_rpm, acceleration_rpm_s, axis_type="prismatic")
    commands = []

    def append(name, command, payload, condition):
        raw = SERIAL_CAN_FRAME.build(dict(frame_id=can_id(1, command), data=payload))
        parsed = SERIAL_CAN_FRAME.parse(raw)
        if parsed.frame_id >> 5 != 1 or parsed.data != payload:
            raise ValueError("实验帧的节点或内容不符")
        commands.append({"name": name, "node_id": 1, "command": command,
                         "raw_hex": raw.hex(), "required_condition": condition})

    def position(name, value, condition):
        append(name, CMD_POSITION_ANGLE_MODE1,
               encode_trapezoid_position(1, value, speed=speed_rpm, accel=acceleration_rpm_s), condition)

    position("hold_zero", zero_deg, "现场确认机械零位；全轴状态、反馈、当前配置与停止原因复核通过")
    append("disable_multi_circle", CMD_PROPERTY_WRITE, encode_property_write(1, 31207, 0, "u32"),
           "原生零位保持五秒，J1 control_mode=3、input_mode=5，当前位置未变化")
    position("move_to_40_mm", target_deg,
             "多圈使能回读为 0，设备限位仍为原值且使能为 1；九轴健康并连续保持五秒")
    position("return_to_zero", zero_deg,
             "40 mm 到位并持续保持五秒；计数、位置与参考连续，全部九轴健康")
    append("restore_multi_circle", CMD_PROPERTY_WRITE, encode_property_write(1, 31207, 1, "u32"),
           "返回零位并持续保持五秒；操作者确认实际机械零位，支撑仍有效")
    append("set_zero_at_confirmed_mechanical_zero", CMD_SYSTEM, encode_system(1, SYSTEM_ORDER_SET_ZERO),
           "多圈使能回读为 1；操作者确认的机械位置保持不动")
    report = {
        "scope": "offline_j1_counter_experiment_preparation",
        "hardware_executable": False,
        "motion_commands_sent": 0, "parameter_writes_sent": 0,
        "physical_stop_independently_verified": False, "full_stroke_verified": False,
        "manufacturer_information_available": "local_documents_only",
        "encoder_readonly_sha256": sha256(source).hexdigest(),
        "servo_readonly_sha256": sha256(servo_source).hexdigest(),
        "geometry_review_sha256": sha256(geometry_source).hexdigest(),
        "stop_sha256": sha256(stop_source).hexdigest(),
        "policy_sha256": sha256(policy_source).hexdigest(),
        "vendor_enums_sha256": sha256(enum_path.read_bytes()).hexdigest(),
        "source_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "model_hash": model.model_hash, "configuration_sha256": capture["configuration_sha256"],
        "j1_backup": {**properties, **servo["properties"]["J1"]},
        "targets_mm": [0, 40, 0], "device_targets_deg": [zero_deg, target_deg, zero_deg],
        "speed_mm_s": .25, "acceleration_mm_s2": .05,
        "speed_rpm": speed_rpm, "acceleration_rpm_s": acceleration_rpm_s,
        "minimum_self_margin_mm": min(row["interval_margin_m"]
                                       for row in geometry["whole_box_self_collision"]) * 1000,
        "self_clearance_mm": 10,
        "commands_requiring_explicit_authorization": commands,
        "unchanged_parameter_addresses": [31202, 31208, 34103, 38010, 38011],
        "save_or_reboot_commands": [],
        "required_before_execution": ["本次参数与动作授权", "现场支撑、空间和断电看护确认",
                                      "重新取得当前九轴原始反馈", "带完整采集和退出检查的受限执行程序"],
        "required_after_return": ["现场机械零位确认", "恢复多圈使能后设置零位",
                                  "读取新零位计数并核验本地配置", "九轴静态原始采集与回放"],
        "abort_conditions": ["属性写入未采用", "设备限位或传动改变", "轴或编码器故障",
                             "原始读取不完整或反馈过期", "位置不连续或超出检查范围",
                             "非运动轴发生超限位移", "运动超时或未取得连续保持"],
        "abort_recovery": "中止后需要现场停止与机械位置确认；不能在未知位置自动设置零位或恢复动作",
    }
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": "offline_preparation_verified", "output": str(args.output),
                      "minimum_self_margin_mm": report["minimum_self_margin_mm"],
                      "planned_commands": len(commands), "hardware_executable": False,
                      "motion_commands_sent": 0, "parameter_writes_sent": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()

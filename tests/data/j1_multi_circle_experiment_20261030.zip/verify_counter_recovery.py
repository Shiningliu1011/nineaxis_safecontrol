from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path

from robot_safecontrol_moveit.drempower_can import (
    CMD_PROPERTY_READ, CMD_SYSTEM, SYSTEM_ORDER_SET_ZERO,
    can_id, can_node_id, enable_sequence, encode_system,
)
from robot_safecontrol_moveit.drempower_serial import SERIAL_CAN_FRAME
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES


FOLDER = Path(__file__).resolve().parent
ROOT = FOLDER.parents[1]
ERRORS = ("axis_error", "can_error", "motor_error", "encoder_error", "controller_error")
CONTROL = JointTableControl(ROOT)


def verify_samples(recorded, replay):
    samples, raw = recorded["samples"], replay["feedback_observations"]
    if len(samples) != len(raw):
        raise ValueError("反馈记录数量与原始帧不符")
    positions = {joint: [] for joint in DEFAULT_JOINT_NAMES}
    times = {joint: [] for joint in DEFAULT_JOINT_NAMES}
    for sample, row in zip(samples, raw):
        joint = sample["joint"]
        state = CONTROL.decode_state(joint, row["pos_deg"], row["vel_rpm"])
        if (sample["node_id"] != row["node_id"] or row["node_id"] != CONTROL._node(joint)
                or sample["state"] != asdict(state)
                or sample["axis_error"] != row["axis_error"] or row["axis_error"]
                or sample["traj_done"] != row["traj_done"] or not row["traj_done"]
                or not sample["request_s"] <= row["request_s"] <= row["received_s"] <= sample["received_s"]
                or sample["received_s"] - sample["request_s"] > .2):
            raise ValueError("反馈内容、故障或时间与原始帧不符")
        positions[joint].append(CONTROL.project_position(joint, state.angle_deg))
        times[joint].append(row["received_s"])
    result = {}
    for joint, values in positions.items():
        # 只读采集的首次反馈位于属性读取前，连续观察使用后续反馈。
        duration = times[joint][-1] - times[joint][1]
        if duration < 5 or max(map(abs, values)) > (.001 if joint == "J1" else .1):
            raise ValueError(f"{joint} 缺少零位附近的连续五秒反馈")
        result[joint] = {"unit": "mm" if joint == "J1" else "deg", "samples": len(values),
                         "host_duration_s": duration, "first": values[0], "last": values[-1],
                         "min": min(values), "max": max(values)}
    return result


def main():
    source = (FOLDER / "counter-zero-recovery-01.capture.json").read_bytes()
    recorded = json.loads(source)
    if (recorded["status"] != "restored_and_stationary"
            or recorded["source_sha256"] != sha256((FOLDER / "restore_counter_zero.py").read_bytes()).hexdigest()
            or recorded["return_capture_sha256"] != sha256((FOLDER / "counter-return-01.capture.json").read_bytes()).hexdigest()):
        raise ValueError("恢复结果、执行源码或回零依据不符")
    expected = [(can_id(1, CMD_SYSTEM), encode_system(1, SYSTEM_ORDER_SET_ZERO)), *enable_sequence(1)]
    names = ["set_zero", "clear_error", "enable_zero_hold"]
    writes, reads = [], []
    for frame in recorded["frames"]:
        parsed = SERIAL_CAN_FRAME.parse(bytes.fromhex(frame["raw_hex"]))
        _, command = can_node_id(parsed.frame_id)
        if frame["direction"] == "tx" and command != CMD_PROPERTY_READ:
            writes.append((parsed.frame_id, parsed.data))
        else:
            reads.append(frame)
    if writes != expected or [item["name"] for item in recorded["commands"]] != names:
        raise ValueError("恢复命令与设置零点、清错、恢复闭环的序列不符")
    for item, (frame_id, payload) in zip(recorded["commands"], expected):
        if ((item["node_id"], item["command"]) != can_node_id(frame_id)
                or item["payload_hex"] != payload.hex()):
            raise ValueError("恢复命令声明与原始发送不符")
    replay = replay_readonly_report(json.dumps({"frames": reads, "status": "readonly_completed"}).encode())
    raw_properties = replay["property_observations"]
    if len(raw_properties) != len(recorded["property_observations"]):
        raise ValueError("恢复属性数量与原始帧不符")
    for item, row in zip(recorded["property_observations"], raw_properties):
        if (CONTROL._node(item["joint"]) != row["node_id"] or item["name"] != row["name"]
                or item["value"] != row["value"]
                or not item["request_s"] <= row["request_s"] <= row["received_s"] <= item["received_s"]):
            raise ValueError("恢复属性内容或时间与原始帧不符")
    for group, raw_groups in ((recorded["before"], replay["initial_nodes"]),
                               (recorded["after"], replay["nodes"])):
        for joint, fields in group.items():
            if any(raw_groups[str(CONTROL._node(joint))][name] != value for name, value in fields.items()):
                raise ValueError("恢复前后属性快照与原始帧不符")
    result = {"status": "recovery_and_final_readonly_verified", "recovery_sha256": sha256(source).hexdigest(),
              "verified_recovery_commands": names, "recovery_property_reads": len(raw_properties),
              "recovery_feedback": verify_samples(recorded, replay)}
    final_source = (FOLDER / "final-nineaxis-confirmed.json").read_bytes()
    final = json.loads(final_source)
    final_replay = replay_readonly_report(final_source)
    if final["status"] != "readonly_completed" or final_replay["status"] != "replayed_completed":
        raise ValueError("最终只读采集不完整")
    policy_source = (ROOT / ".scratch/motor_control/attended-positioning.json").read_bytes()
    policy = json.loads(policy_source)
    if any(sha256((ROOT / "config" / name).read_bytes()).hexdigest() != digest
           for name, digest in final["configuration_sha256"].items()):
        raise ValueError("最终读取采用的设备坐标配置变化")
    counter_changes = {}
    for joint in DEFAULT_JOINT_NAMES:
        fields = final_replay["nodes"][str(CONTROL._node(joint))]
        if fields["axis_state"] != 8 or any(fields[name] for name in ERRORS):
            raise ValueError(f"{joint} 最终状态或故障异常")
        if any(fields[name] != value for name, value in recorded["after"][joint].items()
               if name != "encoder_turn_abs"):
            raise ValueError(f"{joint} 恢复后与最终读取不一致")
        before_turn = recorded["after"][joint]["encoder_turn_abs"]
        if fields["encoder_turn_abs"] != before_turn:
            counter_changes[joint] = {"after_recovery": before_turn, "final_readonly": fields["encoder_turn_abs"]}
    j1 = final_replay["nodes"]["1"]
    if (j1["zero_offset_counts"] != policy["expected_j1_zero_offset_counts"]
            or j1["zero_offset_counts"] != 11045 or j1["encoder_turn_abs"] != 0
            or j1["multi_circle_enabled"] != 1 or j1["circular_limit_enabled"] != 1
            or j1["circular_min_deg"] != -36000 or j1["circular_max_deg"] != 1000):
        raise ValueError("最终 J1 零位或限位与本次恢复结果不符")
    stop_source = (ROOT / ".scratch/motor_control/attended-positioning-stop.json").read_bytes()
    plan = json.loads((FOLDER / "counter-experiment-plan.json").read_bytes())
    if sha256(stop_source).hexdigest() != plan["stop_sha256"]:
        raise ValueError("全局停止记录变化")
    result.update(final_capture_sha256=sha256(final_source).hexdigest(),
                  final_property_reads=len(final_replay["property_observations"]),
                  final_feedback=verify_samples(final, final_replay), final_device_fields=final_replay["nodes"],
                  observed_turn_counter_changes=counter_changes,
                  policy_sha256=sha256(policy_source).hexdigest(), stop_sha256=sha256(stop_source).hexdigest(),
                  full_stroke_verified=False, independent_physical_precision_verified=False,
                  physical_stop_independently_verified=False, motion_restart_qualified=False)
    with (FOLDER / "counter-recovery-verified.json").open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({name: result[name] for name in ("status", "verified_recovery_commands",
                      "recovery_property_reads", "recovery_feedback", "final_property_reads", "final_feedback")},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

import json
import time
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from statistics import median
from zoneinfo import ZoneInfo

from robot_safecontrol_moveit.drempower_serial import DrEmpowerSerial
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import VendorFeedbackReader


root = Path(__file__).resolve().parents[2]
destination = root / ".scratch/joint-positioning/after-operator-all-zero-readonly.json"
control = JointTableControl(root)
report = {"started_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
          "user_report": "九个关节均已在机械零位", "motion_commands_sent": 0,
          "parameter_writes_sent": 0, "properties": {}, "samples": []}
with destination.open("x", encoding="utf-8") as stream:
    with DrEmpowerSerial("/dev/serial/by-id/usb-Dr-Tech_DR-USB_CAN_87949380174B-if00") as device:
        try:
            for joint in DEFAULT_JOINT_NAMES:
                node = control._node(joint)
                values = report["properties"][joint] = {}
                for name, address, kind in (
                    ("node_id", 31001, "u32"), ("axis_state", 30002, "u32"),
                    ("axis_error", 30001, "u32"), ("encoder_error", 34001, "u32"),
                    ("output_pos_deg", 38007, "f32"),
                ):
                    values[name] = device.read_property(node, address, kind)
            for name, address, kind in (
                ("serial_number_l", 3, "u32"), ("multi_circle_enabled", 31207, "u32"),
                ("encoder_turn_abs", 34010, "s32"), ("zero_offset_counts", 31205, "f32"),
            ):
                report["properties"]["J1"][name] = device.read_property(1, address, kind)
            reader = VendorFeedbackReader(device, control, .2)
            until = time.monotonic() + 6.
            while time.monotonic() < until:
                for joint in DEFAULT_JOINT_NAMES:
                    report["samples"].append({"joint": joint, **asdict(reader.read(joint))})
                time.sleep(.02)
            report["positions_mm_deg"] = {
                joint: median(control.project_position(joint, row["state"]["angle_deg"])
                              for row in report["samples"] if row["joint"] == joint)
                for joint in DEFAULT_JOINT_NAMES
            }
            report["status"] = "readonly_completed"
        finally:
            report["frames"] = device.frames
            json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
print(json.dumps({key: report[key] for key in ("status", "properties", "positions_mm_deg")},
                 ensure_ascii=False, indent=2))

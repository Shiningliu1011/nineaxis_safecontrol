import argparse
import json
import time
from dataclasses import asdict, replace
from hashlib import sha256
from math import isfinite
from pathlib import Path

from robot_safecontrol_moveit.drempower_joint_control import JointFeedback
from robot_safecontrol_moveit.drempower_serial import DrEmpowerSerial
from robot_safecontrol_moveit.joint_positioning import positioning_limits
from robot_safecontrol_moveit.joint_table_commissioning import stationary_noise
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.motor_motion_limits import MotionBounds
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import (
    ArrivalWindow,
    MotionRejected,
    ObservedFeedback,
    SingleJointMonitor,
    VendorFeedbackReader,
    VelocityWindow,
    stationary_conditions,
)


ROOT = Path(__file__).resolve().parents[2]
DIRECTORY = ROOT / ".scratch/joint-positioning"
JOINTS = DEFAULT_JOINT_NAMES[1:]
PORT = "/dev/serial/by-id/usb-Dr-Tech_DR-USB_CAN_87949380174B-if00"
POLICY_PATH = ROOT / ".scratch/motor_control/attended-positioning.json"
SOURCE_PATH = DIRECTORY / "before-requested-zero-readonly.json"


class ReturnZero:
    def __init__(self):
        self.control = JointTableControl(ROOT)
        policy_bytes = POLICY_PATH.read_bytes()
        self.policy_digest = sha256(policy_bytes).hexdigest()
        self.policy = json.loads(policy_bytes)
        self.identities = {POLICY_PATH: self.policy_digest}
        for name in ("stop.json", "attended-positioning-stop.json"):
            path = ROOT / ".scratch/motor_control" / name
            self.identities[path] = sha256(path.read_bytes()).hexdigest()
        for name, digest in self.policy["config_hashes"].items():
            self.identities[ROOT / "config" / name] = digest
        self.check_identity()
        if self.policy["port"] != PORT or self.policy["maximum_feedback_deg_s"] != 5.:
            raise ValueError("现场参数范围发生变化")
        source = json.loads(SOURCE_PATH.read_bytes())
        if source["status"] != "readonly_completed" or source["motion_commands_sent"] != 0:
            raise ValueError("缺少本次独立非运动读取")
        j1 = source["properties"]["J1"]
        if j1["axis_state"] != 1 or j1["axis_error"] != 256:
            raise ValueError("J1 故障状态发生变化")
        self.j1_position = -j1["output_pos_deg"]
        noise = stationary_noise(ROOT, ROOT / self.policy["noise_evidence_path"],
                                 self.policy["noise_evidence_sha256"], self.policy["model_hash"])
        limits = positioning_limits(ROOT, dict(zip(DEFAULT_JOINT_NAMES, [.25, *([2.46] * 8)])),
                                    dict(zip(DEFAULT_JOINT_NAMES, [.05, *([.3] * 8)])))
        self.limits = {}
        for joint in JOINTS:
            base = limits[joint]
            bounds = MotionBounds(base.speed_rpm, base.accel_rpm_s, 5 / 6, self.policy_digest)
            self.limits[joint] = replace(base, stationary_window_s=5., stationary_velocity_noise_rpm=noise[joint],
                                         max_feedback_rpm=5 / 6, bounds=bounds)
        self.windows = {joint: VelocityWindow(1., 5.) for joint in JOINTS}
        self.monitors = {joint: SingleJointMonitor(self.control._node(joint), limit)
                         for joint, limit in self.limits.items()}
        self.phase = "initializing"
        self.since = None
        self.started = None
        self.latest = {}
        self.attempted = 0

    def check_identity(self):
        for path, digest in self.identities.items():
            if sha256(path.read_bytes()).hexdigest() != digest:
                raise RuntimeError(f"本次回零的现场记录或配置变化：{path}")

    def observe(self, samples, now):
        if set(samples) != set(DEFAULT_JOINT_NAMES):
            raise MotionRejected("incomplete_feedback")
        j1 = samples["J1"]
        if (j1.node_id != 1 or not j1.axis_error
                or not all(isfinite(value) for value in (j1.state.angle_deg, j1.request_s, j1.received_s, now))
                or not 0 <= j1.request_s <= j1.received_s <= now
                or now - j1.request_s > .2 or abs(j1.state.angle_deg - self.j1_position) > .1):
            raise MotionRejected("J1_fault_position_or_state_changed")
        if self.started is None:
            self.started = now
        current = {}
        for joint in JOINTS:
            sample = self.windows[joint].add(samples[joint])
            monitor = self.monitors[joint]
            if self.phase == "initializing" and sample.window_duration_s < 1.:
                monitor.validate_hold_feedback(sample, now)
            elif self.phase == "moving" and monitor.phase in ("moving", "settling"):
                monitor.observe(sample, now)
            else:
                monitor.validate_feedback(sample, now)
                if self.phase == "moving" and monitor.phase == "completed" and (
                    abs(sample.state.angle_deg) > self.limits[joint].tolerance_deg
                    or not all(stationary_conditions(sample, self.limits[joint]).values()) or not sample.traj_done
                ):
                    raise MotionRejected(f"{joint}:zero_position_changed")
            current[joint] = sample
        self.latest = current
        stationary = all(sample.traj_done and all(stationary_conditions(sample, self.limits[joint]).values())
                         and (self.phase != "moving" or abs(sample.state.angle_deg) <= .1)
                         for joint, sample in current.items())
        if not stationary:
            self.since = None
        elif self.since is None:
            self.since = max(sample.received_s for sample in current.values())
        elif min(sample.request_s for sample in current.values()) - self.since >= .5:
            self.phase = "ready" if self.phase == "initializing" else "completed"
        if self.phase == "initializing" and now - self.started > 8.:
            raise MotionRejected("initial_stationary_timeout")

    def begin(self, samples, now):
        if self.phase != "ready":
            raise MotionRejected("return_zero_not_ready")
        self.check_identity()
        commands = []
        for joint in JOINTS:
            sample = self.windows[joint].add(samples[joint])
            limit = self.limits[joint]
            if sample.state.angle_deg != 0:
                limit = limit.for_motion(-sample.state.angle_deg)
            previous = self.monitors[joint]
            monitor = SingleJointMonitor(self.control._node(joint), limit)
            monitor.last_request_s = previous.last_request_s
            monitor.last_received_s = previous.last_received_s
            monitor.last_angle_deg = previous.last_angle_deg
            monitor.start_absolute(sample, 0., now)
            self.limits[joint] = limit
            self.monitors[joint] = monitor
            self.latest[joint] = sample
            commands.append({"joint": joint, "arguments": self.control.position_arguments(joint, 0., limit)})
        if [command["arguments"]["id_num"] for command in commands] != list(range(2, 10)):
            raise ValueError("本次只能向 J2–J9 发送回零位置")
        self.phase, self.since = "moving", None
        return commands

    def read_cycle(self, reader):
        samples = {"J1": reader.read("J1")}
        for joint in JOINTS:
            reader.require_closed_loop(joint)
            samples[joint] = reader.read(joint)
        return samples

    def verify(self, vendor):
        j1 = {name: vendor.read_property(1, address, kind) for name, address, kind in (
            ("axis_state", 30002, "u32"), ("axis_error", 30001, "u32"), ("encoder_error", 34001, "u32"),
            ("serial_number_l", 3, "u32"), ("zero_offset_counts", 31205, "f32"),
        )}
        if j1 != {"axis_state": 1, "axis_error": 256, "encoder_error": 512,
                   "serial_number_l": 1955, "zero_offset_counts": 7733.}:
            raise RuntimeError(f"J1 状态与已诊断故障不符：{j1}")
        for joint in JOINTS:
            node = self.control._node(joint)
            values = {name: vendor.read_property(node, address, kind) for name, address, kind in (
                ("node", 31001, "u32"), ("state", 30002, "u32"), ("axis_error", 30001, "u32"),
                ("encoder_error", 34001, "u32"), ("motor_error", 33001, "u32"),
                ("controller_error", 32001, "u32"), ("can_error", 20001, "u32"),
                ("limits_enabled", 31202, "u32"), ("lower", 38010, "f32"), ("upper", 38011, "f32"),
                ("traj_mode", 35104, "u32"), ("speed_limit", 38012, "f32"),
            )}
            target = self.control.position_arguments(joint, 0., self.limits[joint])["angle"]
            if (not all(isfinite(value) for value in values.values()) or values["node"] != node
                    or values["state"] != 8 or values["traj_mode"] != 1
                    or values["limits_enabled"] != 1 or not values["lower"] <= target <= values["upper"]
                    or values["speed_limit"] < self.limits[joint].speed_rpm
                    or any(values[name] for name in ("axis_error", "encoder_error", "motor_error", "controller_error", "can_error"))):
                raise RuntimeError(f"{joint} 实际状态或目标检查未通过：{values}")
            vendor.prepare_motion(node)

    def hold(self, vendor, reader, record):
        if vendor._failed or reader.in_transaction:
            return "communication_untrusted"
        samples = self.read_cycle(reader)
        arrivals, monitors = {}, {}
        for joint in JOINTS:
            sample = self.windows[joint].add(samples[joint])
            previous = self.monitors[joint]
            monitor = SingleJointMonitor(self.control._node(joint), self.limits[joint])
            monitor.last_request_s, monitor.last_received_s = previous.last_request_s, previous.last_received_s
            monitor.last_angle_deg = previous.last_angle_deg
            monitor.validate_hold_feedback(sample, time.monotonic())
            monitors[joint] = monitor
            arrivals[joint] = ArrivalWindow(sample.state.angle_deg, self.limits[joint])
        for joint in JOINTS:
            if time.monotonic() - samples[joint].request_s > .2:
                raise MotionRejected("hold_feedback_timeout")
            arguments = self.control.position_arguments(joint, samples[joint].state.angle_deg, self.limits[joint])
            record("hold_requested", joint=joint, arguments=arguments)
            vendor.set_angle(**arguments)
        until = time.monotonic() + max(limit.reposition_hold_timeout_s for limit in self.limits.values())
        while time.monotonic() < until:
            samples = self.read_cycle(reader)
            settled = []
            for joint in JOINTS:
                sample = self.windows[joint].add(samples[joint])
                monitors[joint].validate_feedback(sample, time.monotonic())
                settled.append(arrivals[joint].observe(sample, time.monotonic()))
            record("hold_feedback", samples={joint: asdict(sample) for joint, sample in samples.items()})
            if all(settled):
                return "hold_observed"
            time.sleep(.02)
        return "hold_observation_timeout"


def replay():
    operation = ReturnZero()
    source = json.loads(SOURCE_PATH.read_bytes())
    rows = source["samples"][9:]
    for offset in range(0, len(rows), 9):
        samples = {row["joint"]: ObservedFeedback(
            **{key: value for key, value in row.items() if key not in ("joint", "state")},
            state=JointFeedback(**row["state"])) for row in rows[offset:offset + 9]}
        now = max(sample.received_s for sample in samples.values())
        if operation.phase == "ready":
            commands = operation.begin(samples, now)
            print(json.dumps({"status": "actual_stationary_replay_passed", "commands": commands}, ensure_ascii=False))
            return
        operation.observe(samples, now)
    raise RuntimeError("实际静止反馈未通过回零准备检查")


def execute():
    operation = ReturnZero()
    path = DIRECTORY / "requested-zero-j2-j9.jsonl"
    frames_path = path.with_suffix(".frames.json")
    if frames_path.exists():
        raise FileExistsError(frames_path)
    with path.open("x", encoding="utf-8") as log:
        def record(event, **fields):
            log.write(json.dumps({"event": event, "monotonic_s": time.monotonic(), **fields},
                                 ensure_ascii=False, allow_nan=False) + "\n")
            log.flush()

        with DrEmpowerSerial(PORT, position_nodes={1: "prismatic", **{node: "revolute" for node in range(2, 10)}}) as vendor:
            reader = VendorFeedbackReader(vendor, operation.control, .2)
            try:
                record("authorized_return_zero", joints=list(JOINTS), j1_fault_retained=True,
                       original_zero_preserved=True, limits={joint: asdict(limit) for joint, limit in operation.limits.items()})
                operation.verify(vendor)
                progress_at = time.monotonic()
                while operation.phase != "completed":
                    operation.check_identity()
                    samples = operation.read_cycle(reader)
                    now = time.monotonic()
                    record("feedback", samples={joint: asdict(sample) for joint, sample in samples.items()})
                    if operation.phase == "ready":
                        commands = operation.begin(samples, now)
                        for command in commands:
                            joint = command["joint"]
                            reader.require_closed_loop(joint)
                            if time.monotonic() - samples[joint].request_s > .2:
                                raise MotionRejected("feedback_timeout_before_send")
                            record("command_requested", **command)
                            operation.attempted += 1
                            vendor.set_angle(**command["arguments"])
                        print("J2–J9 回零位置命令已发送。", flush=True)
                    else:
                        operation.observe(samples, now)
                    if now >= progress_at:
                        print(json.dumps({"phase": operation.phase, "positions_deg": {
                            joint: round(sample.state.angle_deg, 4) for joint, sample in operation.latest.items()}}, ensure_ascii=False), flush=True)
                        progress_at = now + 5.
                    time.sleep(.02)
                record("completed", positions_deg={joint: sample.state.angle_deg for joint, sample in operation.latest.items()},
                       j1_returned_to_zero=False, enabled_holding=True)
                print("J2–J9 已回到原机械零位并保持使能；J1 故障保留，未执行回零。", flush=True)
            except BaseException as error:
                stop = "no_motion_command_attempted"
                if operation.attempted:
                    try:
                        stop = operation.hold(vendor, reader, record)
                    except BaseException as hold_error:
                        stop = f"hold_failed: {hold_error}"
                record("aborted", reason=str(error), stop_result=stop)
                print(f"回零中止：{error}；停止结果：{stop}", flush=True)
                raise
            finally:
                with frames_path.open("x", encoding="utf-8") as stream:
                    json.dump(vendor.frames, stream, ensure_ascii=False, indent=2, allow_nan=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true")
    if parser.parse_args().execute:
        execute()
    else:
        replay()

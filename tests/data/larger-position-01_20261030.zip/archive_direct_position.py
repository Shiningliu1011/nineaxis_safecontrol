import argparse
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


parser = argparse.ArgumentParser()
parser.add_argument("--run", required=True)
parser.add_argument("--current", type=Path, required=True)
parser.add_argument("--review", type=Path, required=True)
parser.add_argument("--extra", nargs="*", type=Path, default=[])
parser.add_argument("--operator", type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
names = [f"{args.run}{suffix}" for suffix in (".jsonl", ".frames.json", ".report.json")]
names += ["run_direct_position.py", "prepare_direct_position.py", "archive_direct_position.py"]
files = {name: folder / name for name in names}
operator_path = args.operator or folder / "direct-position-operator.json"
files[operator_path.name] = operator_path
files.update({path.name: path for path in (args.current, args.review, *args.extra)})
sources = ("joint_positioning", "joint_table_runtime", "joint_table_execution", "joint_table", "j1_execution",
           "single_joint_execution", "attended_positioning", "drempower_serial", "drempower_can", "motor_motion_limits")
files.update({f"source/{name}.py": root / f"src/robot_safecontrol_moveit/{name}.py" for name in sources})
files.update({f"config/{name}": root / "config" / name
              for name in ("hardware_joint_zero.yaml", "drempower.yaml", "j1_transmission.yaml")})
report = {"scope": "original_native_positioning_capture", "run": args.run, "files": []}
destination = root / "tests/data" / f"{args.run}_20261030.zip"
with ZipFile(destination, "x", ZIP_DEFLATED) as archive:
    for name, path in files.items():
        data = path.read_bytes()
        archive.writestr(name, data)
        report["files"].append({"member": name, "bytes": len(data), "sha256": sha256(data).hexdigest()})
    archive.writestr("provenance.json", json.dumps(report, ensure_ascii=False, indent=2))
with ZipFile(destination) as archive:
    if archive.testzip() is not None:
        raise ValueError("原始定位归档校验失败")
    for item in report["files"]:
        data = archive.read(item["member"])
        if len(data) != item["bytes"] or sha256(data).hexdigest() != item["sha256"]:
            raise ValueError("原始定位归档成员身份不符")
print(json.dumps({"archive": str(destination), "sha256": sha256(destination.read_bytes()).hexdigest(),
                  "members": len(files)}, ensure_ascii=False))

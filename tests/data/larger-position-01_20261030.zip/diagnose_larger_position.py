from dataclasses import asdict
import json
from pathlib import Path

from robot_safecontrol_moveit.drempower_joint_control import JointFeedback
from robot_safecontrol_moveit.joint_positioning import single_target_table
from robot_safecontrol_moveit.joint_table_execution import JointTableExecutor
from robot_safecontrol_moveit.motor_motion_limits import MotionBounds
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import (
    ExecutionLimits, MotionRejected, ObservedFeedback, stationary_conditions,
)
from work.nineaxis_model import NineaxisModel


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
report = json.loads((folder / "larger-position-01.report.json").read_bytes())
events = [json.loads(line) for line in (folder / "larger-position-01.jsonl").read_bytes().splitlines()]
model = NineaxisModel.load(root=root)
table = single_target_table(dict(zip(DEFAULT_JOINT_NAMES, report["attempts"][0]["target_mm_deg"])), model)
limits = {joint: ExecutionLimits(**{**value, "bounds": MotionBounds(**value["bounds"]) if value["bounds"] else None})
          for joint, value in report["limits"].items()}
executor = JointTableExecutor(table, model, measurement_kind="positioning", task_id="diagnose-original",
                              feedback_source="recorded_device_feedback", limits=limits, manual_positioning=True)
for event in events:
    if event["event"] == "command_requested" and not executor.attempts:
        executor.begin(now_s=event["monotonic_s"])
    if event["event"] != "feedback":
        continue
    samples = {joint: ObservedFeedback(**{**value, "state": JointFeedback(**value["state"])})
               for joint, value in event["samples"].items()}
    previous = {joint: monitor.phase for joint, monitor in executor.monitors.items()}
    try:
        executor.observe(samples, now_s=event["monotonic_s"])
    except MotionRejected:
        joint = executor.rejection_observation["joint"]
        sample = executor.windows[joint].add
        window = executor.windows[joint]
        from robot_safecontrol_moveit.single_joint_execution import VelocityWindow

        replay_window = VelocityWindow(window.duration_s, window.stationary_duration_s)
        for row in window.rows:
            latest = replay_window.add(row)
        result = {"reason": executor.reason, "previous_phases": previous,
                  "rejected_sample": asdict(latest), "stationary_conditions": stationary_conditions(latest, limits[joint]),
                  "target": executor.reference[joint], "position_error_deg": latest.state.angle_deg - executor.reference[joint],
                  "position_arrived_s": executor.monitors[joint].position_arrived_s,
                  "rejected_s": event["monotonic_s"], "termination": report["termination"]}
        print(json.dumps(result, indent=2))
        break
else:
    print(json.dumps({"current_replay_phase": executor.phase, "original_termination": report["termination"]}))

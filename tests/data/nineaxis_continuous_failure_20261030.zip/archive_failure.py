from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
paths = [folder / name for name in (
    "preflight.json", "operating-preflight.json", "restart-preflight.json", "sequence-review.json",
    "stop-before-review.json", "stop-after-review.json", "rejected-attempt-stop.json", "restart-review.json",
    "sequence.jsonl", "sequence.capture.json", "nineaxis-roundtrip-02.jsonl", "nineaxis-roundtrip-02.capture.json",
    "run_sequence.py", "prepare_sequence.py", "release_reviewed_sequence.py", "review_restart.py",
    "operator-stop.json", "failure-inspection.json", "archive_failure.py", "reader-green.xml", "range-search.txt",
)]
paths += [root / "src/robot_safecontrol_moveit" / name for name in (
    "drempower_serial.py", "drempower_can.py", "joint_table_readonly.py", "positioning_plan.py")]
paths += [root / "config" / name for name in ("drempower.yaml", "hardware_joint_zero.yaml", "j1_transmission.yaml")]
paths += [root / ".scratch/motor_control" / name for name in (
    "attended-positioning.json", "attended-positioning-stop.json")]
members = {}
for path in paths:
    name = path.name if path.parent == folder else str(path.relative_to(root))
    members[name] = path.read_bytes()
with ZipFile(folder / "rejected-attempt.zip") as archive:
    members["rejected-attempt-source.py"] = archive.read("run_sequence.py")
for name, source_name in (("sequence", "rejected-attempt-source.py"), ("nineaxis-roundtrip-02", "run_sequence.py")):
    captured = json.loads(members[f"{name}.capture.json"])
    if (captured["source_sha256"] != sha256(members[source_name]).hexdigest()
            or captured["log_sha256"] != sha256(members[f"{name}.jsonl"]).hexdigest()):
        raise ValueError("实际拒绝源码、日志或收发身份不符")
manifest = {
    "evidence_kind": "actual_nineaxis_continuous_reference_abort_and_operator_emergency_stop",
    "hardware_qualified": False, "physical_stop_independently_verified": False,
    "continuous_roundtrip_completed": False,
    "files": [{"member": name, "bytes": len(data), "sha256": sha256(data).hexdigest()}
              for name, data in members.items()],
}
output = root / "tests/data/nineaxis_continuous_failure_20261030.zip"
with ZipFile(output, "x", compression=ZIP_DEFLATED) as archive:
    for name, data in members.items():
        archive.writestr(name, data)
    archive.writestr("provenance.json", json.dumps(manifest, ensure_ascii=False, indent=2, allow_nan=False))
with ZipFile(output) as archive:
    if archive.testzip() is not None:
        raise ValueError("真实拒绝归档的 CRC 无效")
    for row in manifest["files"]:
        data = archive.read(row["member"])
        if len(data) != row["bytes"] or sha256(data).hexdigest() != row["sha256"]:
            raise ValueError("真实拒绝归档成员长度或摘要无效")
print(json.dumps({"archive": str(output), "sha256": sha256(output.read_bytes()).hexdigest(),
                  "members_verified": len(members)}, indent=2))

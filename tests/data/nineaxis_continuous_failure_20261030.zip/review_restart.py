from hashlib import sha256
import json
from math import isclose
from pathlib import Path

from robot_safecontrol_moveit.drempower_can import can_node_id, encode_trapezoid_position
from robot_safecontrol_moveit.drempower_serial import SERIAL_CAN_FRAME
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.motor_stop_latch import MotorStopLatch
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
failed_content = (folder / "sequence.capture.json").read_bytes()
failed = json.loads(failed_content)
events = [json.loads(line) for line in (folder / "sequence.jsonl").read_bytes().splitlines()]
commands = [row for row in events if row["event"] in ("low_speed_seed_requested", "abort_hold_requested")]
if failed["status"] != "aborted" or failed["stop_result"] != "hold_observed" or len(commands) != 18:
    raise ValueError("拒绝后的完整九轴保持未确认")
writes = []
for frame in failed["frames"]:
    if frame["direction"] == "tx":
        parsed = SERIAL_CAN_FRAME.parse(bytes.fromhex(frame["raw_hex"]))
        node, command = can_node_id(parsed.frame_id)
        if command not in (0x1e, 0x1a):
            raise ValueError("首批拒绝记录存在预设、广播或其他写入")
        if command == 0x1a:
            writes.append((node, parsed.data))
if len(writes) != len(commands):
    raise ValueError("保持命令数量与原始帧不符")
for (node, payload), request in zip(writes, commands):
    args = request["arguments"]
    if node != args["id_num"] or payload != encode_trapezoid_position(
            node, args["angle"], speed=args["speed"], accel=args["param"]):
        raise ValueError("保持命令与原始位置参数不符")
data = (folder / "restart-preflight.json").read_bytes()
current = json.loads(data)
replay = replay_readonly_report(data)
review = json.loads((folder / "sequence-review.json").read_bytes())
if current["status"] != "readonly_completed" or replay["status"] != "replayed_completed":
    raise ValueError("修正后的非运动重新读取不完整")
if current["configuration_sha256"] != review["configuration_sha256"]:
    raise ValueError("当前坐标配置与审查不同")
control = JointTableControl(root)
for index, joint in enumerate(DEFAULT_JOINT_NAMES):
    values = current["properties"][joint]
    if values["axis_state"] != 8 or any(values[name] for name in (
            "axis_error", "can_error", "motor_error", "encoder_error", "controller_error")):
        raise ValueError("重新读取的设备状态或故障不符")
    rows = [row for row in current["samples"][9:] if row["joint"] == joint]
    positions = [row["state"]["angle_deg"] for row in rows]
    if (any(not row["traj_done"] or row["axis_error"] for row in rows)
            or rows[-1]["received_s"] - rows[0]["received_s"] < 5 or max(positions) - min(positions) > .01):
        raise ValueError("重新读取未取得九轴五秒稳定证据")
    observed = control.project_position(joint, positions[-1])
    if abs(observed - review["initial_mm_deg"][index]) > (.01 / 72 if joint == "J1" else .01):
        raise ValueError("实际起点与当前有限范围审查不同")
    speed, accel = (.6, .12) if joint == "J1" else (.05, .05)
    for name, expected in (("trap_velocity_rpm", speed), ("trap_acceleration_rpm_s", accel),
                            ("trap_deceleration_rpm_s", accel)):
        if not isclose(values[name], expected, rel_tol=1e-5, abs_tol=1e-6):
            raise ValueError("设备未采用本次低速运行参数")
latch = MotorStopLatch(root / ".scratch/motor_control/attended-positioning-stop.json")
stop_bytes = latch.path.read_bytes()
stop = json.loads(stop_bytes)
if stop["reason"] != "节点 1 超出连续参考实验位移" or stop["log_path"] != str(folder / "sequence.jsonl"):
    raise ValueError("当前停止原因变化")
result = {
    "scope": review["scope"], "rejected_capture_sha256": sha256(failed_content).hexdigest(),
    "current_readonly_sha256": sha256(data).hexdigest(), "hold_commands_verified": len(writes),
    "preset_commands_sent": 0, "broadcast_commands_sent": 0, "nineaxis_stable_observed": True,
    "explicit_low_speed_parameters_verified": True,
    "updated_source_sha256": sha256((folder / "run_sequence.py").read_bytes()).hexdigest(),
    "hardware_qualified": False, "absolute_coordinate_qualification": False,
}
with (folder / "restart-review.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
latch.acknowledge_stop(expected_sha256=sha256(stop_bytes).hexdigest(), archive_path=folder / "rejected-attempt-stop.json")
print(json.dumps(result, ensure_ascii=False, indent=2))

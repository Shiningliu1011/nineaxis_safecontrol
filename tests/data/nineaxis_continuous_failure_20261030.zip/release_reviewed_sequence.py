from hashlib import sha256
import json
from pathlib import Path

from robot_safecontrol_moveit.motor_stop_latch import MotorStopLatch


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
review = json.loads((folder / "sequence-review.json").read_bytes())
if sha256((folder / "stop-before-review.json").read_bytes()).hexdigest() != review["reviewed_stop_sha256"]:
    raise ValueError("原停止原因与本轮审查不符")
if (review["user_statement"] != "固定已解除，支撑不妨碍运动，可以持续看护"
        or review["scope"] != "attended_nineaxis_small_relative_continuous_roundtrip"
        or review["hardware_qualified"] or review["absolute_coordinate_qualification"]
        or review["physical_stop_independently_verified"]):
    raise ValueError("本轮现场声明或研究范围不符")
latch = MotorStopLatch(root / ".scratch/motor_control/attended-positioning-stop.json")
content = latch.path.read_bytes()
stop = json.loads(content)
if (stop["reason"] != "bounded_nineaxis_relative_startup_review_completed"
        or stop["log_path"] != str(folder / "sequence-review.json") or stop["review_scope"] != review["scope"]):
    raise ValueError("本轮有限范围的停止审查记录不符")
if (folder / "sequence.jsonl").exists() or (folder / "sequence.capture.json").exists():
    raise FileExistsError("本轮连续往返已经开始或完成")
latch.acknowledge_stop(expected_sha256=sha256(content).hexdigest(), archive_path=folder / "stop-after-review.json")
print("本轮有限范围启动审查完成；原停止原因与研究限制均已保存。")

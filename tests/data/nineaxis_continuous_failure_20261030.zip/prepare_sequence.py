from dataclasses import asdict, replace
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
from robot_static_fcl import Body

from robot_safecontrol_moveit.drempower_joint_control import JointFeedback
from robot_safecontrol_moveit.joint_positioning import positioning_limits
from robot_safecontrol_moveit.joint_table_commissioning import stationary_noise
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.motor_motion_limits import MotionBounds
from robot_safecontrol_moveit.positioning_plan import _CommonTrajectory, _common_progress
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import ObservedFeedback, VelocityWindow, stationary_conditions
from work.kinematics_data import JOINT_CHAIN
from work.nineaxis_kinematics import NineaxisKinematics
from work.nineaxis_model import NineaxisModel
from work.robot_units import joints_mm_deg_to_si, joints_si_to_mm_deg
from work.static_collision import distance_between
from work.static_collision_meshes import load_meshes, mesh_sources
from work.static_motion import MotionPlanner


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
model = NineaxisModel.load(root=root)
control = JointTableControl(root)
policy_path = root / ".scratch/motor_control/attended-positioning.json"
policy_content = policy_path.read_bytes()
policy = json.loads(policy_content)
sources = {}
for name in ("preflight", "operating-preflight"):
    data = (folder / f"{name}.json").read_bytes()
    original = json.loads(data)
    replay = replay_readonly_report(data)
    if original["status"] != "readonly_completed" or replay["status"] != "replayed_completed":
        raise ValueError("连续往返需要完整的设备原始读取")
    if original["configuration_sha256"] != policy["config_hashes"]:
        raise ValueError("当前原始读取与现场坐标配置身份不同")
    for config_name, digest in original["configuration_sha256"].items():
        if sha256((root / "config" / config_name).read_bytes()).hexdigest() != digest:
            raise ValueError("当前设备坐标配置文件变化")
    sources[name] = {"data": original, "replay": replay, "sha256": sha256(data).hexdigest()}
if model.model_hash != policy["model_hash"]:
    raise ValueError("本轮共同模型与现场记录不同")
if sha256((root / ".scratch/motor_control/stop.json").read_bytes()).hexdigest() != policy["reviewed_stop_sha256"]:
    raise ValueError("主停止原因变化")
if policy["conditions"] != {"motion_area_empty": True, "operator_attended": True,
                            "powered_holding_only": True, "return_zero_on_confirmation": True}:
    raise ValueError("现场基本条件与本次记录不符")
encoder = sources["preflight"]["data"]
operating = sources["operating-preflight"]["data"]
for joint in DEFAULT_JOINT_NAMES:
    for source in (encoder, operating):
        values = source["properties"][joint]
        if values["node_id"] != control._node(joint) or values["axis_state"] != 8 or any(values[name] for name in (
                "axis_error", "can_error", "motor_error", "encoder_error", "controller_error")):
            raise ValueError(f"{joint} 当前设备身份、闭环状态或故障无效")
    values = operating["properties"][joint]
    if (values["control_mode"] != 3 or values["input_mode"] != 5 or values["trajectory_done"] != 1
            or values["can_baud_rate"] != 500000 or values["traj_mode"] != 1):
        raise ValueError(f"{joint} 当前输入模式、轨迹或通信配置不符")
    if encoder["properties"][joint]["zero_offset_counts"] != sources["preflight"]["replay"]["nodes"][str(control._node(joint))]["zero_offset_counts"]:
        raise ValueError("原始零位记录不一致")
j1 = encoder["properties"]["J1"]
if (j1["zero_offset_counts"] != policy["expected_j1_zero_offset_counts"]
        or j1["serial_number_l"] != policy["expected_j1_serial_number_l"] or j1["encoder_turn_abs"] != -57):
    raise ValueError("J1 非零参考、设备身份或零位发生变化")
noise = stationary_noise(root, root / policy["noise_evidence_path"],
                         policy["noise_evidence_sha256"], model.model_hash)
limits = positioning_limits(root, dict(zip(DEFAULT_JOINT_NAMES, [.05, *([.3] * 8)])),
                            dict(zip(DEFAULT_JOINT_NAMES, [.01, *([.3] * 8)])))
for joint, limit in limits.items():
    bounds = None if joint == "J1" else MotionBounds(limit.speed_rpm, limit.accel_rpm_s, 5 / 6,
                                                    sha256(policy_content).hexdigest())
    limits[joint] = replace(limit, stationary_window_s=5., stationary_velocity_noise_rpm=noise[joint],
                            bounds=bounds, max_feedback_rpm=limit.max_feedback_rpm if bounds is None else 5 / 6)
windows = {joint: VelocityWindow(1., 5.) for joint in DEFAULT_JOINT_NAMES}
latest = {}
for row in operating["samples"][9:]:
    joint = row["joint"]
    observed = windows[joint].add(ObservedFeedback(
        **{name: value for name, value in row.items() if name not in ("joint", "state")},
        state=JointFeedback(**row["state"])))
    latest[joint] = observed
if not all(all(stationary_conditions(latest[joint], limits[joint]).values()) and latest[joint].traj_done
           and not latest[joint].axis_error for joint in DEFAULT_JOINT_NAMES):
    raise ValueError("当前九轴没有取得持续五秒的静止证据")
initial = joints_mm_deg_to_si([control.project_position(joint, sample.state.angle_deg)
                               for joint, sample in latest.items()])
delta_mm_deg = [.5, -.15, .12, -.15, .12, -.12, .3, .4, .5]
target = initial + joints_mm_deg_to_si(delta_mm_deg)
lower = joints_mm_deg_to_si([.8, *([-.15] * 8)])
upper = joints_mm_deg_to_si([1.7, *([.15] * 5), .65, .75, .85])
allowance = joints_mm_deg_to_si([.01 / 72, *([.01] * 8)])
if np.any(np.minimum(initial, target) - allowance < lower) or np.any(np.maximum(initial, target) + allowance > upper):
    raise ValueError("本轮往返及反馈范围超出完整自身几何检查范围")
sources_mesh = mesh_sources(root / "portable_oscbf/config/collision_geometry_sources.json")
meshes = load_meshes(sources_mesh)
center, radius = (lower + upper) / 2, (upper - lower) / 2
transforms = NineaxisKinematics().forward_kinematics(center)
bodies = []
for mesh in meshes:
    body = Body.convex(mesh.vertices, mesh.faces)
    transform = transforms[mesh.link]
    body.set_transform(transform[:3, :3], transform[:3, 3])
    bodies.append(body)
offsets = np.array([np.linalg.norm(row[3:6]) for row in JOINT_CHAIN if row[2] in ("prismatic", "revolute")])
distances = []
for first, second in sources_mesh["pairs"]:
    coefficients = np.zeros(9)
    coefficients[0] = 1
    for joint in range(1, second):
        coefficients[joint] = np.sum(offsets[joint + 1:second]) + meshes[second].radius_m
    coefficients[:first] = 0
    distance = distance_between(bodies[first], bodies[second])
    margin = distance.distance_m - float(coefficients @ radius) - .01
    if not distance.valid or margin <= 0:
        raise ValueError("本轮连续往返的完整自身几何范围未证明")
    distances.append({"pair": [meshes[first].link, meshes[second].link], "interval_margin_m": margin})
planner = MotionPlanner(model.position_lower, model.position_upper,
                        joints_mm_deg_to_si([.05, *([.3] * 8)]),
                        joints_mm_deg_to_si([.01, *([.3] * 8)]), jerk_time=.08, minimum_duration_s=30.)
forward, backward = _CommonTrajectory(initial, target, planner), _CommonTrajectory(target, initial, planner)
for trajectory in (forward, backward):
    _common_progress(trajectory, trajectory.initial, trajectory.target)
    for point in np.linspace(0, trajectory.duration, 1001):
        q, velocity, acceleration = trajectory.at_time(point)
        if (np.any(q < lower) or np.any(q > upper) or np.any(np.abs(velocity) > planner.max_velocity + 1e-12)
                or np.any(np.abs(acceleration) > planner.max_acceleration + 1e-12)):
            raise ValueError("共同参考范围、速度或加速度无效")
if any(not np.array_equal(a, b) for a, b in zip(forward.at_time(forward.duration), backward.at_time(0))):
    raise ValueError("共同参考往返的连接点不连续")
stop_path = root / ".scratch/motor_control/attended-positioning-stop.json"
stop_content = stop_path.read_bytes()
stop = json.loads(stop_content)
if stop["reason"] != "supported_power_cycle_review_completed_motion_requires_startup_review":
    raise ValueError("本轮待审查停止原因变化")
report = {
    "scope": "attended_nineaxis_small_relative_continuous_roundtrip", "status": "prepared",
    "initial_mm_deg": joints_si_to_mm_deg(initial).tolist(), "delta_mm_deg": delta_mm_deg,
    "target_mm_deg": joints_si_to_mm_deg(target).tolist(), "lower_si": lower.tolist(), "upper_si": upper.tolist(),
    "forward_duration_s": forward.duration, "return_duration_s": backward.duration,
    "reference_connection_c2_verified": True, "whole_box_self_collision": distances,
    "self_collision_sources": sources_mesh, "model_hash": model.model_hash,
    "configuration_sha256": policy["config_hashes"], "policy_sha256": sha256(policy_content).hexdigest(),
    "reviewed_stop": stop, "reviewed_stop_sha256": sha256(stop_content).hexdigest(),
    "readonly_source_sha256": {name: row["sha256"] for name, row in sources.items()},
    "startup_feedback": {joint: asdict(sample) for joint, sample in latest.items()},
    "user_statement": "固定已解除，支撑不妨碍运动，可以持续看护",
    "startup_actions": "完整九轴当前姿态低速位置命令及速度、加速度独立回读",
    "return_to_zero_requested": False, "motion_commands_sent": 0,
    "hardware_qualified": False, "absolute_coordinate_qualification": False,
    "physical_stop_independently_verified": False, "external_scene_checked": False,
    "source_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
}
with (folder / "sequence-review.json").open("x", encoding="utf-8") as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write("\n")
with (folder / "stop-before-review.json").open("xb") as stream:
    stream.write(stop_content)
print(json.dumps({"initial_mm_deg": report["initial_mm_deg"], "target_mm_deg": report["target_mm_deg"],
                  "duration_s": forward.duration + backward.duration,
                  "minimum_self_margin_mm": min(row["interval_margin_m"] for row in distances) * 1000,
                  "hardware_stop_unchanged": True}, ensure_ascii=False, indent=2))

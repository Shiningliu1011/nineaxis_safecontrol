import argparse
from dataclasses import asdict, dataclass
from datetime import datetime
from hashlib import sha256
import json
from math import isclose
from pathlib import Path
import time
from zoneinfo import ZoneInfo

import numpy as np

from robot_safecontrol_moveit.attended_positioning import AttendedPositioning
from robot_safecontrol_moveit.drempower_serial import DrEmpowerSerial
from robot_safecontrol_moveit.joint_positioning import positioning_limits, single_target_table
from robot_safecontrol_moveit.joint_table_execution import JointTableControl, JointTableExecutor
from robot_safecontrol_moveit.positioning_plan import _CommonTrajectory, _common_progress
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import (
    ArrivalWindow, MotionRejected, SingleJointMonitor, VendorFeedbackReader, VelocityWindow, stationary_conditions,
)
from work.nineaxis_model import NineaxisModel
from work.robot_units import joints_mm_deg_to_si
from work.static_motion import MotionPlanner


@dataclass(frozen=True)
class ProbeHardware:
    vendor: DrEmpowerSerial
    executor: JointTableExecutor


def reference_at_time(forward, backward, elapsed_s):
    return (forward.at_time(elapsed_s) if elapsed_s <= forward.duration
            else backward.at_time(elapsed_s - forward.duration))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    folder = Path(__file__).parent
    review_path = folder / "sequence-review.json"
    review_content = review_path.read_bytes()
    review = json.loads(review_content)
    for name, digest in review["readonly_source_sha256"].items():
        if sha256((folder / f"{name}.json").read_bytes()).hexdigest() != digest:
            raise ValueError("本轮原始读取身份变化")
    for name, digest in review["configuration_sha256"].items():
        if sha256((root / "config" / name).read_bytes()).hexdigest() != digest:
            raise ValueError("本轮设备坐标配置变化")
    policy_path = root / ".scratch/motor_control/attended-positioning.json"
    if sha256(policy_path.read_bytes()).hexdigest() != review["policy_sha256"]:
        raise ValueError("本轮现场记录变化")
    model = NineaxisModel.load(root=root)
    if model.model_hash != review["model_hash"]:
        raise ValueError("本轮共同模型变化")
    initial, target = (joints_mm_deg_to_si(review[name]) for name in ("initial_mm_deg", "target_mm_deg"))
    lower, upper = np.asarray(review["lower_si"]), np.asarray(review["upper_si"])
    planner = MotionPlanner(model.position_lower, model.position_upper,
                            joints_mm_deg_to_si([.05, *([.3] * 8)]),
                            joints_mm_deg_to_si([.01, *([.3] * 8)]), jerk_time=.08, minimum_duration_s=30.)
    forward, backward = _CommonTrajectory(initial, target, planner), _CommonTrajectory(target, initial, planner)
    for trajectory in (forward, backward):
        _common_progress(trajectory, trajectory.initial, trajectory.target)
    duration = forward.duration + backward.duration
    if (forward.duration != review["forward_duration_s"] or backward.duration != review["return_duration_s"]
            or duration < 60 or min(row["interval_margin_m"] for row in review["whole_box_self_collision"]) <= 0):
        raise ValueError("本轮参考或完整自身几何检查无效")
    if args.check_only:
        print(json.dumps({"duration_s": duration, "all_nine_axes_moving": bool(np.all(target != initial)),
                          "reference_connection_c2_verified": review["reference_connection_c2_verified"]}))
        return
    log_path, capture_path = folder / "sequence.jsonl", folder / "sequence.capture.json"
    if log_path.exists() or capture_path.exists():
        raise FileExistsError("本轮连续往返原始输出已经存在")
    control = JointTableControl(root)
    table = single_target_table(dict(zip(DEFAULT_JOINT_NAMES, review["target_mm_deg"])), model)
    port = "/dev/serial/by-id/usb-Dr-Tech_DR-USB_CAN_87949380174B-if00"
    session = AttendedPositioning.load(
        root, policy_path, table, model, port=port,
        limits=positioning_limits(root, dict(zip(DEFAULT_JOINT_NAMES, [.05, *([.3] * 8)])),
                                  dict(zip(DEFAULT_JOINT_NAMES, [.01, *([.3] * 8)]))))
    executor = JointTableExecutor(table, model, measurement_kind="positioning", task_id="issue-186-nineaxis-roundtrip",
                                  feedback_source="hardware_feedback", limits=session.limits, manual_positioning=True)
    capture = {
        "status": "prepared", "started_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
        "scope": review["scope"], "review_sha256": sha256(review_content).hexdigest(), "review": review,
        "source_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "initial_mm_deg": review["initial_mm_deg"], "target_mm_deg": review["target_mm_deg"],
        "forward_duration_s": forward.duration, "return_duration_s": backward.duration,
        "hardware_qualified": False, "independent_physical_precision_verified": False,
        "physical_stop_independently_verified": False, "device_sample_time_known": False,
        "parameter_writes_sent": 0, "return_to_zero_requested": False,
        "backend_sha256": sha256((root / "src/robot_safecontrol_moveit/drempower_serial.py").read_bytes()).hexdigest(),
    }
    windows = {joint: VelocityWindow(1., 5.) for joint in DEFAULT_JOINT_NAMES}
    monitors = {joint: SingleJointMonitor(index + 1, session.limits[joint]) for index, joint in enumerate(DEFAULT_JOINT_NAMES)}
    with log_path.open("x", encoding="utf-8") as log:
        def record(event, **fields):
            log.write(json.dumps({"event": event, "monotonic_s": time.monotonic(), **fields},
                                 ensure_ascii=False, allow_nan=False) + "\n")
            log.flush()

        with DrEmpowerSerial(port, position_nodes={1: "prismatic", **{node: "revolute" for node in range(2, 10)}},
                            tracking_probe=True) as vendor:
            reader = VendorFeedbackReader(vendor, control, .2)

            def observe():
                session.check_stop()
                observed = {}
                positions = []
                for joint in DEFAULT_JOINT_NAMES:
                    reader.require_closed_loop(joint)
                    sample = windows[joint].add(reader.read(joint))
                    if sample.window_duration_s < 1:
                        monitors[joint].validate_hold_feedback(sample, time.monotonic())
                    else:
                        monitors[joint].validate_feedback(sample, time.monotonic())
                    observed[joint] = sample
                    positions.append(control.project_position(joint, sample.state.angle_deg))
                q = joints_mm_deg_to_si(positions)
                if np.any(q < lower) or np.any(q > upper):
                    raise MotionRejected("outside_complete_nineaxis_roundtrip_self_interval")
                if max(time.monotonic() - row.request_s for row in observed.values()) > .2:
                    raise MotionRejected("nineaxis_feedback_timeout")
                record("feedback", samples={joint: asdict(sample) for joint, sample in observed.items()})
                return observed

            def read_operating():
                return {node: {"bandwidth": vendor.read_property(node, 32118, "f32"),
                               "input_mode": vendor.read_property(node, 32106),
                               "control_mode": vendor.read_property(node, 32105)} for node in range(1, 10)}

            def wait_stationary():
                until = time.monotonic() + 12
                while True:
                    observed = observe()
                    if all(all(stationary_conditions(row, session.limits[joint]).values()) and row.traj_done
                           for joint, row in observed.items()):
                        return observed
                    if time.monotonic() > until:
                        raise MotionRejected("initial_nineaxis_not_stationary")
                    time.sleep(.02)

            attempted = False
            try:
                for node in range(1, 10):
                    vendor.prepare_motion(node)
                capture["device_properties"] = session.verify_device(ProbeHardware(vendor, executor))
                original_operating = read_operating()
                if any(row["input_mode"] != 5 or row["control_mode"] != 3 for row in original_operating.values()):
                    raise MotionRejected("initial_operating_modes_invalid")
                capture["original_operating_properties"] = original_operating
                observed = wait_stationary()
                for index, joint in enumerate(DEFAULT_JOINT_NAMES):
                    if abs(observed[joint].state.angle_deg - control.target_deg(joint, initial[index])) > .01:
                        raise MotionRejected("current_pose_differs_from_reviewed_small_relative_start")
                attempted = True
                for joint in DEFAULT_JOINT_NAMES:
                    arguments = control.position_arguments(joint, observed[joint].state.angle_deg, session.limits[joint])
                    record("low_speed_seed_requested", joint=joint, arguments=arguments)
                    vendor.set_angle(**arguments)
                configured = {}
                for node, joint in enumerate(DEFAULT_JOINT_NAMES, 1):
                    expected = session.limits[joint]
                    values = {name: vendor.read_property(node, address, "f32") for name, address in (
                        ("speed", 38014), ("acceleration", 38015), ("deceleration", 38016))}
                    if (not isclose(values["speed"], expected.speed_rpm, rel_tol=1e-5, abs_tol=1e-6)
                            or any(not isclose(values[name], expected.accel_rpm_s, rel_tol=1e-5, abs_tol=1e-6)
                                   for name in ("acceleration", "deceleration"))):
                        raise MotionRejected(f"{joint}_explicit_low_speed_parameters_not_adopted")
                    configured[joint] = values
                capture["low_speed_parameters_verified"] = configured
                observed = wait_stationary()
                record("continuous_roundtrip_requested", duration_s=duration)
                start = time.monotonic()
                capture["reference_start_monotonic_s"] = start
                index, reversed_reported = 0, False
                while True:
                    time.sleep(max(0., start + index * .05 - time.monotonic()))
                    elapsed = time.monotonic() - start
                    q, velocity, acceleration = reference_at_time(forward, backward, elapsed)
                    if (np.any(q < lower) or np.any(q > upper) or np.any(np.abs(velocity) > planner.max_velocity + 1e-12)
                            or np.any(np.abs(acceleration) > planner.max_acceleration + 1e-12)):
                        raise MotionRejected("continuous_reference_outside_reviewed_bounds")
                    targets = {node: control.target_deg(joint, q[node - 1])
                               for node, joint in enumerate(DEFAULT_JOINT_NAMES, 1)}
                    record("tracking_reference", time_s=elapsed, q_si=q.tolist(),
                           velocity_si=velocity.tolist(), acceleration_si=acceleration.tolist())
                    record("tracking_broadcast", **vendor.set_tracking_probe(targets))
                    observed = observe()
                    if not reversed_reported and elapsed >= forward.duration:
                        reversed_reported = True
                        record("reference_reversal", time_s=elapsed)
                        print("九轴共同参考已连续进入返回段。", flush=True)
                    index += 1
                    if elapsed >= duration + 6:
                        break
                record("tracking_reference_finished", elapsed_s=time.monotonic() - start)
                time.sleep(max(0., start + index * .05 - time.monotonic()))
                hold_targets = {node: vendor.motor_state[node - 1][0] for node in range(1, 10)}
                record("restore_bandwidths", **vendor.set_tracking_probe(
                    hold_targets, restore_bandwidths={node: row["bandwidth"] for node, row in original_operating.items()}))
                observe()
                arrivals = {}
                for node, joint in enumerate(DEFAULT_JOINT_NAMES, 1):
                    target_deg = control.target_deg(joint, initial[node - 1])
                    arrivals[joint] = ArrivalWindow(target_deg, session.limits[joint])
                    arguments = control.position_arguments(joint, target_deg, session.limits[joint])
                    record("terminal_hold_requested", joint=joint, arguments=arguments)
                    vendor.set_angle(**arguments)
                hold_started = time.monotonic()
                while True:
                    observed = observe()
                    stable = {joint: arrivals[joint].observe(row, time.monotonic()) for joint, row in observed.items()}
                    if all(stable.values()) and time.monotonic() - hold_started >= 5.5:
                        break
                    if time.monotonic() - hold_started > 15:
                        raise MotionRejected("continuous_roundtrip_terminal_hold_not_confirmed")
                    time.sleep(.02)
                capture["restored_operating_properties"] = read_operating()
                if capture["restored_operating_properties"] != original_operating:
                    raise MotionRejected("continuous_roundtrip_original_modes_not_restored")
                capture["final_device_properties"] = session.verify_device(ProbeHardware(vendor, executor))
                capture.update(status="completed", completed_after_reference_s=time.monotonic() - start,
                               final_feedback={joint: asdict(row) for joint, row in observed.items()})
                record("completed", elapsed_s=time.monotonic() - start)
                session.stop_latch.trip(reason="bounded_nineaxis_continuous_roundtrip_completed", log_path=log_path)
                print("九轴连续往返完成，全部返回本轮起点并取得持续静止反馈。", flush=True)
            except BaseException as error:
                capture.update(status="aborted", reason=str(error))
                if attempted:
                    try:
                        current = observe()
                        stopping = {joint: ArrivalWindow(row.state.angle_deg, session.limits[joint])
                                    for joint, row in current.items()}
                        for joint, row in current.items():
                            arguments = control.position_arguments(joint, row.state.angle_deg, session.limits[joint])
                            record("abort_hold_requested", joint=joint, arguments=arguments)
                            vendor.set_angle(**arguments)
                        until = time.monotonic() + 20
                        while True:
                            stopped = observe()
                            stable = {joint: stopping[joint].observe(row, time.monotonic())
                                      for joint, row in stopped.items()}
                            if all(stable.values()):
                                capture["stop_result"] = "hold_observed"
                                break
                            if time.monotonic() > until:
                                raise MotionRejected("continuous_roundtrip_abort_hold_not_confirmed")
                            time.sleep(.02)
                    except BaseException as stop_error:
                        capture.update(stop_result="external_stop_required", stop_error=str(stop_error))
                        print("无法确认停止，请立即操作现场急停。", flush=True)
                session.stop_latch.trip(reason=str(error), log_path=log_path)
                record("aborted", reason=str(error), stop_result=capture.get("stop_result", "no_motion_attempted"))
                raise
            finally:
                capture["frames"] = vendor.frames
                capture["log_sha256"] = sha256(log_path.read_bytes()).hexdigest()
                with capture_path.open("x", encoding="utf-8") as stream:
                    json.dump(capture, stream, ensure_ascii=False, indent=2, allow_nan=False)
                    stream.write("\n")


if __name__ == "__main__":
    main()

import argparse
from bisect import bisect_left
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path

from robot_safecontrol_moveit.drempower_joint_control import JointFeedback
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import ObservedFeedback
from robot_safecontrol_moveit.tracking_log_replay import _match_commands, _raw_tracking


parser = argparse.ArgumentParser()
parser.add_argument("--run", required=True)
parser.add_argument("--held", type=Path, required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
log_source = (folder / f"{args.run}.jsonl").read_bytes()
frames_source = (folder / f"{args.run}.frames.json").read_bytes()
report = json.loads((folder / f"{args.run}.report.json").read_bytes())
events = [json.loads(line) for line in log_source.splitlines()]
control = JointTableControl(root)
trace = _raw_tracking({"frames": json.loads(frames_source), "status": report["phase"]}, control)
normalized = [{**row, "event": "low_speed_seed_requested"} if row["event"] == "command_requested"
              else row for row in events]
_match_commands(normalized, trace, control)
if (report["phase"] != "aborted" or report["termination"]["stop_result"] != "hold_observed"
        or len(trace["positions"]) != 18 or trace["broadcasts"]
        or set(trace["tx_commands"]) != {"0x1a", "0x1e"}):
    raise ValueError("定位及保持命令范围或终态无效")
by_joint = {joint: [row for row in trace["feedback"] if row["joint"] == joint] for joint in DEFAULT_JOINT_NAMES}
times = {joint: [row["received_s"] for row in rows] for joint, rows in by_joint.items()}
matched = set()
for event in events:
    samples = (event["samples"] if event["event"] == "feedback"
               else {event["joint"]: event["sample"]} if event["event"] == "hold_feedback" else {})
    for joint, value in samples.items():
        index = bisect_left(times[joint], value["request_s"])
        raw = by_joint[joint][index]
        sample = ObservedFeedback(raw["node_id"], JointFeedback(**raw["state"]),
                                  value["request_s"], value["received_s"], raw["traj_done"], raw["axis_error"])
        names = asdict(sample)
        if (any(value[name] != expected for name, expected in names.items() if expected is not None and name not in (
                "window_duration_s", "stationary_window_duration_s"))
                or not value["request_s"] <= raw["received_s"] <= value["received_s"]
                or raw["raw_frame_index"] in matched):
            raise ValueError("定位反馈与原始回复不符")
        matched.add(raw["raw_frame_index"])
held_source = args.held.read_bytes()
held = replay_readonly_report(held_source)
if held["status"] != "replayed_completed" or len(held["nodes"]) != 9:
    raise ValueError("动作后读取不完整")
for values in held["nodes"].values():
    if values["axis_state"] != 8 or any(values[name] for name in (
            "axis_error", "can_error", "motor_error", "encoder_error", "controller_error")):
        raise ValueError("动作后设备状态无效")
start = next(row["monotonic_s"] for row in events if row["event"] == "command_requested")
hold = next(row["monotonic_s"] for row in events if row["event"] == "hold_requested")
metrics = {}
for joint, rows in by_joint.items():
    moving = [row for row in rows if row["received_s"] >= start]
    metrics[joint] = {"unit": "mm" if joint == "J1" else "deg", "initial": rows[0]["position"],
                      "final": rows[-1]["position"], "minimum": min(row["position"] for row in moving),
                      "maximum": max(row["position"] for row in moving),
                      "maximum_target_error": max(abs(row["position"] - report["attempts"][0]["target_mm_deg"][
                          DEFAULT_JOINT_NAMES.index(joint)]) for row in moving)}
result = {"status": "original_positioning_and_hold_verified", "termination": report["termination"],
          "target_mm_deg": report["attempts"][0]["target_mm_deg"], "metrics": metrics,
          "motion_before_hold_s": hold - start, "hold_observation_s": events[-1]["monotonic_s"] - hold,
          "matched_samples": len(matched), "raw_feedback_samples": len(trace["feedback"]),
          "tx_commands": trace["tx_commands"], "position_commands": len(trace["positions"]),
          "journal_sha256": sha256(log_source).hexdigest(), "frames_sha256": sha256(frames_source).hexdigest(),
          "held_readonly_sha256": sha256(held_source).hexdigest(), "device_sample_time_known": False,
          "physical_stop_independently_verified": False, "independent_physical_precision_verified": False}
with (folder / f"{args.run}-validation.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps(result, ensure_ascii=False, indent=2))

import argparse
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
from robot_static_fcl import Body

from robot_safecontrol_moveit.joint_positioning import positioning_limits, single_target_table
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from work.kinematics_data import JOINT_CHAIN
from work.nineaxis_kinematics import NineaxisKinematics
from work.nineaxis_model import NineaxisModel
from work.robot_units import joints_mm_deg_to_si, joints_si_to_mm_deg
from work.static_collision import distance_between
from work.static_collision_meshes import load_meshes, mesh_sources


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
parser = argparse.ArgumentParser()
parser.add_argument("--source", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--joints", type=float, nargs=9, required=True)
args = parser.parse_args()
model = NineaxisModel.load(root=root)
control = JointTableControl(root)
source = args.source.read_bytes()
captured = json.loads(source)
replayed = replay_readonly_report(source)
if captured["status"] != "readonly_completed" or replayed["status"] != "replayed_completed":
    raise ValueError("定位预检查需要完整原始设备读取")
for joint in DEFAULT_JOINT_NAMES:
    values = captured["properties"][joint]
    if values["node_id"] != control._node(joint) or values["axis_state"] != 8 or any(
            values[name] for name in ("axis_error", "can_error", "motor_error", "encoder_error", "controller_error")):
        raise ValueError(f"{joint} 当前设备状态无效")
initial = joints_mm_deg_to_si([
    control.project_position(joint, captured["samples"][-9 + index]["state"]["angle_deg"])
    for index, joint in enumerate(DEFAULT_JOINT_NAMES)])
target_values = args.joints
target = joints_mm_deg_to_si(target_values)
table = single_target_table(dict(zip(DEFAULT_JOINT_NAMES, target_values)), model)
speeds = dict(zip(DEFAULT_JOINT_NAMES, [.25, *([2.46] * 8)]))
accelerations = dict(zip(DEFAULT_JOINT_NAMES, [.05, *([.3] * 8)]))
limits = positioning_limits(root, speeds, accelerations)
allowance = joints_mm_deg_to_si([1.001, *([.11] * 8)])
lower, upper = np.minimum(initial, target) - allowance, np.maximum(initial, target) + allowance
sources = mesh_sources(root / "portable_oscbf/config/collision_geometry_sources.json")
meshes = load_meshes(sources)
center, radius = (lower + upper) / 2, (upper - lower) / 2
transforms = NineaxisKinematics().forward_kinematics(center)
bodies = []
for mesh in meshes:
    body = Body.convex(mesh.vertices, mesh.faces)
    transform = transforms[mesh.link]
    body.set_transform(transform[:3, :3], transform[:3, 3])
    bodies.append(body)
offsets = np.array([np.linalg.norm(row[3:6]) for row in JOINT_CHAIN if row[2] in ("prismatic", "revolute")])
distances = []
for first, second in sources["pairs"]:
    coefficients = np.zeros(9)
    coefficients[0] = 1
    for joint in range(1, second):
        coefficients[joint] = np.sum(offsets[joint + 1:second]) + meshes[second].radius_m
    coefficients[:first] = 0
    pending = [(lower.copy(), upper.copy())]
    accepted = []
    checked = 0
    while pending:
        cell_lower, cell_upper = pending.pop()
        midpoint = (cell_lower + cell_upper) / 2
        cell_radius = (cell_upper - cell_lower) / 2
        transforms = NineaxisKinematics().forward_kinematics(midpoint)
        for index in (first, second):
            transform = transforms[meshes[index].link]
            bodies[index].set_transform(transform[:3, :3], transform[:3, 3])
        distance = distance_between(bodies[first], bodies[second])
        checked += 1
        if not distance.valid or distance.distance_m <= .01 or checked > 4096:
            raise ValueError(f"{meshes[first].link}/{meshes[second].link} 定位范围检查未通过")
        margin = distance.distance_m - float(coefficients @ cell_radius) - .01
        if margin > 0:
            accepted.append({"lower_si": cell_lower.tolist(), "upper_si": cell_upper.tolist(),
                             "interval_margin_m": margin})
            continue
        split = int(np.argmax(coefficients * cell_radius))
        if cell_radius[split] <= 1e-7:
            raise ValueError("定位范围的连续间距未证明")
        left_upper, right_lower = cell_upper.copy(), cell_lower.copy()
        left_upper[split] = right_lower[split] = midpoint[split]
        pending.extend(((cell_lower, left_upper), (right_lower, cell_upper)))
    distances.append({"pair": [meshes[first].link, meshes[second].link],
                      "interval_margin_m": min(cell["interval_margin_m"] for cell in accepted),
                      "checked_cells": checked, "accepted_cells": accepted})
report = {
    "scope": "attended_native_single_group_positioning",
    "initial_mm_deg": joints_si_to_mm_deg(initial).tolist(), "target_mm_deg": target_values,
    "lower_si": lower.tolist(), "upper_si": upper.tolist(), "whole_box_self_collision": distances,
    "model_hash": model.model_hash, "table_sha256": table.source_sha256,
    "configuration_sha256": captured["configuration_sha256"],
    "readonly_sha256": sha256(source).hexdigest(),
    "reviewed_stop_sha256": (sha256((root / ".scratch/motor_control/attended-positioning-stop.json").read_bytes()).hexdigest()
                             if (root / ".scratch/motor_control/attended-positioning-stop.json").exists() else None),
    "speed_mm_deg_s": list(speeds.values()), "acceleration_mm_deg_s2": list(accelerations.values()),
    "preview": table.preview(model, measurement_kind="positioning", execution_limits=limits),
    "source_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
    "independent_precision_verified": False, "independent_stop_verified": False,
    "motion_commands_sent": 0, "parameter_writes_sent": 0,
}
with args.output.open("x", encoding="utf-8") as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps({"initial_mm_deg": report["initial_mm_deg"], "target_mm_deg": target_values,
                  "minimum_self_margin_mm": min(row["interval_margin_m"] for row in distances) * 1000,
                  "commands": len(report["preview"]["rows"][0]["device_commands"])}, ensure_ascii=False))

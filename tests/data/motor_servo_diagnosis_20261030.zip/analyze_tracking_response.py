from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
from statistics import mean

from robot_safecontrol_moveit.drempower_can import decode_feedback
from robot_safecontrol_moveit.drempower_serial import SERIAL_CAN_FRAME
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.tracking_log_replay import _raw_tracking, replay_tracking_capture


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
capture_bytes = (folder / "nineaxis-roundtrip-02.capture.json").read_bytes()
log_bytes = (folder / "nineaxis-roundtrip-02.jsonl").read_bytes()
verified = replay_tracking_capture(log_bytes, capture_bytes, root)
capture = json.loads(capture_bytes)
events = [json.loads(line) for line in log_bytes.splitlines()]
trace = _raw_tracking(capture, JointTableControl(root))
start = next(row["monotonic_s"] for row in events if row["event"] == "continuous_roundtrip_requested")
rows = defaultdict(list)
for original in trace["feedback"]:
    frame = SERIAL_CAN_FRAME.parse(bytes.fromhex(original["raw_hex"]))
    feedback = decode_feedback(frame.frame_id, frame.data)
    previous = capture["frames"][original["raw_frame_index"] - 1]
    request = SERIAL_CAN_FRAME.parse(bytes.fromhex(previous["raw_hex"]))
    row = {key: original[key] for key in ("position", "reference", "reference_source", "raw_frame_index", "received_s")}
    row.update(elapsed_s=original["received_s"] - start,
               reported_speed_rpm=original["state"]["speed_rpm"],
               device_torque_nm=feedback.torque_nm,
               reply_to_command=f"0x{request.frame_id & 0x1f:02x}",
               error=None if original["reference"] is None else original["position"] - original["reference"])
    rows[original["joint"]].append(row)

report = {
    "validation_scope": "original_device_response_timeline",
    "capture_sha256": sha256(capture_bytes).hexdigest(),
    "log_sha256": sha256(log_bytes).hexdigest(),
    "capture_status": verified["capture_status"],
    "hardware_qualified": False,
    "time_basis": "host_receive_minus_continuous_roundtrip_requested",
    "device_sample_time_known": False,
    "joints": {},
}
for joint, samples in rows.items():
    checkpoints = []
    for target in (-4., -1., -.2, 0., .1, .2, .5, 1., 2., 5., 10., 15., 20., 25., 26.15):
        nearest = min(samples, key=lambda row: abs(row["elapsed_s"] - target))
        local = [row for row in samples if abs(row["elapsed_s"] - target) <= .25]
        checkpoints.append({
            "requested_time_s": target,
            "nearest_original": nearest,
            "window_samples": len(local),
            "mean_position": mean(row["position"] for row in local) if local else None,
            "mean_device_torque_nm": mean(row["device_torque_nm"] for row in local) if local else None,
        })
    moving = [row for row in samples if row["reference_source"] == "host_broadcast"]
    report["joints"][joint] = {
        "unit": "mm" if joint == "J1" else "deg",
        "checkpoints": checkpoints,
        "maximum_error_sample": max(moving, key=lambda row: abs(row["error"])),
        "minimum_position_sample": min(moving, key=lambda row: row["position"]),
        "maximum_position_sample": max(moving, key=lambda row: row["position"]),
        "maximum_absolute_device_torque_nm": max(abs(row["device_torque_nm"]) for row in moving),
    }

with (folder / "tracking-response-timeline.json").open("x", encoding="utf-8") as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write("\n")
for joint in ("J2", "J3", "J4", "J5", "J6"):
    print(joint)
    for checkpoint in report["joints"][joint]["checkpoints"]:
        row = checkpoint["nearest_original"]
        print(f"t={row['elapsed_s']:.3f} position={row['position']:.6f} "
              f"reference={row['reference']} error={row['error']} "
              f"torque={checkpoint['mean_device_torque_nm']:.4f}")

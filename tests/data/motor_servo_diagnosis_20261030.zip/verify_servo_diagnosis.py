from hashlib import sha256
import json
from pathlib import Path
import runpy
from statistics import mean

from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.joint_table_readonly import OPERATING_PROPERTIES, SERVO_PROPERTIES, replay_readonly_report
from robot_safecontrol_moveit.tracking_log_replay import replay_tracking_capture


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
vendor_path = root / "大然电机/大然电机所有资料/drempower-wiki-master/4-库函数/python/linux-socketcan/interface_enums.py"
vendor = runpy.run_path(str(vendor_path))
vendor_fields = {address: (name, vendor["property_type"][name])
                 for name, address in vendor["property_addresss"].items()}
fields = {}
for name, (address, kind) in SERVO_PROPERTIES.items():
    if name in OPERATING_PROPERTIES:
        continue
    source_name, source_kind = vendor_fields[address]
    if kind != "f32" or source_kind != "f":
        raise ValueError("伺服诊断字段与厂家枚举类型不符")
    fields[name] = {"address": address, "kind": kind, "manufacturer_name": source_name}
report = {
    "scope": "readonly_servo_and_original_motion_diagnosis",
    "hardware_qualified": False, "physical_cause_confirmed": False,
    "motion_commands_sent": 0, "parameter_writes_sent": 0,
    "manufacturer_enum_sha256": sha256(vendor_path.read_bytes()).hexdigest(),
    "servo_fields": fields, "captures": {},
}
control = JointTableControl(root)
for name in ("post-estop-operating", "post-estop-servo", "post-estop-servo-core", "post-estop-servo-bandwidth"):
    source = (folder / f"{name}.json").read_bytes()
    original = json.loads(source)
    replay = replay_readonly_report(source)
    stable = {}
    for joint in original["properties"]:
        samples = [row for row in original["samples"][9:] if row["joint"] == joint]
        if not samples:
            continue
        positions = [control.project_position(joint, row["state"]["angle_deg"]) for row in samples]
        stable[joint] = {"unit": "mm" if joint == "J1" else "deg", "samples": len(samples),
                         "host_span_s": samples[-1]["received_s"] - samples[0]["received_s"],
                         "mean_position": mean(positions), "position_span": max(positions) - min(positions)}
    report["captures"][name] = {
        "source_sha256": sha256(source).hexdigest(), "source_status": original["status"],
        "replay_status": replay["status"], "properties": len(replay["property_observations"]),
        "fast_feedback": len(replay["feedback_observations"]),
        "incomplete_reads": replay["incomplete_reads"], "stationary_observations": stable,
    }
motion = replay_tracking_capture((folder / "nineaxis-roundtrip-02.jsonl").read_bytes(),
                                 (folder / "nineaxis-roundtrip-02.capture.json").read_bytes(), root)
with (folder / "tracking-dynamics-replay.json").open("x", encoding="utf-8") as stream:
    json.dump(motion, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write("\n")
report["original_motion"] = {
    "capture_sha256": motion["capture_sha256"], "status": motion["capture_status"],
    "response_dynamics": motion["response_dynamics"],
}
events = [json.loads(line) for line in (folder / "nineaxis-roundtrip-02.jsonl").read_bytes().splitlines()]
last_seed = max(row["monotonic_s"] for row in events if row["event"] == "low_speed_seed_requested")
started = next(row["monotonic_s"] for row in events if row["event"] == "continuous_roundtrip_requested")
last_feedback = [row for row in events if row["event"] == "feedback" and row["monotonic_s"] < started][-1]
report["initial_hold_window"] = {
    "seconds_from_last_seed_to_reference_request": started - last_seed,
    "all_windows_after_seed": all(row["received_s"] - row["stationary_window_duration_s"] >= last_seed
                                  for row in last_feedback["samples"].values()),
    "windows_started_s": {joint: row["received_s"] - row["stationary_window_duration_s"]
                          for joint, row in last_feedback["samples"].items()},
}
stop = json.loads((root / ".scratch/motor_control/attended-positioning-stop.json").read_bytes())
if stop["manual_review_required"] is not True or stop["reason"] != "outside_complete_nineaxis_roundtrip_self_interval":
    raise ValueError("现场异常停止限制变化")
report["stop_latch_unchanged"] = True
with (folder / "servo-diagnosis-validation.json").open("x", encoding="utf-8") as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps({"captures": {name: {key: value for key, value in row.items() if key != "stationary_observations"}
                              for name, row in report["captures"].items()},
                  "initial_hold_window": report["initial_hold_window"],
                  "stop_latch_unchanged": True}, ensure_ascii=False, indent=2))

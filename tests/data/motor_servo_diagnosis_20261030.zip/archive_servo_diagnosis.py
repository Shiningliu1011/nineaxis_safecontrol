from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
captures = ("post-estop-operating.json", "post-estop-servo.json", "post-estop-servo-core.json",
            "post-estop-servo-bandwidth.json")
members = {name: (folder / name).read_bytes() for name in (
    *captures, "operator-power-status.json", "operator-observation.json",
    "analyze_tracking_response.py", "analyze_tracking_jumps.py", "verify_servo_diagnosis.py",
    "tracking-response-timeline.json", "tracking-jumps.json", "servo-diagnosis-validation.json",
    "tracking-dynamics-replay.json", "archive_servo_diagnosis.py",
)}
for name in captures:
    replay = replay_readonly_report(members[name])
    expected = "replayed_incomplete" if name == "post-estop-servo.json" else "replayed_completed"
    if replay["status"] != expected:
        raise ValueError("真实伺服读取的完整性与预期不符")
for name in ("joint_table_readonly.py", "tracking_log_replay.py", "drempower_serial.py"):
    members[f"source/{name}"] = (root / "src/robot_safecontrol_moveit" / name).read_bytes()
references = []
for name in ("DrEmpower系列电机常用参数及地址表.pdf", "DrEmpower系列产品电机备选PID参数表.pdf"):
    path = root / "大然电机/大然电机所有资料/drempower-wiki-master/6-其他资料" / name
    references.append({"path": str(path.relative_to(root)), "sha256": sha256(path.read_bytes()).hexdigest()})
manifest = {
    "evidence_kind": "post_power_cycle_nonmotion_servo_diagnosis",
    "motion_commands_sent": 0, "parameter_writes_sent": 0, "hardware_qualified": False,
    "physical_cause_confirmed": False, "manufacturer_sources": references,
    "reader_source_snapshot_capture": "post-estop-servo-bandwidth.json",
    "original_motion_archive": "nineaxis_continuous_failure_20261030.zip",
    "original_motion_archive_sha256": sha256((root / "tests/data/nineaxis_continuous_failure_20261030.zip").read_bytes()).hexdigest(),
    "files": [{"member": name, "bytes": len(data), "sha256": sha256(data).hexdigest()}
              for name, data in members.items()],
}
output = root / "tests/data/motor_servo_diagnosis_20261030.zip"
with ZipFile(output, "x", compression=ZIP_DEFLATED) as archive:
    for name, data in members.items():
        archive.writestr(name, data)
    archive.writestr("provenance.json", json.dumps(manifest, ensure_ascii=False, indent=2, allow_nan=False))
with ZipFile(output) as archive:
    if archive.testzip() is not None:
        raise ValueError("伺服诊断归档的 CRC 无效")
    for row in manifest["files"]:
        data = archive.read(row["member"])
        if len(data) != row["bytes"] or sha256(data).hexdigest() != row["sha256"]:
            raise ValueError("伺服诊断归档成员身份无效")
print(json.dumps({"archive": str(output), "sha256": sha256(output.read_bytes()).hexdigest(),
                  "verified_members": len(members)}, indent=2))

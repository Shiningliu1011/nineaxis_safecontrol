from collections import defaultdict
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path

from robot_safecontrol_moveit.drempower_can import decode_feedback
from robot_safecontrol_moveit.drempower_serial import SERIAL_CAN_FRAME
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.tracking_log_replay import _raw_tracking, replay_tracking_capture


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
capture_bytes = (folder / "nineaxis-roundtrip-02.capture.json").read_bytes()
log_bytes = (folder / "nineaxis-roundtrip-02.jsonl").read_bytes()
verified = replay_tracking_capture(log_bytes, capture_bytes, root)
capture = json.loads(capture_bytes)
trace = _raw_tracking(capture, JointTableControl(root))
start = trace["broadcasts"][0]["monotonic_s"]
samples = defaultdict(list)
for row in trace["feedback"]:
    if row["reference_source"] != "host_broadcast":
        continue
    parsed = SERIAL_CAN_FRAME.parse(bytes.fromhex(row["raw_hex"]))
    samples[row["joint"]].append({
        **row, "elapsed_s": row["received_s"] - start,
        "device_feedback": asdict(decode_feedback(parsed.frame_id, parsed.data)),
    })
report = {
    "capture_sha256": sha256(capture_bytes).hexdigest(),
    "validation_scope": "original_device_adjacent_feedback",
    "time_basis": "host_receive_minus_first_broadcast",
    "device_sample_time_known": False,
    "hardware_qualified": False,
    "joints": {},
}
for joint, rows in samples.items():
    pairs = []
    for before, after in zip(rows, rows[1:]):
        interval = after["received_s"] - before["received_s"]
        pairs.append({
            "before": before, "after": after, "receive_interval_s": interval,
            "position_change": after["position"] - before["position"],
            "reference_change": after["reference"] - before["reference"],
            "position_rate_per_host_second": (after["position"] - before["position"]) / interval,
        })
    largest = sorted(pairs, key=lambda pair: abs(pair["position_change"]), reverse=True)[:5]
    peak_s = largest[0]["after"]["received_s"]
    report["joints"][joint] = {
        "unit": "mm" if joint == "J1" else "deg", "largest_five_steps": largest,
        "peak_context": [row for row in rows if peak_s - .4 <= row["received_s"] <= peak_s + .3],
    }
with (folder / "tracking-jumps.json").open("x", encoding="utf-8") as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write("\n")
for joint in ("J2", "J3", "J4", "J5", "J6"):
    for pair in report["joints"][joint]["largest_five_steps"][:2]:
        print(joint, json.dumps({
            "time_s": pair["after"]["elapsed_s"], "step_deg": pair["position_change"],
            "interval_s": pair["receive_interval_s"], "target_step_deg": pair["reference_change"],
            "speed_deg_s": pair["position_rate_per_host_second"],
            "reported_device_rpm": pair["after"]["device_feedback"]["vel_rpm"],
            "device_torque_before_nm": pair["before"]["device_feedback"]["torque_nm"],
            "device_torque_after_nm": pair["after"]["device_feedback"]["torque_nm"],
        }))

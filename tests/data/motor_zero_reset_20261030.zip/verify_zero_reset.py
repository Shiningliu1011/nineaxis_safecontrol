import argparse
from hashlib import sha256
import json
from pathlib import Path
from statistics import mean
from zipfile import ZIP_DEFLATED, ZipFile

from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--archive", type=Path)
    args = parser.parse_args()
    folder = Path(__file__).resolve().parent
    root = folder.parents[1]
    control = JointTableControl(root)
    policy_path = root / ".scratch/motor_control/attended-positioning.json"
    stop_path = root / ".scratch/motor_control/attended-positioning-stop.json"
    policy_source, stop_source = policy_path.read_bytes(), stop_path.read_bytes()
    policy, stop = json.loads(policy_source), json.loads(stop_source)
    report = {
        "status": "readonly_zero_reset_verified",
        "mechanical_zero_source": "operator_statement",
        "motion_commands_sent": 0,
        "parameter_writes_sent": 0,
        "full_stroke_verified": False,
        "physical_stop_independently_verified": False,
        "independent_physical_precision_verified": False,
        "device_sample_time_known": False,
        "captures": {},
    }
    contents = {"operator-statement.json": (folder / "operator-statement.json").read_bytes(),
                "attended-positioning.json": policy_source,
                "attended-positioning-stop.json": stop_source,
                "verify_zero_reset.py": Path(__file__).read_bytes()}
    for name in ("drempower.yaml", "hardware_joint_zero.yaml", "j1_transmission.yaml"):
        contents[f"config/{name}"] = (root / "config" / name).read_bytes()
    config_hashes = {name: sha256(contents[f"config/{name}"]).hexdigest()
                     for name in ("drempower.yaml", "hardware_joint_zero.yaml", "j1_transmission.yaml")}
    for name in ("nineaxis-encoder-readonly.json", "nineaxis-servo-readonly.json"):
        source = (folder / name).read_bytes()
        capture = json.loads(source)
        replay = replay_readonly_report(source)
        if (capture["status"] != "readonly_completed" or replay["status"] != "replayed_completed"
                or capture["configuration_sha256"] != config_hashes
                or set(replay["nodes"]) != {str(index) for index in range(1, 10)}):
            raise ValueError("重新归零核验需要完整九轴原始读取及一致的坐标配置")
        observations = {}
        for joint in DEFAULT_JOINT_NAMES:
            node = control._node(joint)
            properties = replay["nodes"][str(node)]
            if properties["node_id"] != node or properties["axis_state"] != 8 or any(properties[key] for key in (
                    "axis_error", "can_error", "motor_error", "encoder_error", "controller_error")):
                raise ValueError(f"{joint} 当前设备身份、闭环状态或故障无效")
            rows = [row for row in replay["feedback_observations"] if row["node_id"] == node]
            if rows[-1]["received_s"] - rows[0]["received_s"] < 5 or any(
                    row["axis_error"] or not row["traj_done"] for row in rows):
                raise ValueError(f"{joint} 缺少连续五秒的有效反馈")
            positions = [control.project_position(joint, control.decode_state(
                joint, row["pos_deg"], row["vel_rpm"]).angle_deg) for row in rows]
            observations[joint] = {
                "unit": "mm" if joint == "J1" else "deg",
                "samples": len(rows),
                "host_duration_s": rows[-1]["received_s"] - rows[0]["received_s"],
                "mean_position": mean(positions),
                "minimum_position": min(positions),
                "maximum_position": max(positions),
                "position_span": max(positions) - min(positions),
            }
        report["captures"][name] = {
            "sha256": sha256(source).hexdigest(),
            "started_at": capture["started_at"],
            "property_reads": len(replay["property_observations"]),
            "fast_feedback": len(replay["feedback_observations"]),
            "properties": capture["properties"],
            "observations": observations,
        }
        contents[name] = source
    encoder = report["captures"]["nineaxis-encoder-readonly.json"]["properties"]["J1"]
    if (encoder["zero_offset_counts"] != policy["expected_j1_zero_offset_counts"]
            or encoder["serial_number_l"] != policy["expected_j1_serial_number_l"]
            or encoder["encoder_turn_abs"] != 0 or encoder["multi_circle_enabled"] != 1):
        raise ValueError("J1 现场零位配置与当前原始回读不一致")
    if not stop["manual_review_required"] or stop_path.read_bytes() != stop_source:
        raise ValueError("本次只读核验期间停止记录变化")
    report["current_j1_zero_offset_counts"] = encoder["zero_offset_counts"]
    report["policy_sha256"] = sha256(policy_source).hexdigest()
    report["stop_sha256"] = sha256(stop_source).hexdigest()
    report["motion_restart_qualified"] = False
    encoded = (json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()
    with args.output.open("xb") as output:
        output.write(encoded)
    if args.archive is not None:
        contents["verification.json"] = encoded
        provenance = [{"member": name, "bytes": len(value), "sha256": sha256(value).hexdigest()}
                      for name, value in contents.items()]
        with ZipFile(args.archive, "x", compression=ZIP_DEFLATED) as archive:
            for name, value in contents.items():
                archive.writestr(name, value)
            archive.writestr("provenance.json", json.dumps(provenance, ensure_ascii=False, indent=2))
        with ZipFile(args.archive) as archive:
            for item in json.loads(archive.read("provenance.json")):
                data = archive.read(item["member"])
                if len(data) != item["bytes"] or sha256(data).hexdigest() != item["sha256"]:
                    raise ValueError("原始归档成员校验失败")
        print(f"归档：{args.archive}，SHA-256：{sha256(args.archive.read_bytes()).hexdigest()}")
    print(json.dumps({"status": report["status"], "j1_zero_offset_counts": encoder["zero_offset_counts"],
                      "captures": {name: {"property_reads": value["property_reads"],
                                          "fast_feedback": value["fast_feedback"],
                                          "observations": value["observations"]}
                                   for name, value in report["captures"].items()}}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

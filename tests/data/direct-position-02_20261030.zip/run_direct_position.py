import argparse
from hashlib import sha256
import json
from pathlib import Path
import time

import numpy as np

from robot_safecontrol_moveit.joint_positioning import run_positioning_cli
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.motor_stop_latch import MotorStopLatch
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES


parser = argparse.ArgumentParser()
parser.add_argument("--check-only", action="store_true")
parser.add_argument("--run-id", required=True)
parser.add_argument("--current", type=Path, required=True)
parser.add_argument("--review", type=Path, required=True)
args = parser.parse_args()
if not args.run_id.isascii() or not all(value.isalnum() or value == "-" for value in args.run_id):
    raise ValueError("定位记录名称无效")
root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
review_source = args.review.read_bytes()
review = json.loads(review_source)
operator = json.loads((folder / "direct-position-operator.json").read_bytes())
target = [2., 1., -1., 1., -1., 1., 1., -1., 1.]
if (operator["target_mm_deg"] != target or review["target_mm_deg"] != target
        or any(operator[name] is not True for name in (
            "support_allows_motion", "motion_area_empty", "operator_at_power_cutoff"))):
    raise ValueError("本次九轴目标及现场条件不符")
if review["scope"] != "attended_native_single_group_positioning":
    raise ValueError("本次只允许单组原生位置命令")
for name, digest in review["configuration_sha256"].items():
    if sha256((root / "config" / name).read_bytes()).hexdigest() != digest:
        raise ValueError("本次定位配置身份变化")
current_source = args.current.read_bytes()
current = json.loads(current_source)
replay = replay_readonly_report(current_source)
if current["status"] != "readonly_completed" or replay["status"] != "replayed_completed":
    raise ValueError("本次设备读取未完成")
control = JointTableControl(root)
position = np.array([control.project_position(joint, current["samples"][-9 + index]["state"]["angle_deg"])
                     for index, joint in enumerate(DEFAULT_JOINT_NAMES)])
if np.any(np.abs(position - review["initial_mm_deg"]) > [.001, *([.01] * 8)]):
    raise ValueError("当前位置已变化，需要重新核对运动范围")
if not 0 <= time.monotonic() - current["samples"][-1]["received_s"] <= 180:
    raise ValueError("本次执行前读取已经过期")
for joint in DEFAULT_JOINT_NAMES:
    values = current["properties"][joint]
    if (values["axis_state"] != 8 or values["input_mode"] != 5 or values["control_mode"] != 3
            or values["trajectory_done"] != 1 or any(values[name] for name in (
                "axis_error", "can_error", "motor_error", "encoder_error", "controller_error"))):
        raise ValueError(f"{joint} 执行前状态无效")
if args.check_only:
    print(json.dumps({"status": "pre_execution_checks_passed", "current_mm_deg": position.tolist(),
                      "target_mm_deg": target, "motion_commands_sent": 0}))
    raise SystemExit(0)
stop = MotorStopLatch(root / ".scratch/motor_control/attended-positioning-stop.json")
stop_source = stop.path.read_bytes()
if json.loads(stop_source).get("reviewed_native_target_mm_deg") != target:
    raise ValueError("本次原生定位的停止审查未完成")
stop.acknowledge_stop(expected_sha256=sha256(stop_source).hexdigest(),
                      archive_path=folder / f"{args.run_id}-reviewed-stop.json")
output = folder / f"{args.run_id}.jsonl"
try:
    raise SystemExit(run_positioning_cli(
        root=root, target_joints=dict(zip(DEFAULT_JOINT_NAMES, target)),
        maximum_speed=dict(zip(DEFAULT_JOINT_NAMES, review["speed_mm_deg_s"])),
        acceleration=dict(zip(DEFAULT_JOINT_NAMES, review["acceleration_mm_deg_s2"])),
        port="/dev/serial/by-id/usb-Dr-Tech_DR-USB_CAN_87949380174B-if00",
        argv=["--joints", *map(str, target), "--output", str(output)]))
finally:
    stop.trip(reason="reviewed_native_single_group_session_finished", log_path=output)

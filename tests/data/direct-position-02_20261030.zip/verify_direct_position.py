from bisect import bisect_left
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path

import numpy as np

from robot_safecontrol_moveit.drempower_joint_control import JointFeedback
from robot_safecontrol_moveit.joint_positioning import single_target_table
from robot_safecontrol_moveit.joint_table_execution import JointTableControl, JointTableExecutor
from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.motor_motion_limits import MotionBounds
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import ExecutionLimits, ObservedFeedback
from robot_safecontrol_moveit.tracking_log_replay import _match_commands, _raw_tracking
from work.nineaxis_model import NineaxisModel


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
run = "direct-position-02"
log_source = (folder / f"{run}.jsonl").read_bytes()
events = [json.loads(line) for line in log_source.splitlines()]
report = json.loads((folder / f"{run}.report.json").read_bytes())
frames_source = (folder / f"{run}.frames.json").read_bytes()
frames = json.loads(frames_source)
control = JointTableControl(root)
trace = _raw_tracking({"frames": frames, "status": report["phase"]}, control)
if report["phase"] != "completed" or events[-1]["event"] != "completed":
    raise ValueError("实机定位没有完成")
if report["all_positioning_targets_completed"] is not True or len(report["positioning_records"]) != 1:
    raise ValueError("实机定位完成组数无效")
normalized = [{**row, "event": "low_speed_seed_requested"} if row["event"] == "command_requested"
              else row for row in events]
_match_commands(normalized, trace, control)
if len(trace["positions"]) != 9 or trace["broadcasts"] or set(trace["tx_commands"]) != {"0x1a", "0x1e"}:
    raise ValueError("实机定位命令范围无效")
model = NineaxisModel.load(root=root)
target = report["attempts"][0]["target_mm_deg"]
table = single_target_table(dict(zip(DEFAULT_JOINT_NAMES, target)), model)
if model.model_hash != report["model_hash"] or table.source_sha256 != report["table_sha256"]:
    raise ValueError("实机定位模型或目标身份变化")
limits = {joint: ExecutionLimits(**{**values, "bounds": MotionBounds(**values["bounds"])
                                    if values["bounds"] else None}) for joint, values in report["limits"].items()}
executor = JointTableExecutor(table, model, measurement_kind="positioning", task_id="original-native-replay",
                              feedback_source="recorded_device_feedback", limits=limits, manual_positioning=True)
by_joint = {joint: [row for row in trace["feedback"] if row["joint"] == joint] for joint in DEFAULT_JOINT_NAMES}
times = {joint: [row["received_s"] for row in values] for joint, values in by_joint.items()}
matched = set()
for event in events:
    if event["event"] == "command_requested" and not executor.attempts:
        executor.begin(now_s=event["monotonic_s"])
    if event["event"] == "feedback":
        samples = {}
        for joint, value in event["samples"].items():
            index = bisect_left(times[joint], value["request_s"])
            raw = by_joint[joint][index]
            sample = ObservedFeedback(raw["node_id"], JointFeedback(**raw["state"]),
                                      value["request_s"], value["received_s"], raw["traj_done"], raw["axis_error"])
            if (asdict(sample) != value or not value["request_s"] <= raw["received_s"] <= value["received_s"]
                    or raw["raw_frame_index"] in matched):
                raise ValueError("实机定位反馈与原始帧不符")
            samples[joint] = sample
            matched.add(raw["raw_frame_index"])
        executor.observe(samples, now_s=event["monotonic_s"])
    if event["event"] == "positioning_completed" and executor.phase != "holding_position":
        raise ValueError("实机定位到位事件与原始反馈复算不符")
    if event["event"] == "completed":
        executor.finish_positioning(now_s=event["monotonic_s"])
if executor.phase != "completed" or len(executor.positioning_records) != 1:
    raise ValueError("实机定位状态复算未完成")
holding = next(row for row in events if row["event"] == "positioning_completed")
hold_s = events[-1]["monotonic_s"] - holding["monotonic_s"]
if hold_s < 5:
    raise ValueError("实机到位后持续观察不足五秒")
metrics = {}
for index, joint in enumerate(DEFAULT_JOINT_NAMES):
    after = [row for row in by_joint[joint] if row["received_s"] >= holding["monotonic_s"]]
    command_time = trace["positions"][index]["monotonic_s"]
    moving = [row for row in by_joint[joint] if row["received_s"] >= command_time]
    before = [row for row in by_joint[joint] if row["received_s"] < command_time][-1]["position"]
    direction = np.sign(target[index] - before)
    metrics[joint] = {
        "unit": "mm" if joint == "J1" else "deg",
        "target": target[index], "final_position": after[-1]["position"],
        "maximum_hold_error": max(abs(row["position"] - target[index]) for row in after),
        "maximum_overshoot": max(0., max(direction * (row["position"] - target[index]) for row in moving)),
        "maximum_reverse_start_motion": max(0., max(-direction * (row["position"] - before) for row in moving)),
        "initial_to_final_displacement": after[-1]["position"] - before,
    }
held_source = (folder / "direct-position-held-02.json").read_bytes()
held = replay_readonly_report(held_source)
if held["status"] != "replayed_completed":
    raise ValueError("独立连接的保持读取未完成")
for values in held["nodes"].values():
    if values["axis_state"] != 8 or any(values[name] for name in (
            "axis_error", "can_error", "motor_error", "encoder_error", "controller_error")):
        raise ValueError("定位结束后的设备状态无效")
result = {
    "status": "recorded_native_positioning_verified", "target_mm_deg": target,
    "matched_samples": len(matched), "raw_feedback_samples": len(trace["feedback"]),
    "tx_commands": trace["tx_commands"], "position_commands": len(trace["positions"]),
    "arrival_elapsed_s": report["attempts"][0]["arrival_elapsed_s"], "holding_duration_s": hold_s,
    "metrics": metrics, "journal_sha256": sha256(log_source).hexdigest(),
    "frames_sha256": sha256(frames_source).hexdigest(), "held_readonly_sha256": sha256(held_source).hexdigest(),
    "independent_physical_precision_verified": False, "physical_stop_independently_verified": False,
    "device_sample_time_known": False,
}
with (folder / "direct-position-02-validation.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps(result, ensure_ascii=False, indent=2))

import argparse
from hashlib import sha256
import json
from pathlib import Path

from construct import Float32l, Int16sl, Struct, Terminated
import numpy as np

from robot_safecontrol_moveit.drempower_can import can_node_id
from robot_safecontrol_moveit.drempower_serial import SERIAL_CAN_FRAME
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES


folder = Path(__file__).parent
parser = argparse.ArgumentParser()
parser.add_argument("--kind", choices=("hold", "forward", "return"), required=True)
args = parser.parse_args()
capture_path = folder / f"timed-{args.kind}.capture.json"
capture = json.loads(capture_path.read_bytes())
log_path = folder / f"timed-{args.kind}.jsonl"
log_bytes = log_path.read_bytes()
if sha256(log_bytes).hexdigest() != capture["log_sha256"] or capture["status"] != "completed":
    raise ValueError("共同时间实验未完成或日志身份变化")
events = [json.loads(line) for line in log_bytes.splitlines()]
observations = [row for row in events if row["event"] == "feedback"]
start = capture["broadcast"]["broadcast_write_finished_s"]
rows = {}
for joint in DEFAULT_JOINT_NAMES:
    data = [row["samples"][joint] for row in observations]
    times = np.array([(row["request_s"] + row["received_s"]) / 2 - start for row in data])
    positions = np.array([row["state"]["angle_deg"] / (72 if joint == "J1" else 1) for row in data])
    before = positions[(times >= -4) & (times < 0)]
    after = positions[times >= times[-1] - 4]
    initial, final = float(np.median(before)), float(np.median(after))
    rows[joint] = {"initial": initial, "final": final, "before_span": float(np.ptp(before)),
                   "after_span": float(np.ptp(after)), "samples": len(data),
                   "unit": "mm" if joint == "J1" else "deg",
                   "target_error": final - capture["target_mm_deg"][DEFAULT_JOINT_NAMES.index(joint)]}
    if args.kind != "hold" and joint in ("J1", "J7", "J8", "J9"):
        progress = (positions - initial) / (final - initial)
        rows[joint]["progress"] = np.interp(np.arange(0., 30.001, .05), times, progress)
        for threshold in (.1, .5, .9, .95):
            crossing = np.flatnonzero((times >= 0) & (progress >= threshold))
            rows[joint][f"t{round(threshold * 100)}_host_s"] = float(times[crossing[0]]) if len(crossing) else None
        rows[joint]["relative_baseline_span"] = rows[joint]["before_span"] / abs(final - initial)
report = {"kind": args.kind, "status": capture["status"], "broadcast": capture["broadcast"],
          "completed_after_broadcast_s": capture["completed_after_broadcast_s"], "joints": rows,
          "device_sample_time_known": False, "hardware_qualified": False,
          "independent_physical_precision_verified": False,
          "progress_normalization": "observed_four_second_median_start_and_end",
          "host_grid_interval_s": .05, "source_sha256": sha256(capture_path.read_bytes()).hexdigest()}
if args.kind != "hold":
    active = ("J1", "J7", "J8", "J9")
    progress = np.stack([rows[joint].pop("progress") for joint in active])
    grid = np.arange(0., 30.001, .05)
    spread = np.ptp(progress, axis=0)
    index = int(np.argmax(spread))
    report["maximum_progress_spread"] = float(spread[index])
    report["maximum_spread_host_s"] = float(grid[index])
    report["progress_at_maximum_spread"] = dict(zip(active, progress[:, index].tolist()))
    report["progress_samples"] = [{"host_s": float(value), "normalized_progress": dict(zip(active, column.tolist()))}
                                  for value, column in zip(grid, progress.T)]
payload = Struct("angle" / Float32l, "duration_100" / Int16sl, "accel_100" / Int16sl, Terminated)
counts = {}
presets, broadcasts, replies = [], [], {}
for row in capture["frames"]:
    frame = SERIAL_CAN_FRAME.parse(bytes.fromhex(row["raw_hex"]))
    node, command = can_node_id(frame.frame_id)
    if row["direction"] == "tx":
        counts[f"0x{command:02x}"] = counts.get(f"0x{command:02x}", 0) + 1
        if command == 0x0c:
            decoded = payload.parse(frame.data)
            presets.append({"node": node, "angle": decoded.angle, "duration_s": decoded.duration_100 / 100,
                            "accel_rpm_s": decoded.accel_100 / 100, "requested_s": row["monotonic_s"]})
        elif command == 0x08:
            if node != 0 or frame.data != bytes.fromhex("1100000000000000"):
                raise ValueError("共同时间启动帧无效")
            broadcasts.append(row["monotonic_s"])
    else:
        replies[str(node)] = replies.get(str(node), 0) + 1
if len(presets) != 9 or len(broadcasts) != 1 or counts.get("0x1f", 0) != 0:
    raise ValueError("原始实验命令数量或参数写入不符")
report.update(tx_commands=counts, presets=presets, broadcasts=broadcasts, rx_by_node=replies)
with (folder / f"timed-{args.kind}.analysis.json").open("x", encoding="utf-8") as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write("\n")
summary = {key: value for key, value in report.items() if key not in ("progress_samples", "presets")}
print(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False))

from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
paths = [folder / name for name in (
    "run_timed_probe.py", "analyze_timed_probe.py", "prepare_probe.py", "archive_native.py",
    "current-preflight.json", "recovery-review.json", "previous-attended-stop.json", "operator-readings.json",
    "j1-outward-1mm.jsonl", "j1-outward-1mm.frames.json", "j1-outward-1mm.capture.json",
    "timed-hold.jsonl", "timed-hold.capture.json", "timed-forward.jsonl", "timed-forward.capture.json",
    "timed-return.jsonl", "timed-return.capture.json", "timed-forward.analysis.json", "timed-return.analysis.json",
    "codec-guard-green.xml",
)]
paths += [root / "src/robot_safecontrol_moveit" / name for name in (
    "drempower_serial.py", "drempower_can.py")]
paths += [root / "config" / name for name in ("drempower.yaml", "hardware_joint_zero.yaml", "j1_transmission.yaml")]
output = root / "tests/data/motor_sync_timed_experiments_20261030.zip"
provenance = {"evidence_kind": "real_attended_timed_preset_broadcast_experiments",
              "hardware_qualified": False, "independent_physical_precision_verified": False, "files": []}
with ZipFile(output, "x", compression=ZIP_DEFLATED) as archive:
    for path in paths:
        content = path.read_bytes()
        member = str(path.relative_to(root)) if not path.is_relative_to(folder) else path.name
        provenance["files"].append({"member": member, "bytes": len(content), "sha256": sha256(content).hexdigest()})
        archive.writestr(member, content)
    archive.writestr("provenance.json", json.dumps(provenance, ensure_ascii=False, indent=2, allow_nan=False))
print(json.dumps({"archive": str(output), "sha256": sha256(output.read_bytes()).hexdigest(),
                  "members": len(paths)}, ensure_ascii=False))

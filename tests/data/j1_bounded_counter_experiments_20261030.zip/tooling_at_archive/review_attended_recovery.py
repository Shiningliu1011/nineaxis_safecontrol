import json
from dataclasses import asdict, replace
from hashlib import sha256
from pathlib import Path

from robot_safecontrol_moveit.drempower_joint_control import JointFeedback
from robot_safecontrol_moveit.joint_positioning import positioning_limits
from robot_safecontrol_moveit.joint_table_commissioning import stationary_noise
from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.motor_motion_limits import MotionBounds
from robot_safecontrol_moveit.motor_stop_latch import MotorStopLatch
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import (
    ObservedFeedback, SingleJointMonitor, VelocityWindow, stationary_conditions,
)

root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
policy_bytes = (root / ".scratch/motor_control/attended-positioning.json").read_bytes()
policy = json.loads(policy_bytes)
stop_path = root / ".scratch/motor_control/attended-positioning-stop.json"
stop_bytes = stop_path.read_bytes()
stop = json.loads(stop_bytes)
old = json.loads((root / ".scratch/joint-positioning/attended-motion-02.report.json").read_bytes())
if stop["log_path"] != ".scratch/joint-positioning/attended-motion-02.jsonl" or stop["reason"] != old["rejection_reason"]:
    raise ValueError("本次恢复审查的停止原因已经变化")
if sha256((root / ".scratch/motor_control/stop.json").read_bytes()).hexdigest() != policy["reviewed_stop_sha256"]:
    raise ValueError("主停止记录身份变化")
source_path = folder / "current-preflight.json"
source_bytes = source_path.read_bytes()
source = json.loads(source_bytes)
replay = replay_readonly_report(source_bytes)
if source["status"] != "readonly_completed" or replay["status"] != "replayed_completed":
    raise ValueError("本次独立非运动读取未完成")
for name, digest in source["configuration_sha256"].items():
    if sha256((root / "config" / name).read_bytes()).hexdigest() != digest or policy["config_hashes"][name] != digest:
        raise ValueError(f"现场坐标配置身份变化：{name}")
for joint in DEFAULT_JOINT_NAMES:
    values = source["properties"][joint]
    if values["axis_state"] != 8 or values["axis_error"] != 0 or values["encoder_error"] != 0:
        raise ValueError(f"{joint} 当前状态或故障无效")
j1 = source["properties"]["J1"]
if j1["serial_number_l"] != policy["expected_j1_serial_number_l"] or j1["zero_offset_counts"] != policy["expected_j1_zero_offset_counts"]:
    raise ValueError("J1 用户恢复后的身份或零位变化")
noise = stationary_noise(root, root / policy["noise_evidence_path"], policy["noise_evidence_sha256"], policy["model_hash"])
limits = positioning_limits(root, dict(zip(DEFAULT_JOINT_NAMES, [.05, *([2.46] * 8)])),
                            dict(zip(DEFAULT_JOINT_NAMES, [.01, *([.3] * 8)])))
for joint, limit in limits.items():
    bounds = None if joint == "J1" else MotionBounds(limit.speed_rpm, limit.accel_rpm_s, 5 / 6,
                                                    sha256(policy_bytes).hexdigest())
    limits[joint] = replace(limit, stationary_window_s=5., stationary_velocity_noise_rpm=noise[joint],
                            bounds=bounds, max_feedback_rpm=limit.max_feedback_rpm if bounds is None else 5 / 6)
windows = {joint: VelocityWindow(1., 5.) for joint in DEFAULT_JOINT_NAMES}
monitors = {joint: SingleJointMonitor(index + 1, limits[joint]) for index, joint in enumerate(DEFAULT_JOINT_NAMES)}
latest = {}
for row in source["samples"][9:]:
    joint = row["joint"]
    sample = ObservedFeedback(**{key: value for key, value in row.items() if key not in ("joint", "state")},
                              state=JointFeedback(**row["state"]))
    observed = windows[joint].add(sample)
    if observed.window_duration_s < 1:
        monitors[joint].validate_hold_feedback(observed, observed.received_s)
    else:
        monitors[joint].validate_feedback(observed, observed.received_s)
    latest[joint] = observed
if set(latest) != set(DEFAULT_JOINT_NAMES) or not all(all(stationary_conditions(latest[joint], limits[joint]).values())
                                                                  for joint in DEFAULT_JOINT_NAMES):
    raise ValueError("九轴实际静止反馈尚未成立")
result = {"reviewed_stop": stop, "reviewed_stop_sha256": sha256(stop_bytes).hexdigest(),
          "source": str(source_path.relative_to(root)), "source_sha256": sha256(source_bytes).hexdigest(),
          "policy_sha256": sha256(policy_bytes).hexdigest(), "feedback": {joint: asdict(sample) for joint, sample in latest.items()},
          "operator_statement": "现在我就在旁边看着，有急停按钮，失能转动有支撑",
          "probe_clearance_statement": "空间足够，支撑不会阻碍升降",
          "recovery_scope": "attended_bounded_J1_counter_characterisation",
          "motion_commands_sent": 0, "parameter_writes_sent": 0,
          "physical_stop_independently_verified": False, "general_hardware_qualification_changed": False}
with (folder / "attended-recovery-review.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
MotorStopLatch(stop_path).acknowledge_stop(expected_sha256=sha256(stop_bytes).hexdigest(),
                                          archive_path=folder / "previous-attended-stop.json")
print("有人值守停止原因审查通过；九轴独立读取保持静止，原停止记录已经归档。")

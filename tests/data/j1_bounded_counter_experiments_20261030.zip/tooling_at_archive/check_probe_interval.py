import argparse
import json
from pathlib import Path

import numpy as np
from robot_static_fcl import Body

from work.kinematics_data import JOINT_CHAIN
from work.nineaxis_kinematics import NineaxisKinematics
from work.static_collision import distance_between
from work.static_collision_meshes import load_meshes, mesh_sources

root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
parser = argparse.ArgumentParser()
parser.add_argument("--maximum-mm", type=float, choices=(1., 5.), default=1.)
args = parser.parse_args()
inspection = json.loads((folder / "self-geometry-inspection.json").read_bytes())
reference = np.array(inspection["results"][0]["joints_si"])
center = reference.copy()
center[0] = args.maximum_mm / 2000
radius = np.full(9, np.deg2rad(0.01))
radius[0] = center[0] + 0.0001
sources = mesh_sources(root / "portable_oscbf/config/collision_geometry_sources.json")
meshes = load_meshes(sources)
transforms = NineaxisKinematics().forward_kinematics(center)
bodies = []
for mesh in meshes:
    body = Body.convex(mesh.vertices, mesh.faces)
    transform = transforms[mesh.link]
    body.set_transform(transform[:3, :3], transform[:3, 3])
    bodies.append(body)
offsets = np.array([np.linalg.norm(row[3:6]) for row in JOINT_CHAIN
                    if row[2] in ("prismatic", "revolute")])
rows = []
for first, second in sources["pairs"]:
    coefficients = np.zeros(9)
    coefficients[0] = 1
    for joint in range(1, second):
        coefficients[joint] = np.sum(offsets[joint + 1:second]) + meshes[second].radius_m
    coefficients[:first] = 0
    distance = distance_between(bodies[first], bodies[second])
    margin = distance.distance_m - float(coefficients @ radius) - 0.01
    rows.append({"pair": [meshes[first].link, meshes[second].link], "distance_m": distance.distance_m,
                 "displacement_bound_m": float(coefficients @ radius), "required_m": 0.01,
                 "interval_margin_m": margin, "valid": distance.valid and margin > 0})
report = {"scope": "bounded_J1_characterisation_self_geometry", "maximum_mm": args.maximum_mm,
          "self_collision_sources": sources,
          "center_si": center.tolist(), "radius_si": radius.tolist(),
          "reference_si": reference.tolist(), "method": "whole_joint_box_displacement_bound",
          "coefficient_reference": "StaticGeometry.displacement_coefficients",
          "external_scene_checked": False, "physical_stop_independently_verified": False,
          "rows": rows, "self_interval_checked": all(row["valid"] for row in rows)}
output = folder / ("j1-probe-self-interval.json" if args.maximum_mm == 1 else "j1-probe-5mm-self-interval.json")
with output.open("x", encoding="utf-8") as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
if not report["self_interval_checked"]:
    raise ValueError("J1 实验范围的完整自身几何检查未通过")
print(json.dumps({"self_interval_checked": True, "pairs": len(rows),
                  "minimum_interval_margin_mm": min(row["interval_margin_m"] for row in rows) * 1000},
                 ensure_ascii=False))

import json
from hashlib import sha256
from pathlib import Path

from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.motor_stop_latch import MotorStopLatch

root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
source = (folder / "final-nineaxis-readonly.json").read_bytes()
recorded = json.loads(source)
replay = replay_readonly_report(source)
if recorded["status"] != "readonly_completed" or replay["status"] != "replayed_completed":
    raise ValueError("实验后的独立读取未完成")
for joint, values in recorded["properties"].items():
    if values["axis_state"] != 8 or any(values[name] != 0 for name in (
            "axis_error", "can_error", "motor_error", "encoder_error", "controller_error")):
        raise ValueError(f"{joint} 实验后状态无效")
if abs(recorded["properties"]["J1"]["output_pos_deg"]) > .01:
    raise ValueError("J1 实验后位置没有接近原机械零位")
policy = json.loads((root / ".scratch/motor_control/attended-positioning.json").read_bytes())
if sha256((root / ".scratch/motor_control/stop.json").read_bytes()).hexdigest() != policy["reviewed_stop_sha256"]:
    raise ValueError("主停止记录身份变化")
latch = MotorStopLatch(root / ".scratch/motor_control/attended-positioning-stop.json")
latch.require_clear()
latch.trip(reason="bounded_J1_encoder_experiment_completed", log_path=folder / "j1-return-from5mm.jsonl")
result = {"status": "bounded_experiments_completed", "motion_sessions": 4,
          "last_target_mm": 0, "powered_holding": True, "serial_connection_closed": True,
          "final_readonly_sha256": sha256(source).hexdigest(), "all_axes_closed_loop": True,
          "all_read_errors_zero": True, "reviewed_main_stop_unchanged": True,
          "attended_stop": json.loads(latch.path.read_bytes()),
          "hardware_qualified": False, "physical_stop_independently_verified": False}
with (folder / "scope-completion.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
print("四次有界实验结束，J1 保持零位，九轴状态正常；新的动作继续经过恢复审查。")

import argparse
import json
import time
from dataclasses import asdict, dataclass, replace
from hashlib import sha256
from pathlib import Path

from robot_safecontrol_moveit.attended_positioning import AttendedPositioning
from robot_safecontrol_moveit.drempower_serial import DrEmpowerSerial
from robot_safecontrol_moveit.j1_execution import J1ScrewControl
from robot_safecontrol_moveit.joint_positioning import positioning_limits, single_target_table
from robot_safecontrol_moveit.joint_table_execution import JointTableControl, JointTableExecutor
from robot_safecontrol_moveit.joint_table_readonly import (
    ENCODER_CONFIGURATION_FIELDS, ENCODER_PROPERTIES, read_recorded_property, sample_encoder_properties,
)
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import (
    MotionRejected, SingleJointMonitor, VendorFeedbackReader, VelocityWindow, run_single_joint, stationary_conditions,
)
from work.nineaxis_model import NineaxisModel
from work.robot_units import joints_si_to_mm_deg
from work.static_collision_meshes import mesh_sources


@dataclass(frozen=True)
class ProbeHardware:
    vendor: DrEmpowerSerial
    executor: JointTableExecutor


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
parser = argparse.ArgumentParser()
parser.add_argument("--target-mm", type=float, choices=(0., 1., 5.), required=True)
parser.add_argument("--maximum-mm", type=float, choices=(1., 5.), default=1.)
parser.add_argument("--name", choices=("j1-outward-1mm", "j1-return-0mm", "j1-outward-5mm", "j1-return-from5mm"),
                    required=True)
args = parser.parse_args()
expected = {(1., 1.): "j1-outward-1mm", (1., 0.): "j1-return-0mm",
            (5., 5.): "j1-outward-5mm", (5., 0.): "j1-return-from5mm"}
if expected.get((args.maximum_mm, args.target_mm)) != args.name:
    raise ValueError("动作名称与本次目标不符")
interval_name = "j1-probe-self-interval.json" if args.maximum_mm == 1 else "j1-probe-5mm-self-interval.json"
interval_bytes = (folder / interval_name).read_bytes()
interval = json.loads(interval_bytes)
if interval["self_interval_checked"] is not True or len(interval["rows"]) != 36:
    raise ValueError("完整自身几何范围未证明")
if abs(interval["center_si"][0] + interval["radius_si"][0] - (args.maximum_mm + .1) / 1000) > 1e-12:
    raise ValueError("自身几何证明范围与目标行程不符")
if mesh_sources(root / "portable_oscbf/config/collision_geometry_sources.json") != interval["self_collision_sources"]:
    raise ValueError("自身几何来源身份变化")
reference = joints_si_to_mm_deg(interval["reference_si"]).tolist()
model = NineaxisModel.load(root=root)
table = single_target_table(dict(zip(DEFAULT_JOINT_NAMES, [args.target_mm, *reference[1:]])), model)
speeds = dict(zip(DEFAULT_JOINT_NAMES, [.05, *([2.46] * 8)]))
accelerations = dict(zip(DEFAULT_JOINT_NAMES, [.01, *([.3] * 8)]))
port = "/dev/serial/by-id/usb-Dr-Tech_DR-USB_CAN_87949380174B-if00"
session = AttendedPositioning.load(root, root / ".scratch/motor_control/attended-positioning.json", table,
                                   model, port=port, limits=positioning_limits(root, speeds, accelerations))
executor = JointTableExecutor(table, model, measurement_kind="positioning", task_id="issue-185-counter-probe",
                              feedback_source="hardware_feedback", limits=session.limits, manual_positioning=True)
control = J1ScrewControl.from_root(root)
all_control = JointTableControl(root)
limits = replace(session.limits["J1"], max_step_deg=args.maximum_mm * 72 + .01,
                 max_feedback_rpm=.84, stationary_window_s=5.2)
windows = {joint: VelocityWindow(1., 5.) for joint in DEFAULT_JOINT_NAMES[1:]}
monitors = {joint: SingleJointMonitor(all_control._node(joint), session.limits[joint]) for joint in windows}
fields = ("encoder_turn_abs", "encoder_pos_abs", "rotor_pos_turns", "output_pos_deg", "axis_state",
          "axis_error", "encoder_error", "battery_voltage")
capture = {"status": "preparing", "scope": "attended_bounded_J1_counter_characterisation",
           "model_hash": model.model_hash, "policy": session.report(), "target_mm": args.target_mm,
           "operator_statement": "现在我就在旁边看着，有急停按钮，失能转动有支撑",
           "clearance_statement": ("空间足够，支撑不会阻碍升降" if args.maximum_mm == 1
                                   else "现在量到末端500mm,不会碰到障碍物"),
           "maximum_mm": args.maximum_mm, "self_interval_source": interval_name,
           "self_interval_sha256": sha256(interval_bytes).hexdigest(),
           "hardware_qualified": False, "device_sample_time_known": False,
           "physical_stop_independently_verified": False, "independent_mechanical_position_measured": False,
           "parameter_writes_sent": 0, "properties": {}, "property_observations": [],
           "encoder_samples": [], "encoder_sample_fields": list(fields)}
log_path = folder / f"{args.name}.jsonl"
frames_path = log_path.with_suffix(".frames.json")
capture_path = log_path.with_suffix(".capture.json")
if any(path.exists() for path in (log_path, frames_path, capture_path)):
    raise FileExistsError("本次实验输出已经存在")
try:
    with DrEmpowerSerial(port, command_node=1, axis_type="prismatic") as vendor:
        reader = VendorFeedbackReader(vendor, all_control, .2)
        try:
            vendor.prepare_motion()
            capture["device_properties"] = session.verify_device(ProbeHardware(vendor, executor))
            values = capture["properties"]["J1"] = {}
            for name in dict.fromkeys((*ENCODER_CONFIGURATION_FIELDS, *fields)):
                values[name] = read_recorded_property(vendor, capture, "J1", 1, name, ENCODER_PROPERTIES[name])
            if values["zero_offset_counts"] != 11145 or values["multi_circle_enabled"] != 1:
                raise ValueError("J1 现场零位或多圈设置变化")

            def observe(sample, record):
                session.check_stop()
                latest = {}
                for index, joint in enumerate(DEFAULT_JOINT_NAMES[1:], start=1):
                    reader.require_closed_loop(joint)
                    observed = windows[joint].add(reader.read(joint))
                    monitors[joint].validate_feedback(observed, time.monotonic())
                    if abs(observed.state.angle_deg - reference[index]) > .01:
                        raise MotionRejected(f"{joint}:probe_stationary_position_changed")
                    latest[joint] = observed
                    record("other_joint_feedback", joint=joint, observation=asdict(observed))
                position_mm = sample.state.angle_deg / control.degrees_per_mm
                if not -.1 <= position_mm <= args.maximum_mm + .1:
                    raise MotionRejected("J1:outside_certified_probe_interval")
                sample_encoder_properties(vendor, capture, "J1", 1, fields)
                batch = capture["encoder_samples"][-1]
                current = batch["values"]
                if current["axis_state"] != 8 or current["axis_error"] != 0 or current["encoder_error"] != 0:
                    raise MotionRejected("J1:probe_device_error")
                if max(time.monotonic() - row.request_s for row in [sample, *latest.values()]) > .2:
                    raise MotionRejected("probe_feedback_timeout")
                if sample.stationary_window_duration_s >= limits.stationary_window_s:
                    if not all(all(stationary_conditions(row, session.limits[joint]).values())
                               for joint, row in latest.items()):
                        raise MotionRejected("probe_other_joints_not_stationary")
                record("encoder_properties", capture=batch)

            capture["status"] = "observing_and_moving"
            print(f"J1 目标 {args.target_mm:g} mm；速度 0.05 mm/s，加速度 0.01 mm/s²；其他八轴仅监测。", flush=True)
            run_single_joint(vendor, control, "J1", None, limits, log_path,
                             target_deg=args.target_mm * control.degrees_per_mm, observation_callback=observe)
            capture["status"] = "completed"
            print("J1 已通过真实位置和静止检查，保持目标与使能。", flush=True)
        except BaseException as error:
            capture.update(status="aborted", reason=str(error))
            session.stop_latch.trip(reason=str(error), log_path=log_path)
            raise
        finally:
            with frames_path.open("x", encoding="utf-8") as stream:
                json.dump(vendor.frames, stream, ensure_ascii=False, indent=2, allow_nan=False)
            capture["frames_sha256"] = sha256(frames_path.read_bytes()).hexdigest()
            capture["log_sha256"] = sha256(log_path.read_bytes()).hexdigest() if log_path.exists() else None
            with capture_path.open("x", encoding="utf-8") as stream:
                json.dump(capture, stream, ensure_ascii=False, indent=2, allow_nan=False)
except BaseException:
    print("本次流程已终止；未自动重试、回零、清错或修改设备参数。", flush=True)
    raise

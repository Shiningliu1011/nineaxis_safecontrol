import json
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
vendor_root = root / "大然电机/大然电机所有资料/drempower-wiki-master"
source_files = [
    vendor_root / "README.md",
    vendor_root / "4-库函数/python/interface_enums.py",
    vendor_root / "4-库函数/python/DrEmpower_can.py",
    vendor_root / "1-产品手册及使用说明书/DrEmpower系列电机使用手册 v1.0.pdf",
    vendor_root / "4-库函数/DrEmpower电机库函数说明 v2.1.pdf",
    vendor_root / "5-通信协议/DrEmpower电机CAN通讯协议说明 v2.0.pdf",
    vendor_root / "6-其他资料/DrEmpower系列电机常用参数及地址表.pdf",
    vendor_root / "3-上位机软件/Dr Actuator Terminal v2.1.zip",
]
for path in source_files:
    if not path.is_file():
        raise FileNotFoundError(path)
source_registry = {
    "evidence_kind": "read_manufacturer_sources_and_independent_communication_reference",
    "local_sources": [{"path": str(path.relative_to(root)), "bytes": path.stat().st_size,
                       "sha256": sha256(path.read_bytes()).hexdigest()} for path in source_files],
    "public_repository": {
        "url": "https://github.com/DrRobotTech/drempower-wiki",
        "checked_master_commit": "6239af5dbbb639fb3b69d7eb4a7b77635c6fe65d",
        "matching_local_interface_enums_git_blob": "7d96ae5273fca004977a4919ee92ef35bca78a53",
        "local_control_sdk_and_manual_identical_to_public_master": False,
    },
    "shared_GUI_range_source": {
        "archive_member": "Dr Actuator Terminal v2.0/B0x-HA.txt",
        "line_numbers": [36, 37],
        "current_G_batch_applicability_verified": False,
    },
    "CAN_frame_reference": {
        "url": "https://www.microcontrol.net/service/grundlagen/can-bus/",
        "captured_html_sha256": sha256((folder / "can-bus-reference.html").read_bytes()).hexdigest(),
        "full_page_text_read": True,
        "standard_8byte_frame_bits_without_stuffing": 111,
    },
    "previous_motion_archive": {
        "path": "tests/data/j1_bounded_counter_experiments_20261030.zip",
        "sha256": sha256((root / "tests/data/j1_bounded_counter_experiments_20261030.zip").read_bytes()).hexdigest(),
    },
    "validation": {"command": "bash .scratch/issue-184-research/run_checks.sh",
                   "junitxml": "regression.xml"},
}
files = {name: (folder / name).read_bytes() for name in (
    "nineaxis-current-readonly.json", "nineaxis-operating-readonly.json",
    "nineaxis-operating-current-readonly.json", "operator-conditions.json",
    "operating-replay-summary.json", "four-probe-replay-summary.json", "derived-conclusions.json",
    "analyze_research.py", "run_checks.sh", "regression.xml",
)}
files["source-provenance.json"] = (json.dumps(source_registry, ensure_ascii=False, indent=2) + "\n").encode()
files["tooling_at_archive/capture_operating_state.py"] = (folder / "capture_operating_state.py").read_bytes()
files["tooling_at_archive/archive_research.py"] = Path(__file__).read_bytes()
for name in ("drempower.yaml", "hardware_joint_zero.yaml", "j1_transmission.yaml"):
    files[f"config/{name}"] = (root / "config" / name).read_bytes()
    expected = json.loads(files["nineaxis-current-readonly.json"])["configuration_sha256"][name]
    if sha256(files[f"config/{name}"]).hexdigest() != expected:
        raise ValueError(f"{name} 与采集时的配置不符")
provenance = {
    "evidence_kind": "issue_184_readonly_research_and_previous_motion_recalculation",
    "new_motion_commands_sent": 0, "new_parameter_writes_sent": 0,
    "files": [{"member": name, "bytes": len(content), "sha256": sha256(content).hexdigest()}
              for name, content in files.items()],
}
output = root / "tests/data/motor_positioning_research_20261030.zip"
with ZipFile(output, "x", compression=ZIP_DEFLATED, compresslevel=9) as archive:
    for name, content in files.items():
        archive.writestr(name, content)
    archive.writestr("provenance.json", json.dumps(provenance, ensure_ascii=False, indent=2) + "\n")
with ZipFile(output) as archive:
    if archive.testzip() is not None:
        raise ValueError("研究归档 CRC 校验失败")
    for item in provenance["files"]:
        content = archive.read(item["member"])
        if len(content) != item["bytes"] or sha256(content).hexdigest() != item["sha256"]:
            raise ValueError(f"研究归档成员校验失败：{item['member']}")
print(json.dumps({"output": str(output.relative_to(root)), "members": len(files),
                  "sha256": sha256(output.read_bytes()).hexdigest(), "bytes": output.stat().st_size}))

import json
import runpy
import time
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from zoneinfo import ZoneInfo

from robot_safecontrol_moveit.drempower_serial import DrEmpowerSerial


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
source = root / "大然电机/大然电机所有资料/drempower-wiki-master/4-库函数/python/interface_enums.py"
definitions = runpy.run_path(str(source))
fields = {
    "node_id": ("axis0.config.can_node_id", 31001, "u32"),
    "hw_version": ("hw_version", 5, "u32"),
    "fw_version": ("fw_version", 6, "u32"),
    "can_baud_rate": ("can.config.baud_rate", 21001, "u32"),
    "can_timeout_ms": ("can.config.timeout_ms", 21003, "u32"),
    "control_mode": ("axis0.controller.config.control_mode", 32105, "u32"),
    "input_mode": ("axis0.controller.config.input_mode", 32106, "u32"),
    "input_filter_bandwidth": ("axis0.controller.config.input_filter_bandwidth", 32118, "f32"),
    "trajectory_done": ("axis0.controller.trajectory_done", 32008, "u32"),
}
for name, (canonical, address, kind) in fields.items():
    vendor_kind = definitions["property_type"][canonical]
    if (definitions["property_addresss"][canonical] != address
            or ("f32" if vendor_kind == "f" else vendor_kind) != kind):
        raise ValueError(f"{name} 的地址或类型与厂家 SDK 不符")

port = "/dev/serial/by-id/usb-Dr-Tech_DR-USB_CAN_87949380174B-if00"
report = {
    "started_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
    "status": "reading", "port": port,
    "evidence_kind": "readonly_operating_configuration_and_host_timing",
    "motion_commands_sent": 0, "parameter_writes_sent": 0,
    "device_sample_time_known": False, "hardware_qualified": False,
    "physical_stop_independently_verified": False,
    "field_definitions": fields, "properties": {}, "operating_property_observations": [],
    "feedback_observations": [], "source": str(source.relative_to(root)),
    "source_sha256": sha256(source.read_bytes()).hexdigest(),
}
with (folder / "nineaxis-operating-current-readonly.json").open("x", encoding="utf-8") as stream:
    try:
        # 此连接只有属性读取权限，快速状态请求同样属于属性读取。
        with DrEmpowerSerial(port) as vendor:
            try:
                for node in range(1, 10):
                    values = report["properties"][f"J{node}"] = {}
                    for name, (canonical, address, kind) in fields.items():
                        report["reading_joint"], report["reading_property"] = f"J{node}", name
                        request_s = time.monotonic()
                        value = vendor.read_property(node, address, kind)
                        received_s = time.monotonic()
                        values[name] = value
                        report["operating_property_observations"].append({
                            "name": name, "vendor_name": canonical, "node_id": node,
                            "address": address, "kind": kind, "value": value,
                            "request_s": request_s, "received_s": received_s,
                        })
                    if values["node_id"] != node:
                        raise ValueError(f"J{node} 的节点身份与请求不符")
                report["timing_started_s"] = time.monotonic()
                until = report["timing_started_s"] + 10
                while time.monotonic() < until:
                    for node in range(1, 10):
                        request_s = time.monotonic()
                        position, velocity = vendor.get_state(node)
                        report["feedback_observations"].append({
                            "node_id": node, "request_s": request_s, "received_s": time.monotonic(),
                            "pos_deg": position, "vel_rpm": velocity,
                        })
                report["timing_finished_s"] = time.monotonic()
                report["status"] = "readonly_completed"
            finally:
                report["frames"] = vendor.frames
    except BaseException as error:
        report.update(status="readonly_failed", reason=str(error))
        raise
    finally:
        report["missing_properties"] = {
            f"J{node}": [name for name in fields if name not in report["properties"].get(f"J{node}", {})]
            for node in range(1, 10)
        }
        json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
print(f"只读配置与主机时序采集完成：{stream.name}")

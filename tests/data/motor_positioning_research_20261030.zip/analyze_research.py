import json
import runpy
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile

import numpy as np

from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.motion_log_replay import replay_encoder_probe


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent


def save(name, value):
    with (folder / name).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def statistics(values):
    values = np.asarray(values, dtype=float)
    if values.size == 0 or not np.isfinite(values).all():
        raise ValueError("时序统计需要完整的有限数值")
    return {"count": len(values), "minimum": float(np.min(values)),
            "median": float(np.median(values)), "p95": float(np.percentile(values, 95)),
            "p99": float(np.percentile(values, 99)), "maximum": float(np.max(values))}


def operating_replay(name):
    source = (folder / name).read_bytes()
    recorded = json.loads(source)
    replay = replay_readonly_report(source)
    definitions_path = root / recorded["source"]
    if sha256(definitions_path.read_bytes()).hexdigest() != recorded["source_sha256"]:
        raise ValueError("厂家 SDK 属性定义的身份变化")
    definitions = runpy.run_path(str(definitions_path))
    for canonical, address, kind in recorded["field_definitions"].values():
        sdk_kind = definitions["property_type"][canonical]
        if (definitions["property_addresss"][canonical] != address
                or ("f32" if sdk_kind == "f" else sdk_kind) != kind):
            raise ValueError("读取字段与厂家 SDK 不符")
    ledger, original = recorded["operating_property_observations"], replay["property_observations"]
    if len(ledger) != len(original):
        raise ValueError("属性读取数量与原始帧不符")
    values = {}
    for declared, raw in zip(ledger, original):
        canonical, address, kind = recorded["field_definitions"][declared["name"]]
        if (declared["vendor_name"] != canonical or raw["address"] != address or raw["kind"] != kind
                or any(declared[key] != raw[key] for key in ("node_id", "address", "kind", "value"))
                or not declared["request_s"] <= raw["request_s"] <= raw["received_s"] <= declared["received_s"]):
            raise ValueError("属性值、时间或身份与原始读取事务不符")
        values.setdefault(f"J{raw['node_id']}", {})[declared["name"]] = raw["value"]
    if values != recorded["properties"]:
        raise ValueError("配置报告与原始帧不符")
    feedback = recorded["feedback_observations"]
    if len(feedback) != len(replay["feedback_observations"]):
        raise ValueError("反馈数量与原始帧不符")
    for declared, raw in zip(feedback, replay["feedback_observations"]):
        if (any(declared[key] != raw[key] for key in ("node_id", "pos_deg", "vel_rpm"))
                or not declared["request_s"] <= raw["request_s"] <= raw["received_s"] <= declared["received_s"]
                or raw["axis_error"] or not raw["traj_done"]):
            raise ValueError("静态反馈、主机时间或设备完成标志无效")
    if recorded["motion_commands_sent"] != 0 or recorded["parameter_writes_sent"] != 0:
        raise ValueError("本次研究范围只允许读取")
    result = {"source_sha256": sha256(source).hexdigest(), "source_bytes": len(source),
              "status": replay["status"], "properties": values,
              "verified_property_reads": len(original), "verified_feedback_reads": len(feedback),
              "incomplete_reads": replay["incomplete_reads"], "device_sample_time_known": False,
              "motion_commands_sent": 0, "parameter_writes_sent": 0}
    if feedback:
        elapsed = recorded["timing_finished_s"] - recorded["timing_started_s"]
        if len(feedback) % 9 or [row["node_id"] for row in feedback] != list(range(1, 10)) * (len(feedback) // 9):
            raise ValueError("完整九轴轮询顺序无效")
        result["host_timing"] = {
            "elapsed_s": elapsed, "complete_nineaxis_sweeps": len(feedback) // 9,
            "mean_complete_nineaxis_sweeps_hz": len(feedback) / 9 / elapsed,
            "transaction_ms": statistics([(row["received_s"] - row["request_s"]) * 1000 for row in feedback]),
            "nineaxis_sweep_ms": statistics([
                (feedback[index + 8]["received_s"] - feedback[index]["request_s"]) * 1000
                for index in range(0, len(feedback), 9)]),
            "per_node_receive_gap_ms": {
                f"J{node}": statistics(np.diff([row["received_s"] for row in feedback if row["node_id"] == node]) * 1000)
                for node in range(1, 10)},
            "scope": "sequential_readonly_host_request_receive_without_motion_traffic",
            "worst_case_latency_bound_verified": False,
            "device_sampling_or_adoption_time_verified": False,
        }
    return result


static_source = (folder / "nineaxis-current-readonly.json").read_bytes()
static = replay_readonly_report(static_source)
if static["status"] != "replayed_completed" or set(static["nodes"]) != {str(node) for node in range(1, 10)}:
    raise ValueError("本次九轴静态记录不完整")
for values in static["nodes"].values():
    if (values["axis_state"] != 8
            or any(values[name] for name in ("axis_error", "can_error", "motor_error", "encoder_error", "controller_error"))):
        raise ValueError("本次静态属性存在设备故障")

operating = operating_replay("nineaxis-operating-current-readonly.json")
partial = operating_replay("nineaxis-operating-readonly.json")
if operating["status"] != "replayed_completed" or partial["status"] != "replayed_incomplete":
    raise ValueError("完整与未完成采集的回放状态不符")
save("operating-replay-summary.json", {"complete": operating, "partial": partial})

archive_path = root / "tests/data/j1_bounded_counter_experiments_20261030.zip"
probes = {}
with ZipFile(archive_path) as archive:
    provenance = json.loads(archive.read("provenance.json"))
    files = provenance["files"]
    if len(set(archive.namelist())) != len(archive.namelist()):
        raise ValueError("原始实验归档存在重名成员")
    if {item["member"] for item in files} != set(archive.namelist()) - {"provenance.json"}:
        raise ValueError("实验归档与来源清单不符")
    for item in files:
        source = archive.read(item["member"])
        if len(source) != item["bytes"] or sha256(source).hexdigest() != item["sha256"]:
            raise ValueError(f"实验归档成员身份不符：{item['member']}")
    for prefix in ("j1-outward-1mm", "j1-return-0mm", "j1-outward-5mm", "j1-return-from5mm"):
        result = replay_encoder_probe(archive.read(f"{prefix}.jsonl"),
                                      archive.read(f"{prefix}.frames.json"),
                                      archive.read(f"{prefix}.capture.json"))
        probes[prefix] = {key: result[key] for key in (
            "source_sha256", "frames_sha256", "capture_sha256", "capture_status", "encoder_samples",
            "configuration_unchanged", "initial_encoder", "final_encoder", "counter_relationship",
            "motion_commands_sent", "parameter_writes_sent", "other_joint_motion_commands_sent")}
        print(f"真实动作原始记录复算通过：{prefix}", flush=True)
save("four-probe-replay-summary.json", {"archive_sha256": sha256(archive_path.read_bytes()).hexdigest(),
                                       "verified_archive_members": len(files), "probes": probes})

gear_ratio = static["nodes"]["1"]["gear_ratio"]
lead_mm_per_rev = 5.
full_travel_mm = 500.
full_output_turns = full_travel_mm / lead_mm_per_rev
observed_gains = [probes[name]["counter_relationship"]["turn_abs_per_reported_rotor_turn"]
                  for name in ("j1-outward-5mm", "j1-return-from5mm")]
nominal_counts_per_rotor_turn = 8.
counts_per_mm = nominal_counts_per_rotor_turn * gear_ratio / lead_mm_per_rev
baud_rates = {value["can_baud_rate"] for value in operating["properties"].values()}
if len(baud_rates) != 1:
    raise ValueError("九轴 CAN 速率回读不一致")
can_baud = baud_rates.pop()
bits_per_frame_without_stuffing = 111
rate_hz = 200
frame_models = {"presets_and_broadcast": 10, "plus_nine_explicit_feedback_transactions": 28,
                "plus_nine_automatic_feedback_replies": 19}
save("derived-conclusions.json", {
    "evidence_scope": "manufacturer_sources_actual_readonly_and_previous_bounded_motion_replay",
    "hardware_qualified": False, "full_travel_verified": False, "synchronous_motion_verified": False,
    "new_motion_commands_sent": 0, "new_parameter_writes_sent": 0,
    "current_static": {"source_sha256": sha256(static_source).hexdigest(),
                       "verified_property_reads": len(static["property_observations"]),
                       "verified_feedback_reads": len(static["feedback_observations"]),
                       "nodes": static["nodes"]},
    "observed_turn_abs_gains_per_rotor_turn": observed_gains,
    "nominal_conversion_for_capacity_calculation": {
        "counts_per_rotor_turn": nominal_counts_per_rotor_turn, "gear_ratio": gear_ratio,
        "lead_mm_per_output_rev": lead_mm_per_rev, "counts_per_mm": counts_per_mm,
        "counter_bit_encoding_verified": False},
    "required_full_travel_capacity": {
        "travel_mm": full_travel_mm, "output_revolutions": full_output_turns,
        "rotor_revolutions": full_output_turns * gear_ratio,
        "nominal_turn_abs_increment_magnitude": full_travel_mm * counts_per_mm,
        "additional_stop_margin_counts": None},
    "conditional_shared_gui_range": {
        "minimum": -2048, "maximum": 2047,
        "current_G_batch_applicability_verified": False,
        "width_increments": 4095, "width_mm": 4095 / counts_per_mm,
        "negative_fault_magnitude": 2047, "equivalent_fault_position_mm": 2047 / counts_per_mm,
        "zero_translation_changes_window_width": False},
    "protocol_positive_limits": {"preset_time_max_s": 327.67, "time_quantum_s": .01,
                                 "acceleration_quantum_rpm_s": .01,
                                 "minimum_nonzero_J1_acceleration_mm_s2": .01 * lead_mm_per_rev / 60,
                                 "J1_velocity_lower_bound_for_500mm_in_max_time_mm_s": 500 / 327.67,
                                 "default_500mm_constant_speed_lower_bound_s": 500 / .25},
    "bus_budget": {
        "can_baud_bits_s": can_baud, "proposed_reference_hz_for_calculation": rate_hz,
        "minimum_bits_per_standard_8byte_frame_with_intermission": bits_per_frame_without_stuffing,
        "bit_length_source": "https://www.microcontrol.net/service/grundlagen/can-bus/",
        "bit_stuffing_arbitration_errors_and_other_traffic_included": False,
        "models": {name: {"frames_per_reference_cycle": count,
                           "minimum_bits_s": count * bits_per_frame_without_stuffing * rate_hz,
                           "minimum_bus_utilization": count * bits_per_frame_without_stuffing * rate_hz / can_baud}
                   for name, count in frame_models.items()},
        "actual_motion_traffic_or_interpolation_verified": False,
    },
    "feedback_timing": operating["host_timing"],
    "continuous_filter_bandwidth_per_s": {joint: value["input_filter_bandwidth"]
                                          for joint, value in operating["properties"].items()},
    "field_conditions": {"moving_parts_and_tool_total_mass_kg": None, "maximum_planned_payload_kg": None,
                         "available_independent_instrument": "卷尺", "prior_reported_resolution_mm": 1,
                         "uncertainty_mm": None, "physical_accuracy_acceptance_completed": False},
})
print("研究复算完成：.scratch/issue-184-research/derived-conclusions.json", flush=True)

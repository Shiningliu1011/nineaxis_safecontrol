set -euo pipefail
cd /home/lsn/robot/robot_safecontrol
set +u
source /opt/ros/humble/setup.bash
set -u
export PYTHONPATH="$PWD/src:$PWD/portable_oscbf:$PWD/.scratch/motor_tools/deps:$PWD/.scratch/nineaxis-execution/deps:$PYTHONPATH"
export TMPDIR="$PWD/.scratch/issue-184-research/work"
export ROS_LOG_DIR="$PWD/.scratch/issue-184-research/ros-log"
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
mkdir -p "$TMPDIR" "$ROS_LOG_DIR"
python3 -m pytest tests/test_joint_position_evidence.py tests/test_motion_log_replay.py \
  -q --basetemp=.scratch/issue-184-research/regression \
  --junitxml=.scratch/issue-184-research/regression.xml

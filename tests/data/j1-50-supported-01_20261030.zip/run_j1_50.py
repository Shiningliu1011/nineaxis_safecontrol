import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
import time

import numpy as np

from robot_safecontrol_moveit.attended_positioning import AttendedPositioning
from robot_safecontrol_moveit.joint_positioning import PositioningOperator, positioning_limits, single_target_table
from robot_safecontrol_moveit.joint_table_execution import JointTableControl, JointTableExecutor
from robot_safecontrol_moveit.joint_table_readonly import replay_readonly_report
from robot_safecontrol_moveit.joint_table_runtime import run_joint_table
from robot_safecontrol_moveit.motor_stop_latch import MotorStopLatch
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import MotionRejected
from work.nineaxis_model import NineaxisModel


class BoundedJ1Operator(PositioningOperator):
    def step(self, executor, *, now_s):
        if executor.phase == "moving":
            position_mm = executor.control.project_position("J1", executor.latest["J1"].state.angle_deg)
            if position_mm >= 32.:
                raise MotionRejected("J1:reviewed_pre_overflow_boundary_32mm")
        return super().step(executor, now_s=now_s)


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
parser = argparse.ArgumentParser()
parser.add_argument("--current", type=Path, required=True)
parser.add_argument("--check-only", action="store_true")
parser.add_argument("--supported-continuation", action="store_true")
args = parser.parse_args()
target = [50., 7., -7., 7., -7., 7., 7., -7., 7.]
review_name = "j1-50-supported-review.json" if args.supported_continuation else "j1-50-review.json"
review = json.loads((folder / review_name).read_bytes())
current_source = args.current.read_bytes()
current = json.loads(current_source)
replayed = replay_readonly_report(current_source)
if (current["status"] != "readonly_completed" or replayed["status"] != "replayed_completed"
        or review["target_mm_deg"] != target or len(review["whole_box_self_collision"]) != 36
        or any(row["interval_margin_m"] <= 0 for row in review["whole_box_self_collision"])):
    raise ValueError("J1 本次目标或完整范围检查无效")
control = JointTableControl(root)
position = np.array([control.project_position(joint, current["samples"][-9 + index]["state"]["angle_deg"])
                     for index, joint in enumerate(DEFAULT_JOINT_NAMES)])
if np.any(np.abs(position - review["initial_mm_deg"]) > [.001, *([.01] * 8)]):
    raise ValueError("当前位置已变化，需要重新核对运动范围")
if not 0 <= time.monotonic() - current["samples"][-1]["received_s"] <= 180:
    raise ValueError("执行前读取已经过期")
for joint, values in current["properties"].items():
    if values["axis_state"] != 8 or any(values[name] for name in (
            "axis_error", "can_error", "motor_error", "encoder_error", "controller_error")):
        raise ValueError(f"{joint} 本次状态或故障码无效")
j1 = current["properties"]["J1"]
expected_turns = -1843 if args.supported_continuation else -115
if (j1["multi_circle_enabled"] != 1 or j1["zero_offset_counts"] != 11145
        or j1["encoder_turn_abs"] != expected_turns or j1["gear_ratio"] != 36 or j1["cpr"] != 16384):
    raise ValueError("J1 本次多圈计数配置与实际起点不符")
for name, digest in review["configuration_sha256"].items():
    if sha256((root / "config" / name).read_bytes()).hexdigest() != digest:
        raise ValueError("本次配置身份变化")
stop = MotorStopLatch(root / ".scratch/motor_control/attended-positioning-stop.json")
stop_source = stop.path.read_bytes()
previous_name = "j1-50-bounded-01.report.json" if args.supported_continuation else "larger-position-01.report.json"
previous = json.loads((folder / previous_name).read_bytes())
expected_reason = ("J1:reviewed_pre_overflow_boundary_32mm" if args.supported_continuation
                   else "J7:target_left_settling_tolerance")
if (sha256(stop_source).hexdigest() != review["reviewed_stop_sha256"]
        or json.loads(stop_source)["reason"] != expected_reason
        or previous["termination"]["stop_result"] != "hold_observed"):
    raise ValueError("当前停止记录与已核对原因不符")
if args.supported_continuation:
    operator_evidence = json.loads((folder / "j1-50-supported-operator.json").read_bytes())
    if (operator_evidence["target_mm_deg"] != target or any(operator_evidence[name] is not True for name in (
            "support_holds_j1_load_on_drive_failure", "support_allows_motion", "motion_area_empty",
            "operator_at_power_cutoff"))):
        raise ValueError("完整50mm测试需要现场确认驱动失能时的承重支撑")
if args.check_only:
    print(json.dumps({"current_mm_deg": position.tolist(), "target_mm_deg": target,
                      "protective_stop_at_mm": None if args.supported_continuation else 32., "motion_commands_sent": 0,
                      "multi_circle_enabled": j1["multi_circle_enabled"]}))
    raise SystemExit(0)
run_id = "j1-50-supported-01" if args.supported_continuation else "j1-50-bounded-01"
stop.acknowledge_stop(expected_sha256=sha256(stop_source).hexdigest(),
                      archive_path=folder / f"{run_id}-reviewed-stop.json")
model = NineaxisModel.load(root=root)
table = single_target_table(dict(zip(DEFAULT_JOINT_NAMES, target)), model)
limits = positioning_limits(root, dict(zip(DEFAULT_JOINT_NAMES, review["speed_mm_deg_s"])),
                            dict(zip(DEFAULT_JOINT_NAMES, review["acceleration_mm_deg_s2"])))
port = "/dev/serial/by-id/usb-Dr-Tech_DR-USB_CAN_87949380174B-if00"
session = AttendedPositioning.load(root, root / ".scratch/motor_control/attended-positioning.json", table,
                                   model, port=port, limits=limits)
executor = JointTableExecutor(table, model, measurement_kind="positioning", task_id="j1-50-bounded-test",
                              feedback_source="hardware_feedback", limits=session.limits, manual_positioning=True)
operator_type = PositioningOperator if args.supported_continuation else BoundedJ1Operator
operator = operator_type(sys.stdin, output=sys.stdout, start_immediately=True)
print("J1 目标 50 mm；速度 0.25 mm/s；继续检查全部设备故障和运动反馈。", flush=True)
output = folder / f"{run_id}.jsonl"
run_joint_table(executor, port=port, log_path=output, measurement_dir=folder,
                positioning_operator=operator, attended=session)

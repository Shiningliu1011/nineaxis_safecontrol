from bisect import bisect_left
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path

from robot_safecontrol_moveit.drempower_can import CMD_PROPERTY_READ, can_node_id
from robot_safecontrol_moveit.drempower_joint_control import JointFeedback
from robot_safecontrol_moveit.drempower_serial import SERIAL_CAN_FRAME
from robot_safecontrol_moveit.joint_table_execution import JointTableControl
from robot_safecontrol_moveit.joint_table_readonly import PROPERTY_READ_REQUEST, replay_readonly_report
from robot_safecontrol_moveit.robot_spec import DEFAULT_JOINT_NAMES
from robot_safecontrol_moveit.single_joint_execution import ObservedFeedback
from robot_safecontrol_moveit.tracking_log_replay import _match_commands, _raw_tracking


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).parent
run = "j1-50-supported-01"
log_source = (folder / f"{run}.jsonl").read_bytes()
frames_source = (folder / f"{run}.frames.json").read_bytes()
report = json.loads((folder / f"{run}.report.json").read_bytes())
events = [json.loads(line) for line in log_source.splitlines()]
frames = json.loads(frames_source)
request, missing = frames[-2:]
parsed = SERIAL_CAN_FRAME.parse(bytes.fromhex(request["raw_hex"]))
field = PROPERTY_READ_REQUEST.parse(parsed.data)
if (request["direction"] != "tx" or missing["direction"] != "rx" or missing["raw_hex"] != ""
        or can_node_id(parsed.frame_id) != (1, CMD_PROPERTY_READ) or field.address != 30002
        or field.type_code != 3 or missing["monotonic_s"] <= request["monotonic_s"]
        or report["phase"] != "aborted" or report["termination"]["stop_result"] != "external_stop_required"):
    raise ValueError("末次未完成读取与运行终态不符")
control = JointTableControl(root)
# 完整事务前段与最后一次无回复事务分别核验，原始记录保持完整。
trace = _raw_tracking({"frames": frames[:-2], "status": "aborted"}, control)
_match_commands([{**row, "event": "low_speed_seed_requested"} if row["event"] == "command_requested"
                 else row for row in events], trace, control)
if len(trace["positions"]) != 9 or trace["broadcasts"] or set(trace["tx_commands"]) != {"0x1a", "0x1e"}:
    raise ValueError("50 mm 测试的实际命令范围无效")
by_joint = {joint: [row for row in trace["feedback"] if row["joint"] == joint] for joint in DEFAULT_JOINT_NAMES}
times = {joint: [row["received_s"] for row in rows] for joint, rows in by_joint.items()}
matched = set()
for event in events:
    if event["event"] != "feedback":
        continue
    for joint, value in event["samples"].items():
        raw = by_joint[joint][bisect_left(times[joint], value["request_s"])]
        sample = ObservedFeedback(raw["node_id"], JointFeedback(**raw["state"]),
                                  value["request_s"], value["received_s"], raw["traj_done"], raw["axis_error"])
        if (asdict(sample) != value or not value["request_s"] <= raw["received_s"] <= value["received_s"]
                or raw["raw_frame_index"] in matched):
            raise ValueError("50 mm 测试反馈与原始回复不符")
        matched.add(raw["raw_frame_index"])
post_source = (folder / "j1-50-post-power-encoder.json").read_bytes()
post = replay_readonly_report(post_source)
other_source = (folder / "j1-50-post-power-other-axes.json").read_bytes()
other = replay_readonly_report(other_source)
if post["status"] != "replayed_completed" or other["status"] != "replayed_completed" or len(other["nodes"]) != 8:
    raise ValueError("上电后诊断记录不完整")
initial, fault = trace["readonly"]["initial_nodes"]["1"], post["nodes"]["1"]
for name in ("zero_offset_counts", "multi_circle_enabled"):
    if initial[name] != fault[name]:
        raise ValueError("故障前后计数配置不一致")
if (fault["axis_state"] != 1 or fault["axis_error"] != 257 or fault["encoder_error"] != 512
        or fault["encoder_turn_abs"] != -2047 or fault["multi_circle_enabled"] != 1):
    raise ValueError("本次故障原始读取与复核结论不符")
for values in other["nodes"].values():
    if values["axis_state"] != 8 or any(values[name] for name in (
            "axis_error", "can_error", "motor_error", "encoder_error", "controller_error")):
        raise ValueError("其他关节上电后存在故障")
result = {
    "status": "incomplete_run_and_post_power_fault_verified", "target_j1_mm": 50,
    "initial_j1_mm": by_joint["J1"][0]["position"], "last_valid_j1_mm": by_joint["J1"][-1]["position"],
    "last_feedback_axis_error": by_joint["J1"][-1]["axis_error"],
    "matched_samples": len(matched), "raw_feedback_samples": len(trace["feedback"]),
    "position_commands": len(trace["positions"]), "complete_prefix_tx_commands": trace["tx_commands"],
    "incomplete_terminal_read": {"node_id": 1, "address": field.address, "request": request, "response": missing},
    "post_power_j1": fault, "other_axes_state8_error0": True,
    "journal_sha256": sha256(log_source).hexdigest(), "frames_sha256": sha256(frames_source).hexdigest(),
    "post_power_sha256": sha256(post_source).hexdigest(), "other_axes_sha256": sha256(other_source).hexdigest(),
    "physical_stop_independently_verified": False, "independent_physical_precision_verified": False,
    "device_sample_time_known": False, "goal_50mm_reached": False,
}
with (folder / f"{run}-validation.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps(result, ensure_ascii=False, indent=2))

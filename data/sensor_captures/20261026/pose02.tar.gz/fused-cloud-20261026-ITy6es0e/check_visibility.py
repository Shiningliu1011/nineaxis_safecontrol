import json
import time
from pathlib import Path

import cv2
from cv_bridge import CvBridge
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties, fontManager
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CameraInfo, Image, PointCloud2
from sensor_msgs_py import point_cloud2

work = Path(__file__).resolve().parent
clouds = []
latest = {}
def callback_cloud(message):
    assert message.header.frame_id == "livox_frame"
    points = point_cloud2.read_points(message, field_names=("x", "y", "z", "intensity"), skip_nans=True)
    values = np.column_stack([points[key] for key in ("x", "y", "z", "intensity")])
    clouds.append(values[np.isfinite(values).all(axis=1) & (np.linalg.norm(values[:, :3], axis=1) > 0.1)])
def callback(name, message):
    latest[name] = message
rclpy.init()
node = Node("independent_sensor_visibility")
subscriptions = [node.create_subscription(PointCloud2, "/livox/lidar", callback_cloud, qos_profile_sensor_data)]
for name, topic, message_type in [("image", "/camera/color/image_raw", Image),
                                 ("camera", "/camera/depth_registered/points", PointCloud2),
                                 ("info", "/camera/color/camera_info", CameraInfo)]:
    subscriptions.append(node.create_subscription(message_type, topic, lambda message, name=name: callback(name, message), qos_profile_sensor_data))
start = time.monotonic()
while time.monotonic() - start < 10:
    rclpy.spin_once(node, timeout_sec=0.1)
node.destroy_node()
rclpy.shutdown()
assert len(clouds) > 70 and set(latest) == {"image", "camera", "info"}
lidar = np.concatenate(clouds)
message = latest["camera"]
assert message.header.frame_id == "camera_color_optical_frame"
points = point_cloud2.read_points(message, field_names=("x", "y", "z"), skip_nans=True)
camera = np.column_stack([points[key] for key in ("x", "y", "z")])
camera = camera[np.isfinite(camera).all(axis=1) & (np.linalg.norm(camera, axis=1) > 0.1)]
np.savez_compressed(work / "independent_clouds.npz", lidar=lidar, camera=camera)
image = CvBridge().imgmsg_to_cv2(latest["image"], desired_encoding="bgr8")
assert cv2.imwrite(str(work / "current-camera.png"), image)
summary = {"lidar_frames": len(clouds), "lidar_points": len(lidar), "camera_points": len(camera),
           "camera_matrix": np.array(latest["info"].k).reshape(3, 3).tolist(),
           "distortion": list(latest["info"].d), "cross_sensor_transform_applied": False}
(work / "inspection.json").write_text(json.dumps(summary, indent=2))
fontManager.addfont("/home/lsn/.local/share/fonts/robot_figures/Times.TTF")
fontManager.addfont("/home/lsn/.local/share/fonts/robot_figures/simsun.ttc")
cn = FontProperties(fname="/home/lsn/.local/share/fonts/robot_figures/simsun.ttc")
plt.rcParams["font.family"] = "Times New Roman"
ranges = np.linalg.norm(lidar[:, :3], axis=1)
azimuth = np.degrees(np.arctan2(lidar[:, 1], lidar[:, 0]))
elevation = np.degrees(np.arctan2(lidar[:, 2], np.linalg.norm(lidar[:, :2], axis=1)))
fig, axis = plt.subplots(figsize=(24, 6), facecolor="white")
axis.set_facecolor("#111b29")
valid = ranges < 6
order = np.argsort(ranges[valid])[::-1]
artist = axis.scatter(azimuth[valid][order], elevation[valid][order], c=ranges[valid][order], s=0.15,
                      cmap="turbo", vmin=0.2, vmax=6, linewidths=0)
axis.set(xlim=(-180, 180), ylim=(-10, 55), xlabel="Azimuth (deg)", ylabel="Elevation (deg)")
axis.set_title("雷达自身坐标中的周围观测", fontproperties=cn, fontsize=18)
fig.colorbar(artist, ax=axis, label="Range (m)")
fig.tight_layout()
fig.savefig(work / "lidar-panorama.png", dpi=160)
plt.close(fig)
print(json.dumps(summary))

import json
from pathlib import Path

import cv2
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties, fontManager
from matplotlib.ft2font import FT2Font
from matplotlib.lines import Line2D
import numpy as np
import open3d as o3d
from scipy.spatial import cKDTree

work = Path(__file__).resolve().parent
root = work.parents[1]
calibration_path = root / "docs/calibration/lidar_camera_20261026.json"
calibration = json.loads(calibration_path.read_text())
assert calibration["validation_passed"]
assert calibration["frame_from"] == "livox_frame"
assert calibration["frame_to"] == "camera_color_optical_frame"
matrix = np.array(calibration["matrix"])
capture = json.loads((work / "inspection.json").read_text())
data = np.load(work / "independent_clouds.npz")
camera = data["camera"]
lidar = data["lidar"][:, :3] @ matrix[:3, :3].T + matrix[:3, 3]
intrinsic = np.array(capture["camera_matrix"])
photo = cv2.imread(str(work / "current-camera.png"))
assert photo is not None
photo = cv2.undistort(photo, intrinsic, np.array(capture["distortion"]))


def project(points):
    pixels, _ = cv2.projectPoints(points, np.zeros(3), np.zeros(3), intrinsic, None)
    return pixels[:, 0]


def crop(points):
    lower = np.array([-0.75, -0.35, 0.45])
    upper = np.array([0.35, 1.15, 2.40])
    return points[np.isfinite(points).all(axis=1) & (points > lower).all(axis=1)
                  & (points < upper).all(axis=1)]


def cloud_from(points, colors):
    cloud = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(points))
    cloud.colors = o3d.utility.Vector3dVector(colors)
    return cloud.voxel_down_sample(0.005)


camera_roi = crop(camera)
lidar_roi = crop(lidar)
assert len(camera_roi) > 1000 and len(lidar_roi) > 1000
camera_pixels = np.rint(project(camera_roi)).astype(int)
inside = ((camera_pixels[:, 0] >= 0) & (camera_pixels[:, 0] < photo.shape[1])
          & (camera_pixels[:, 1] >= 0) & (camera_pixels[:, 1] < photo.shape[0]))
camera_roi, camera_pixels = camera_roi[inside], camera_pixels[inside]
camera_colors = photo[camera_pixels[:, 1], camera_pixels[:, 0], ::-1].astype(float) / 255.0
lidar_color = np.array([1.0, 0.48, 0.06])
camera_cloud = cloud_from(camera_roi, camera_colors)
lidar_cloud = cloud_from(lidar_roi, np.tile(lidar_color, (len(lidar_roi), 1)))
merged = camera_cloud + lidar_cloud
for name, cloud in [("camera_roi", camera_cloud), ("lidar_roi", lidar_cloud),
                    ("merged_camera_frame", merged)]:
    assert o3d.io.write_point_cloud(str(work / f"{name}.pcd"), cloud)
    restored = o3d.io.read_point_cloud(str(work / f"{name}.pcd"))
    assert len(restored.points) == len(cloud.points) and np.isfinite(restored.points).all()

# 用右侧真实地面点确定图片朝向，点云文件始终保留在相机光学坐标中。
full_pixels = project(camera)
floor_mask = ((full_pixels[:, 0] > 850) & (full_pixels[:, 0] < 1150)
              & (full_pixels[:, 1] > 500) & (full_pixels[:, 1] < 760)
              & (camera[:, 2] > 0.4) & (camera[:, 2] < 4.5))
floor_cloud = o3d.geometry.PointCloud(o3d.utility.Vector3dVector(camera[floor_mask]))
floor_cloud = floor_cloud.voxel_down_sample(0.02)
assert len(floor_cloud.points) > 300
plane, inliers = floor_cloud.segment_plane(0.015, 3, 600)
assert len(inliers) > 0.65 * len(floor_cloud.points)
plane = np.array(plane)
plane /= np.linalg.norm(plane[:3])
if plane[1] > 0:
    plane = -plane
up = plane[:3]
assert up[1] < -0.3
forward = np.array([0.0, 0.0, 1.0])
forward -= up * np.dot(forward, up)
forward /= np.linalg.norm(forward)
right = np.cross(forward, up)
display_rotation = np.vstack([right, forward, up])
assert np.isclose(np.linalg.det(display_rotation), 1.0)
display_origin = -plane[3] * up
camera_points = np.asarray(camera_cloud.points)
lidar_points = np.asarray(lidar_cloud.points)
camera_display = (camera_points - display_origin) @ display_rotation.T
lidar_display = (lidar_points - display_origin) @ display_rotation.T
all_display = np.vstack([camera_display, lidar_display])
lower = all_display.min(axis=0) - 0.05
upper = all_display.max(axis=0) + 0.05
sample_indices = np.linspace(0, len(lidar_points) - 1, min(20000, len(lidar_points)), dtype=int)
distances, _ = cKDTree(camera_points).query(lidar_points[sample_indices])

cn_path = "/home/lsn/.local/share/fonts/robot_figures/simsun.ttc"
en_path = "/home/lsn/.local/share/fonts/robot_figures/Times.TTF"
fontManager.addfont(cn_path)
fontManager.addfont(en_path)
cn = FontProperties(fname=cn_path)
assert cn.get_name() == "SimSun"
assert FontProperties(fname=en_path).get_name() == "Times New Roman"
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["axes.unicode_minus"] = False
fig = plt.figure(figsize=(20, 9), facecolor="white")
grid = fig.add_gridspec(1, 3, width_ratios=[0.85, 1.35, 1.35])
photo_axis = fig.add_subplot(grid[0])
photo_axis.imshow(cv2.cvtColor(photo, cv2.COLOR_BGR2RGB))
photo_axis.set(xlim=(270, 780), ylim=(800, 300))
photo_axis.axis("off")
photo_axis.set_title("机械臂当前画面", fontproperties=cn, fontsize=20)
views = [(grid[1], "合并点云：斜视", 26, -66), (grid[2], "合并点云：侧视", 18, -8)]
for position, title, elevation, azimuth in views:
    axis = fig.add_subplot(position, projection="3d")
    axis.set_facecolor("#f5f7fa")
    axis.scatter(camera_display[:, 0], camera_display[:, 1], camera_display[:, 2],
                 c=np.asarray(camera_cloud.colors), s=1.0, depthshade=False, linewidths=0)
    axis.scatter(lidar_display[:, 0], lidar_display[:, 1], lidar_display[:, 2],
                 color=lidar_color, s=2.0, depthshade=False, linewidths=0)
    axis.set(xlim=(lower[0], upper[0]), ylim=(lower[1], upper[1]), zlim=(lower[2], upper[2]),
             xlabel="X (m)", ylabel="Y (m)", zlabel="Z (m)")
    axis.set_box_aspect(upper - lower)
    axis.view_init(elev=elevation, azim=azimuth)
    axis.set_title(title, fontproperties=cn, fontsize=20, pad=16)
    axis.tick_params(labelsize=10)
    axis.xaxis.pane.set_facecolor((0.97, 0.98, 1.0, 0.2))
    axis.yaxis.pane.set_facecolor((0.97, 0.98, 1.0, 0.2))
    axis.zaxis.pane.set_facecolor((0.97, 0.98, 1.0, 0.2))
legend = [Line2D([0], [0], marker="o", color="none", markerfacecolor="#555555",
                  markersize=7, label="相机彩色点云"),
          Line2D([0], [0], marker="o", color="none", markerfacecolor=lidar_color,
                  markersize=7, label="雷达点云")]
fig.legend(handles=legend, loc="lower center", bbox_to_anchor=(0.59, 0.08),
           ncol=2, prop=cn, frameon=False)
fig.text(0.58, 0.035, "静态累计十秒；图中朝向根据地面调整；时间同步尚未验证", fontproperties=cn,
         ha="center", fontsize=15)
fig.subplots_adjust(left=0.02, right=0.98, bottom=0.18, top=0.90, wspace=0.02)
for text in fig.findobj(matplotlib.text.Text):
    if any(ord(char) > 127 for char in text.get_text()):
        assert all(ord(char) in FT2Font(cn_path).get_charmap()
                   for char in text.get_text() if not char.isspace())
output = root / "picture/robot_fused_cloud_20261026.png"
fig.savefig(output, dpi=170, bbox_inches="tight", pad_inches=0.15)
plt.close(fig)
report = {"calibration": str(calibration_path.relative_to(root)),
          "frame": "camera_color_optical_frame", "voxel_m": 0.005,
          "roi_min_m": [-0.75, -0.35, 0.45], "roi_max_m": [0.35, 1.15, 2.4],
          "raw_lidar_points": capture["lidar_points"], "lidar_frames": capture["lidar_frames"],
          "raw_camera_points": capture["camera_points"],
          "camera_roi_points": len(camera_points), "lidar_roi_points": len(lidar_points),
          "merged_points": len(merged.points),
          "lidar_to_camera_nearest_distance_median_m": float(np.median(distances)),
          "lidar_to_camera_nearest_distance_p95_m": float(np.percentile(distances, 95)),
          "display_floor_plane_in_camera": plane.tolist(),
          "time_synchronization_verified": False, "base_link_transform_verified": False,
          "static_accumulation": True, "image": str(output.relative_to(root))}
(work / "fusion-report.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))

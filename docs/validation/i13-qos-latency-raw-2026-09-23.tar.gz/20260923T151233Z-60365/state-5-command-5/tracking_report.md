# 路径跟踪评价报告

- 任务质量：不通过；在线门控：证据不足
- 全部所需判据：不通过（仅限下述证据范围，不授予实机准入）
- 证据：model；测量边界：kernel_candidate
- 运行：oscbf-runtime-20260923T151258.779673Z-fb6f03a1660f49318426f3cb2fc6c2f7；工况：configured path; obstacles=False
- 测量定义：post-integration model q_next and command reference; QP rows at solve input; before command filter; no execution feedback；时间基准：perf_counter sample start; step_once includes kernel and host diagnostics
- 模型 / 配置 / 路径 / 数据身份：/home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151233Z-60365/state-5-command-5/runtime_snapshots/oscbf-runtime-20260923T151258.779673Z-fb6f03a1660f49318426f3cb2fc6c2f7.json#software / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151233Z-60365/state-5-command-5/runtime_snapshots/oscbf-runtime-20260923T151258.779673Z-fb6f03a1660f49318426f3cb2fc6c2f7.json / sha256:a4aa60dbde62d798d37266882556a6103ba401d1f3e449b6eb9d7cc1641bfc91 / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151233Z-60365/state-5-command-5/runtime_snapshots/oscbf-runtime-20260923T151258.779673Z-fb6f03a1660f49318426f3cb2fc6c2f7.json#kernel_step_sequence
- 总样本：1704；终止原因：interrupted
- 样本记录 SHA-256：a65b3e6a1e976365a9852ec145ef41f1f3dba9af3c39e173e1a3b67a4272ea34
- 声明范围：EvaluationScope(total_length_m=1.8167634936816308, start_m=0.0, end_m=1.8167634936816308)；初始/最终投影弧长：0 / 0.178088 m
- 绝对弧长比：0.098025；本次区间覆盖比：0.098025
- 本次区间完成：False；整条路径覆盖：False；全部所需判据下整条路径验证：False
- 采样耗时：22.1501 s；计算 deadline：20 ms；超期率：0
- 未采集边界：filtered_command, simulated_state, real_feedback

## 误差及诊断统计

统计按样本等权；部分有效样本仍可供诊断，缺失/无效样本阻止对应指标通过。

| 指标（单位见定义） | 有效/缺失/无效 | 均值 | RMS | p95 | 最小 | 最大 |
|---|---|---|---|---|---|---|
| actual_tangent_speed_m_s | 1704/0/0 | 0.0405934 | 0.0649023 | 0.147038 | 0.0096381 | 0.151709 |
| cross_track_m | 1704/0/0 | 0.000125818 | 0.00057098 | 0.000145134 | 1.01525e-05 | 0.00583726 |
| delta_slack | 1704/0/0 | 6.43039e-11 | 1.41172e-10 | 3.92243e-10 | 5.99123e-13 | 4.26085e-10 |
| feedrate_m_s | 1704/0/0 | 0.0725621 | 0.117222 | 0.267015 | 0.0171163 | 0.269929 |
| legacy_orientation_error | 1704/0/0 | 0.00783186 | 0.0125626 | 0.0313271 | 0.000128635 | 0.0366352 |
| obstacle_clearance_m | 0/1704/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| obstacle_margin_m | 0/1704/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| online_cross_track_m | 1704/0/0 | 0.00018471 | 0.000760099 | 0.000320461 | 1.76679e-06 | 0.00716124 |
| pos_error_m | 1704/0/0 | 0.00999025 | 0.0100169 | 0.0102974 | 0.000738129 | 0.0139582 |
| qp_primal_residual | 1704/0/0 | 0 | 0 | 0 | 0 | 0 |
| source_time_s | 1704/0/0 | 2.59862 | 2.68692 | 3.12864 | 0.298154 | 3.15435 |
| step_latency_ms | 1704/0/0 | 8.65716 | 8.6959 | 10.0241 | 6.80839 | 16.7968 |
| tool_axis_error_rad | 1704/0/0 | 0.00783258 | 0.0125643 | 0.0313322 | 0.000128635 | 0.0366434 |

## 逐项判据与来源

| 指标 | 类别 | 阈值/单位 | 状态 | 测量值 | 结论 | 来源/原因 |
|---|---|---|---|---|---|---|
| cross_track_m.rms | task | <= 0.00015 m | accepted | 0.00057098 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.p95 | task | <= 0.0005 m | accepted | 0.000145134 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.maximum | task | <= 0.002 m | accepted | 0.00583726 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| tool_axis_error_rad.rms | task | <= 0.000872665 rad | accepted | 0.0125643 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| tool_axis_error_rad.maximum | task | <= 0.00872665 rad | accepted | 0.0366434 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| qp_success_rate | task | >= 0.999 1 | accepted | 1 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| obstacle_clearance_nonnegative | safety | >= 0 m | accepted | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; nonnegative clearance alone does not prove non-overlap; required samples missing or invalid |
| obstacle_clearance_m.minimum | safety | >= 0.03 m | provisional | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; geometry/scope pending #8/#18; threshold not accepted for this scope |
| deadline_miss_rate | timing | <= 0.01 1 | provisional | 0 | 证据不足 | GitHub #14 resolution 2026-09-04; deadline must match current measured boundary/config; threshold not accepted for this scope |

## 在线门控与约束

- QP：success=1，失败=0，缺失/无效=0
- 准入：{'unmeasured': 1704}；重叠：{'unmeasured': 1704}
- 状态事件：{}；限制因素：{0: 411, 2: 1293}
- 几何裕度、原始约束残差和松弛分别报告；不同量纲不相加。

- legacy_orientation_error 是旧控制误差诊断；delta_slack/qp_primal_residual 是跨类求解诊断，不能当作米解释，物理量请使用逐类数据。

```json
{
  "esdf.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 1704,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 1704
  },
  "esdf.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 1704,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 1704
  },
  "joint_angular.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "rad/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 1704,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_angular.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "rad",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 1704,
      "missing": 0,
      "invalid": 0,
      "mean": 0.03371251330049508,
      "rms": 0.054536448802412256,
      "p95": 0.14055096457025382,
      "minimum": 0.010397359988800101,
      "maximum": 0.16229133004220464
    },
    "inactive_count": 0
  },
  "joint_linear.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 1704,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_linear.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 1704,
      "missing": 0,
      "invalid": 0,
      "mean": 0.021276790825466917,
      "rms": 0.041442382320434845,
      "p95": 0.10629512285890638,
      "minimum": 0.0017657319755003485,
      "maximum": 0.1089111407694164
    },
    "inactive_count": 0
  },
  "obstacle.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 1704,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 1704
  },
  "obstacle.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 1704,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 1704
  },
  "self_collision.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 1704,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "self_collision.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 1704,
      "missing": 0,
      "invalid": 0,
      "mean": 0.25712116629389803,
      "rms": 0.2572853123743997,
      "p95": 0.2709313990248484,
      "minimum": 0.2392260942148357,
      "maximum": 0.2725456191068351
    },
    "inactive_count": 0
  },
  "singularity.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "model_manipulability/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 1704,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "singularity.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "model_manipulability",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 1704,
      "missing": 0,
      "invalid": 0,
      "mean": 0.7389267275860361,
      "rms": 0.7391872964740162,
      "p95": 0.7739164191839639,
      "minimum": 0.7084353623030059,
      "maximum": 0.7790791189203914
    },
    "inactive_count": 0
  }
}
```

## 数据与范围限制

- declared interval has not been validly completed

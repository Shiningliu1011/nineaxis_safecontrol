# 路径跟踪评价报告

- 任务质量：不通过；在线门控：证据不足
- 全部所需判据：不通过（仅限下述证据范围，不授予实机准入）
- 证据：model；测量边界：kernel_candidate
- 运行：oscbf-runtime-20260923T151436.296895Z-bb840ccf82974f689dd9ff65e9e6f96e；工况：configured path; obstacles=False
- 测量定义：post-integration model q_next and command reference; QP rows at solve input; before command filter; no execution feedback；时间基准：perf_counter sample start; step_once includes kernel and host diagnostics
- 模型 / 配置 / 路径 / 数据身份：/home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151233Z-60365/state-20-command-5/runtime_snapshots/oscbf-runtime-20260923T151436.296895Z-bb840ccf82974f689dd9ff65e9e6f96e.json#software / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151233Z-60365/state-20-command-5/runtime_snapshots/oscbf-runtime-20260923T151436.296895Z-bb840ccf82974f689dd9ff65e9e6f96e.json / sha256:a4aa60dbde62d798d37266882556a6103ba401d1f3e449b6eb9d7cc1641bfc91 / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151233Z-60365/state-20-command-5/runtime_snapshots/oscbf-runtime-20260923T151436.296895Z-bb840ccf82974f689dd9ff65e9e6f96e.json#kernel_step_sequence
- 总样本：2043；终止原因：interrupted
- 样本记录 SHA-256：5e603891b0478784ce18c76298780c34d76b59540e5044143841e1d5c5cefb79
- 声明范围：EvaluationScope(total_length_m=1.8167634936816308, start_m=0.0, end_m=1.8167634936816308)；初始/最终投影弧长：0 / 0.183329 m
- 绝对弧长比：0.10091；本次区间覆盖比：0.10091
- 本次区间完成：False；整条路径覆盖：False；全部所需判据下整条路径验证：False
- 采样耗时：22.0899 s；计算 deadline：20 ms；超期率：0
- 未采集边界：filtered_command, simulated_state, real_feedback

## 误差及诊断统计

统计按样本等权；部分有效样本仍可供诊断，缺失/无效样本阻止对应指标通过。

| 指标（单位见定义） | 有效/缺失/无效 | 均值 | RMS | p95 | 最小 | 最大 |
|---|---|---|---|---|---|---|
| actual_tangent_speed_m_s | 2043/0/0 | 0.0356036 | 0.0595112 | 0.14639 | 0.00945041 | 0.150728 |
| cross_track_m | 2043/0/0 | 0.000116597 | 0.000541361 | 0.000144931 | 1.01525e-05 | 0.0056854 |
| delta_slack | 2043/0/0 | 5.59138e-11 | 1.30525e-10 | 3.59374e-10 | 6.08585e-13 | 4.25921e-10 |
| feedrate_m_s | 2043/0/0 | 0.063628 | 0.107513 | 0.266331 | 0.0169301 | 0.269959 |
| legacy_orientation_error | 2043/0/0 | 0.00709989 | 0.0116459 | 0.0303883 | 6.2257e-05 | 0.0358893 |
| obstacle_clearance_m | 0/2043/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| obstacle_margin_m | 0/2043/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| online_cross_track_m | 2043/0/0 | 0.000168925 | 0.000722224 | 0.000314891 | 1.76679e-06 | 0.00702841 |
| pos_error_m | 2043/0/0 | 0.00998366 | 0.010005 | 0.0100308 | 0.000738129 | 0.0133807 |
| qp_primal_residual | 2043/0/0 | 0 | 0 | 0 | 0 | 0 |
| source_time_s | 2043/0/0 | 2.68904 | 2.76447 | 3.19027 | 0.298154 | 3.21969 |
| step_latency_ms | 2043/0/0 | 8.10183 | 8.133 | 9.31189 | 6.58561 | 13.0486 |
| tool_axis_error_rad | 2043/0/0 | 0.00710051 | 0.0116475 | 0.030393 | 6.2257e-05 | 0.035897 |

## 逐项判据与来源

| 指标 | 类别 | 阈值/单位 | 状态 | 测量值 | 结论 | 来源/原因 |
|---|---|---|---|---|---|---|
| cross_track_m.rms | task | <= 0.00015 m | accepted | 0.000541361 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.p95 | task | <= 0.0005 m | accepted | 0.000144931 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.maximum | task | <= 0.002 m | accepted | 0.0056854 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| tool_axis_error_rad.rms | task | <= 0.000872665 rad | accepted | 0.0116475 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| tool_axis_error_rad.maximum | task | <= 0.00872665 rad | accepted | 0.035897 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| qp_success_rate | task | >= 0.999 1 | accepted | 1 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| obstacle_clearance_nonnegative | safety | >= 0 m | accepted | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; nonnegative clearance alone does not prove non-overlap; required samples missing or invalid |
| obstacle_clearance_m.minimum | safety | >= 0.03 m | provisional | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; geometry/scope pending #8/#18; threshold not accepted for this scope |
| deadline_miss_rate | timing | <= 0.01 1 | provisional | 0 | 证据不足 | GitHub #14 resolution 2026-09-04; deadline must match current measured boundary/config; threshold not accepted for this scope |

## 在线门控与约束

- QP：success=1，失败=0，缺失/无效=0
- 准入：{'unmeasured': 2043}；重叠：{'unmeasured': 2043}
- 状态事件：{}；限制因素：{0: 407, 2: 1636}
- 几何裕度、原始约束残差和松弛分别报告；不同量纲不相加。

- legacy_orientation_error 是旧控制误差诊断；delta_slack/qp_primal_residual 是跨类求解诊断，不能当作米解释，物理量请使用逐类数据。

```json
{
  "esdf.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 2043,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2043
  },
  "esdf.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 2043,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2043
  },
  "joint_angular.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "rad/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2043,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_angular.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "rad",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2043,
      "missing": 0,
      "invalid": 0,
      "mean": 0.030631559010234125,
      "rms": 0.05023749104716068,
      "p95": 0.13665152546894724,
      "minimum": 0.010386987096532749,
      "maximum": 0.16188288238930038
    },
    "inactive_count": 0
  },
  "joint_linear.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2043,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_linear.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2043,
      "missing": 0,
      "invalid": 0,
      "mean": 0.017913468139337314,
      "rms": 0.0374870713179168,
      "p95": 0.10378127897497094,
      "minimum": 0.0017631527432817682,
      "maximum": 0.1089111407694164
    },
    "inactive_count": 0
  },
  "obstacle.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 2043,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2043
  },
  "obstacle.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 2043,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2043
  },
  "self_collision.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2043,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "self_collision.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2043,
      "missing": 0,
      "invalid": 0,
      "mean": 0.25929432573280536,
      "rms": 0.25949152236325096,
      "p95": 0.2748510090738106,
      "minimum": 0.2392260942148357,
      "maximum": 0.2768012588854529
    },
    "inactive_count": 0
  },
  "singularity.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "model_manipulability/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2043,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "singularity.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "model_manipulability",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2043,
      "missing": 0,
      "invalid": 0,
      "mean": 0.7439594000882952,
      "rms": 0.7443394001479177,
      "p95": 0.7861013814246122,
      "minimum": 0.7078725416712841,
      "maximum": 0.7920332016426876
    },
    "inactive_count": 0
  }
}
```

## 数据与范围限制

- declared interval has not been validly completed

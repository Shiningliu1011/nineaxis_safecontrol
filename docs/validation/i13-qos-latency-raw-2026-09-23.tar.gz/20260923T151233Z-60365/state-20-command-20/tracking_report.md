# 路径跟踪评价报告

- 任务质量：不通过；在线门控：证据不足
- 全部所需判据：不通过（仅限下述证据范围，不授予实机准入）
- 证据：model；测量边界：kernel_candidate
- 运行：oscbf-runtime-20260923T151524.541630Z-d48fc5cfef8c4655b76d4e8a7a43f247；工况：configured path; obstacles=False
- 测量定义：post-integration model q_next and command reference; QP rows at solve input; before command filter; no execution feedback；时间基准：perf_counter sample start; step_once includes kernel and host diagnostics
- 模型 / 配置 / 路径 / 数据身份：/home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151233Z-60365/state-20-command-20/runtime_snapshots/oscbf-runtime-20260923T151524.541630Z-d48fc5cfef8c4655b76d4e8a7a43f247.json#software / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151233Z-60365/state-20-command-20/runtime_snapshots/oscbf-runtime-20260923T151524.541630Z-d48fc5cfef8c4655b76d4e8a7a43f247.json / sha256:a4aa60dbde62d798d37266882556a6103ba401d1f3e449b6eb9d7cc1641bfc91 / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151233Z-60365/state-20-command-20/runtime_snapshots/oscbf-runtime-20260923T151524.541630Z-d48fc5cfef8c4655b76d4e8a7a43f247.json#kernel_step_sequence
- 总样本：2196；终止原因：interrupted
- 样本记录 SHA-256：743195fc7d079e2803e2024a19f27f3f7ab0ac7ab96948278b8522ac487f6454
- 声明范围：EvaluationScope(total_length_m=1.8167634936816308, start_m=0.0, end_m=1.8167634936816308)；初始/最终投影弧长：0 / 0.185991 m
- 绝对弧长比：0.102375；本次区间覆盖比：0.102375
- 本次区间完成：False；整条路径覆盖：False；全部所需判据下整条路径验证：False
- 采样耗时：22.0499 s；计算 deadline：20 ms；超期率：0
- 未采集边界：filtered_command, simulated_state, real_feedback

## 误差及诊断统计

统计按样本等权；部分有效样本仍可供诊断，缺失/无效样本阻止对应指标通过。

| 指标（单位见定义） | 有效/缺失/无效 | 均值 | RMS | p95 | 最小 | 最大 |
|---|---|---|---|---|---|---|
| actual_tangent_speed_m_s | 2196/0/0 | 0.0343889 | 0.0581912 | 0.145999 | 0.00836416 | 0.150534 |
| cross_track_m | 2196/0/0 | 0.000113984 | 0.000532097 | 0.000144537 | 6.87027e-06 | 0.00557177 |
| delta_slack | 2196/0/0 | 5.33204e-11 | 1.26918e-10 | 3.54418e-10 | 6.32151e-13 | 4.25248e-10 |
| feedrate_m_s | 2196/0/0 | 0.061413 | 0.105065 | 0.266187 | 0.0148048 | 0.269853 |
| legacy_orientation_error | 2196/0/0 | 0.00697154 | 0.0114846 | 0.0303318 | 0.000205356 | 0.0355995 |
| obstacle_clearance_m | 0/2196/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| obstacle_margin_m | 0/2196/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| online_cross_track_m | 2196/0/0 | 0.000167266 | 0.000714642 | 0.000317066 | 1.76679e-06 | 0.00691498 |
| pos_error_m | 2196/0/0 | 0.00999201 | 0.0100138 | 0.0100278 | 0.000738129 | 0.0133383 |
| qp_primal_residual | 2196/0/0 | 0 | 0 | 0 | 0 | 0 |
| source_time_s | 2196/0/0 | 2.72026 | 2.79235 | 3.22357 | 0.298154 | 3.25306 |
| step_latency_ms | 2196/0/0 | 7.83223 | 7.84614 | 8.60282 | 6.46539 | 13.3699 |
| tool_axis_error_rad | 2196/0/0 | 0.00697214 | 0.0114862 | 0.0303365 | 0.000205356 | 0.0356071 |

## 逐项判据与来源

| 指标 | 类别 | 阈值/单位 | 状态 | 测量值 | 结论 | 来源/原因 |
|---|---|---|---|---|---|---|
| cross_track_m.rms | task | <= 0.00015 m | accepted | 0.000532097 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.p95 | task | <= 0.0005 m | accepted | 0.000144537 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.maximum | task | <= 0.002 m | accepted | 0.00557177 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| tool_axis_error_rad.rms | task | <= 0.000872665 rad | accepted | 0.0114862 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| tool_axis_error_rad.maximum | task | <= 0.00872665 rad | accepted | 0.0356071 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| qp_success_rate | task | >= 0.999 1 | accepted | 1 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| obstacle_clearance_nonnegative | safety | >= 0 m | accepted | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; nonnegative clearance alone does not prove non-overlap; required samples missing or invalid |
| obstacle_clearance_m.minimum | safety | >= 0.03 m | provisional | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; geometry/scope pending #8/#18; threshold not accepted for this scope |
| deadline_miss_rate | timing | <= 0.01 1 | provisional | 0 | 证据不足 | GitHub #14 resolution 2026-09-04; deadline must match current measured boundary/config; threshold not accepted for this scope |

## 在线门控与约束

- QP：success=1，失败=0，缺失/无效=0
- 准入：{'unmeasured': 2196}；重叠：{'unmeasured': 2196}
- 状态事件：{}；限制因素：{0: 414, 2: 1782}
- 几何裕度、原始约束残差和松弛分别报告；不同量纲不相加。

- legacy_orientation_error 是旧控制误差诊断；delta_slack/qp_primal_residual 是跨类求解诊断，不能当作米解释，物理量请使用逐类数据。

```json
{
  "esdf.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 2196,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2196
  },
  "esdf.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 2196,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2196
  },
  "joint_angular.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "rad/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2196,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_angular.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "rad",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2196,
      "missing": 0,
      "invalid": 0,
      "mean": 0.030000525990543564,
      "rms": 0.04926351876877841,
      "p95": 0.13552225277799274,
      "minimum": 0.010385610189177283,
      "maximum": 0.16206901274221286
    },
    "inactive_count": 0
  },
  "joint_linear.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2196,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_linear.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2196,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0169637163380799,
      "rms": 0.03625360050135679,
      "p95": 0.10304815140199013,
      "minimum": 0.0017633987342368183,
      "maximum": 0.1089111407694164
    },
    "inactive_count": 0
  },
  "obstacle.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 2196,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2196
  },
  "obstacle.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 2196,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2196
  },
  "self_collision.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2196,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "self_collision.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2196,
      "missing": 0,
      "invalid": 0,
      "mean": 0.26027334674497127,
      "rms": 0.26049367561602194,
      "p95": 0.27705932115658266,
      "minimum": 0.2392260942148357,
      "maximum": 0.2789726443628541
    },
    "inactive_count": 0
  },
  "singularity.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "model_manipulability/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2196,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "singularity.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "model_manipulability",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2196,
      "missing": 0,
      "invalid": 0,
      "mean": 0.7466128437029343,
      "rms": 0.7470674645223774,
      "p95": 0.7928075080906258,
      "minimum": 0.7078161147540714,
      "maximum": 0.7981899540529699
    },
    "inactive_count": 0
  }
}
```

## 数据与范围限制

- declared interval has not been validly completed

# 路径跟踪评价报告

- 任务质量：不通过；在线门控：证据不足
- 全部所需判据：不通过（仅限下述证据范围，不授予实机准入）
- 证据：model；测量边界：kernel_candidate
- 运行：oscbf-runtime-20260923T151347.513388Z-63cd11816e364f0a8a804d2a195c6b01；工况：configured path; obstacles=False
- 测量定义：post-integration model q_next and command reference; QP rows at solve input; before command filter; no execution feedback；时间基准：perf_counter sample start; step_once includes kernel and host diagnostics
- 模型 / 配置 / 路径 / 数据身份：/home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151233Z-60365/state-5-command-20/runtime_snapshots/oscbf-runtime-20260923T151347.513388Z-63cd11816e364f0a8a804d2a195c6b01.json#software / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151233Z-60365/state-5-command-20/runtime_snapshots/oscbf-runtime-20260923T151347.513388Z-63cd11816e364f0a8a804d2a195c6b01.json / sha256:a4aa60dbde62d798d37266882556a6103ba401d1f3e449b6eb9d7cc1641bfc91 / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151233Z-60365/state-5-command-20/runtime_snapshots/oscbf-runtime-20260923T151347.513388Z-63cd11816e364f0a8a804d2a195c6b01.json#kernel_step_sequence
- 总样本：1962；终止原因：interrupted
- 样本记录 SHA-256：cf6c284fbbcb30efdda2eb9ccf6c665bc0e5fc9d080496486ebbbd835a0a5542
- 声明范围：EvaluationScope(total_length_m=1.8167634936816308, start_m=0.0, end_m=1.8167634936816308)；初始/最终投影弧长：0 / 0.182076 m
- 绝对弧长比：0.10022；本次区间覆盖比：0.10022
- 本次区间完成：False；整条路径覆盖：False；全部所需判据下整条路径验证：False
- 采样耗时：22.0698 s；计算 deadline：20 ms；超期率：0
- 未采集边界：filtered_command, simulated_state, real_feedback

## 误差及诊断统计

统计按样本等权；部分有效样本仍可供诊断，缺失/无效样本阻止对应指标通过。

| 指标（单位见定义） | 有效/缺失/无效 | 均值 | RMS | p95 | 最小 | 最大 |
|---|---|---|---|---|---|---|
| actual_tangent_speed_m_s | 1962/0/0 | 0.03676 | 0.0607781 | 0.14628 | 0.00949373 | 0.151045 |
| cross_track_m | 1962/0/0 | 0.000120215 | 0.000556428 | 0.000144596 | 1.01525e-05 | 0.00561992 |
| delta_slack | 1962/0/0 | 5.74642e-11 | 1.3247e-10 | 3.68144e-10 | 6.09085e-13 | 4.25553e-10 |
| feedrate_m_s | 1962/0/0 | 0.0656559 | 0.109766 | 0.266606 | 0.0170727 | 0.269863 |
| legacy_orientation_error | 1962/0/0 | 0.0073525 | 0.0119744 | 0.0309367 | 0.000128635 | 0.0364241 |
| obstacle_clearance_m | 0/1962/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| obstacle_margin_m | 0/1962/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| online_cross_track_m | 1962/0/0 | 0.000174383 | 0.000740741 | 0.000318736 | 1.76679e-06 | 0.00692111 |
| pos_error_m | 1962/0/0 | 0.00998362 | 0.0100052 | 0.0100612 | 0.000738129 | 0.0134518 |
| qp_primal_residual | 1962/0/0 | 0 | 0 | 0 | 0 | 0 |
| source_time_s | 1962/0/0 | 2.67133 | 2.74746 | 3.17519 | 0.298154 | 3.20405 |
| step_latency_ms | 1962/0/0 | 8.39521 | 8.41964 | 9.37586 | 6.55402 | 13.5675 |
| tool_axis_error_rad | 1962/0/0 | 0.00735315 | 0.0119761 | 0.0309417 | 0.000128635 | 0.0364322 |

## 逐项判据与来源

| 指标 | 类别 | 阈值/单位 | 状态 | 测量值 | 结论 | 来源/原因 |
|---|---|---|---|---|---|---|
| cross_track_m.rms | task | <= 0.00015 m | accepted | 0.000556428 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.p95 | task | <= 0.0005 m | accepted | 0.000144596 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.maximum | task | <= 0.002 m | accepted | 0.00561992 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| tool_axis_error_rad.rms | task | <= 0.000872665 rad | accepted | 0.0119761 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| tool_axis_error_rad.maximum | task | <= 0.00872665 rad | accepted | 0.0364322 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| qp_success_rate | task | >= 0.999 1 | accepted | 1 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| obstacle_clearance_nonnegative | safety | >= 0 m | accepted | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; nonnegative clearance alone does not prove non-overlap; required samples missing or invalid |
| obstacle_clearance_m.minimum | safety | >= 0.03 m | provisional | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; geometry/scope pending #8/#18; threshold not accepted for this scope |
| deadline_miss_rate | timing | <= 0.01 1 | provisional | 0 | 证据不足 | GitHub #14 resolution 2026-09-04; deadline must match current measured boundary/config; threshold not accepted for this scope |

## 在线门控与约束

- QP：success=1，失败=0，缺失/无效=0
- 准入：{'unmeasured': 1962}；重叠：{'unmeasured': 1962}
- 状态事件：{}；限制因素：{0: 405, 2: 1557}
- 几何裕度、原始约束残差和松弛分别报告；不同量纲不相加。

- legacy_orientation_error 是旧控制误差诊断；delta_slack/qp_primal_residual 是跨类求解诊断，不能当作米解释，物理量请使用逐类数据。

```json
{
  "esdf.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 1962,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 1962
  },
  "esdf.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 1962,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 1962
  },
  "joint_angular.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "rad/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 1962,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_angular.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "rad",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 1962,
      "missing": 0,
      "invalid": 0,
      "mean": 0.031272034757734206,
      "rms": 0.051127613455927305,
      "p95": 0.13718946730547882,
      "minimum": 0.01038293625653842,
      "maximum": 0.16200993122857588
    },
    "inactive_count": 0
  },
  "joint_linear.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 1962,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_linear.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 1962,
      "missing": 0,
      "invalid": 0,
      "mean": 0.01840347728720906,
      "rms": 0.03798582591713263,
      "p95": 0.10396737512720773,
      "minimum": 0.001762902153802712,
      "maximum": 0.1089111407694164
    },
    "inactive_count": 0
  },
  "obstacle.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 1962,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 1962
  },
  "obstacle.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 1962,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 1962
  },
  "self_collision.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 1962,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "self_collision.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 1962,
      "missing": 0,
      "invalid": 0,
      "mean": 0.2586730059007452,
      "rms": 0.25885931399636536,
      "p95": 0.273860713586094,
      "minimum": 0.2392260942148357,
      "maximum": 0.27575700895610267
    },
    "inactive_count": 0
  },
  "singularity.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "model_manipulability/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 1962,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "singularity.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "model_manipulability",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 1962,
      "missing": 0,
      "invalid": 0,
      "mean": 0.7421794914183399,
      "rms": 0.7425309072856487,
      "p95": 0.7830163579642888,
      "minimum": 0.7077283509921295,
      "maximum": 0.7888662851617663
    },
    "inactive_count": 0
  }
}
```

## 数据与范围限制

- declared interval has not been validly completed

# 路径跟踪评价报告

- 任务质量：不通过；在线门控：证据不足
- 全部所需判据：不通过（仅限下述证据范围，不授予实机准入）
- 证据：model；测量边界：kernel_candidate
- 运行：oscbf-runtime-20260923T151936.031065Z-7d5c3d7845e74885a9c1259d293a28b7；工况：configured path; obstacles=False
- 测量定义：post-integration model q_next and command reference; QP rows at solve input; before command filter; no execution feedback；时间基准：perf_counter sample start; step_once includes kernel and host diagnostics
- 模型 / 配置 / 路径 / 数据身份：/home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151912Z-63112/state-20-command-5/runtime_snapshots/oscbf-runtime-20260923T151936.031065Z-7d5c3d7845e74885a9c1259d293a28b7.json#software / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151912Z-63112/state-20-command-5/runtime_snapshots/oscbf-runtime-20260923T151936.031065Z-7d5c3d7845e74885a9c1259d293a28b7.json / sha256:a4aa60dbde62d798d37266882556a6103ba401d1f3e449b6eb9d7cc1641bfc91 / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151912Z-63112/state-20-command-5/runtime_snapshots/oscbf-runtime-20260923T151936.031065Z-7d5c3d7845e74885a9c1259d293a28b7.json#kernel_step_sequence
- 总样本：2188；终止原因：interrupted
- 样本记录 SHA-256：60d5319effaa196bac273754ec33a48e8b46821d06e24b44977bbf03b6d73ae0
- 声明范围：EvaluationScope(total_length_m=1.8167634936816308, start_m=0.0, end_m=1.8167634936816308)；初始/最终投影弧长：0 / 0.185863 m
- 绝对弧长比：0.102304；本次区间覆盖比：0.102304
- 本次区间完成：False；整条路径覆盖：False；全部所需判据下整条路径验证：False
- 采样耗时：22.0499 s；计算 deadline：20 ms；超期率：0
- 未采集边界：filtered_command, simulated_state, real_feedback

## 误差及诊断统计

统计按样本等权；部分有效样本仍可供诊断，缺失/无效样本阻止对应指标通过。

| 指标（单位见定义） | 有效/缺失/无效 | 均值 | RMS | p95 | 最小 | 最大 |
|---|---|---|---|---|---|---|
| actual_tangent_speed_m_s | 2188/0/0 | 0.0345314 | 0.0583316 | 0.146046 | 0.0085548 | 0.150525 |
| cross_track_m | 2188/0/0 | 0.000114313 | 0.000533451 | 0.000144534 | 7.59805e-06 | 0.00556778 |
| delta_slack | 2188/0/0 | 5.34341e-11 | 1.27118e-10 | 3.54514e-10 | 6.54915e-13 | 4.25298e-10 |
| feedrate_m_s | 2188/0/0 | 0.0616739 | 0.105329 | 0.26618 | 0.015203 | 0.269852 |
| legacy_orientation_error | 2188/0/0 | 0.00698599 | 0.0115026 | 0.0303292 | 0.000205356 | 0.0355801 |
| obstacle_clearance_m | 0/2188/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| obstacle_margin_m | 0/2188/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| online_cross_track_m | 2188/0/0 | 0.000168211 | 0.000716995 | 0.000317749 | 1.76679e-06 | 0.00691563 |
| pos_error_m | 2188/0/0 | 0.00999211 | 0.010014 | 0.010031 | 0.000738129 | 0.0133463 |
| qp_primal_residual | 2188/0/0 | 0 | 0 | 0 | 0 | 0 |
| source_time_s | 2188/0/0 | 2.71681 | 2.78952 | 3.2217 | 0.298154 | 3.25144 |
| step_latency_ms | 2188/0/0 | 7.82083 | 7.83563 | 8.57628 | 6.2132 | 14.6515 |
| tool_axis_error_rad | 2188/0/0 | 0.00698659 | 0.0115042 | 0.0303338 | 0.000205356 | 0.0355876 |

## 逐项判据与来源

| 指标 | 类别 | 阈值/单位 | 状态 | 测量值 | 结论 | 来源/原因 |
|---|---|---|---|---|---|---|
| cross_track_m.rms | task | <= 0.00015 m | accepted | 0.000533451 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.p95 | task | <= 0.0005 m | accepted | 0.000144534 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.maximum | task | <= 0.002 m | accepted | 0.00556778 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| tool_axis_error_rad.rms | task | <= 0.000872665 rad | accepted | 0.0115042 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| tool_axis_error_rad.maximum | task | <= 0.00872665 rad | accepted | 0.0355876 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| qp_success_rate | task | >= 0.999 1 | accepted | 1 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| obstacle_clearance_nonnegative | safety | >= 0 m | accepted | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; nonnegative clearance alone does not prove non-overlap; required samples missing or invalid |
| obstacle_clearance_m.minimum | safety | >= 0.03 m | provisional | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; geometry/scope pending #8/#18; threshold not accepted for this scope |
| deadline_miss_rate | timing | <= 0.01 1 | provisional | 0 | 证据不足 | GitHub #14 resolution 2026-09-04; deadline must match current measured boundary/config; threshold not accepted for this scope |

## 在线门控与约束

- QP：success=1，失败=0，缺失/无效=0
- 准入：{'unmeasured': 2188}；重叠：{'unmeasured': 2188}
- 状态事件：{}；限制因素：{0: 415, 2: 1773}
- 几何裕度、原始约束残差和松弛分别报告；不同量纲不相加。

- legacy_orientation_error 是旧控制误差诊断；delta_slack/qp_primal_residual 是跨类求解诊断，不能当作米解释，物理量请使用逐类数据。

```json
{
  "esdf.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 2188,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2188
  },
  "esdf.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 2188,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2188
  },
  "joint_angular.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "rad/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2188,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_angular.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "rad",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2188,
      "missing": 0,
      "invalid": 0,
      "mean": 0.030054741897029093,
      "rms": 0.04933203700160315,
      "p95": 0.13570408804696427,
      "minimum": 0.010384560969366472,
      "maximum": 0.16191716274141643
    },
    "inactive_count": 0
  },
  "joint_linear.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2188,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_linear.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2188,
      "missing": 0,
      "invalid": 0,
      "mean": 0.017086704131520882,
      "rms": 0.03642111280754952,
      "p95": 0.10323255198891927,
      "minimum": 0.0017631384796967884,
      "maximum": 0.1089111407694164
    },
    "inactive_count": 0
  },
  "obstacle.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 2188,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2188
  },
  "obstacle.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 2188,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2188
  },
  "self_collision.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2188,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "self_collision.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2188,
      "missing": 0,
      "invalid": 0,
      "mean": 0.260191327757173,
      "rms": 0.2604107521616541,
      "p95": 0.27693488495643115,
      "minimum": 0.2392260942148357,
      "maximum": 0.2788813202062369
    },
    "inactive_count": 0
  },
  "singularity.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "model_manipulability/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2188,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "singularity.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "model_manipulability",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2188,
      "missing": 0,
      "invalid": 0,
      "mean": 0.7464061100485396,
      "rms": 0.7468570742814118,
      "p95": 0.7924382230059649,
      "minimum": 0.70778329067941,
      "maximum": 0.7979664833580222
    },
    "inactive_count": 0
  }
}
```

## 数据与范围限制

- declared interval has not been validly completed

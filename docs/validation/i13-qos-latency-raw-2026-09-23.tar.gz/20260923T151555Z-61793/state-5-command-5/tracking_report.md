# 路径跟踪评价报告

- 任务质量：不通过；在线门控：证据不足
- 全部所需判据：不通过（仅限下述证据范围，不授予实机准入）
- 证据：model；测量边界：kernel_candidate
- 运行：oscbf-runtime-20260923T151844.279242Z-3f8aeedabe86445f9978ef963aa71720；工况：configured path; obstacles=False
- 测量定义：post-integration model q_next and command reference; QP rows at solve input; before command filter; no execution feedback；时间基准：perf_counter sample start; step_once includes kernel and host diagnostics
- 模型 / 配置 / 路径 / 数据身份：/home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151555Z-61793/state-5-command-5/runtime_snapshots/oscbf-runtime-20260923T151844.279242Z-3f8aeedabe86445f9978ef963aa71720.json#software / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151555Z-61793/state-5-command-5/runtime_snapshots/oscbf-runtime-20260923T151844.279242Z-3f8aeedabe86445f9978ef963aa71720.json / sha256:a4aa60dbde62d798d37266882556a6103ba401d1f3e449b6eb9d7cc1641bfc91 / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151555Z-61793/state-5-command-5/runtime_snapshots/oscbf-runtime-20260923T151844.279242Z-3f8aeedabe86445f9978ef963aa71720.json#kernel_step_sequence
- 总样本：2154；终止原因：interrupted
- 样本记录 SHA-256：2c1fbcccb63a3ebde08e681887f3d99a8b8f461cc7ba3c2dc5a3c8731e31ca1f
- 声明范围：EvaluationScope(total_length_m=1.8167634936816308, start_m=0.0, end_m=1.8167634936816308)；初始/最终投影弧长：0 / 0.185391 m
- 绝对弧长比：0.102045；本次区间覆盖比：0.102045
- 本次区间完成：False；整条路径覆盖：False；全部所需判据下整条路径验证：False
- 采样耗时：22.0798 s；计算 deadline：20 ms；超期率：0
- 未采集边界：filtered_command, simulated_state, real_feedback

## 误差及诊断统计

统计按样本等权；部分有效样本仍可供诊断，缺失/无效样本阻止对应指标通过。

| 指标（单位见定义） | 有效/缺失/无效 | 均值 | RMS | p95 | 最小 | 最大 |
|---|---|---|---|---|---|---|
| actual_tangent_speed_m_s | 2154/0/0 | 0.0348167 | 0.0586409 | 0.146054 | 0.0089585 | 0.150526 |
| cross_track_m | 2154/0/0 | 0.000115488 | 0.000537615 | 0.000145015 | 7.59805e-06 | 0.00556778 |
| delta_slack | 2154/0/0 | 5.41382e-11 | 1.28054e-10 | 3.56336e-10 | 6.53654e-13 | 4.25312e-10 |
| feedrate_m_s | 2154/0/0 | 0.0621902 | 0.105897 | 0.266275 | 0.0160257 | 0.269853 |
| legacy_orientation_error | 2154/0/0 | 0.00702982 | 0.0115508 | 0.0303311 | 0.000205356 | 0.0358053 |
| obstacle_clearance_m | 0/2154/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| obstacle_margin_m | 0/2154/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| online_cross_track_m | 2154/0/0 | 0.000170111 | 0.000722576 | 0.000317326 | 1.76679e-06 | 0.00691563 |
| pos_error_m | 2154/0/0 | 0.00999193 | 0.0100142 | 0.0100502 | 0.000738129 | 0.0133463 |
| qp_primal_residual | 2154/0/0 | 0 | 0 | 0 | 0 | 0 |
| source_time_s | 2154/0/0 | 2.71003 | 2.78333 | 3.21579 | 0.298154 | 3.24551 |
| step_latency_ms | 2154/0/0 | 7.9616 | 7.98157 | 8.87397 | 6.42412 | 13.7005 |
| tool_axis_error_rad | 2154/0/0 | 0.00703043 | 0.0115523 | 0.0303357 | 0.000205356 | 0.035813 |

## 逐项判据与来源

| 指标 | 类别 | 阈值/单位 | 状态 | 测量值 | 结论 | 来源/原因 |
|---|---|---|---|---|---|---|
| cross_track_m.rms | task | <= 0.00015 m | accepted | 0.000537615 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.p95 | task | <= 0.0005 m | accepted | 0.000145015 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.maximum | task | <= 0.002 m | accepted | 0.00556778 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| tool_axis_error_rad.rms | task | <= 0.000872665 rad | accepted | 0.0115523 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| tool_axis_error_rad.maximum | task | <= 0.00872665 rad | accepted | 0.035813 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| qp_success_rate | task | >= 0.999 1 | accepted | 1 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| obstacle_clearance_nonnegative | safety | >= 0 m | accepted | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; nonnegative clearance alone does not prove non-overlap; required samples missing or invalid |
| obstacle_clearance_m.minimum | safety | >= 0.03 m | provisional | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; geometry/scope pending #8/#18; threshold not accepted for this scope |
| deadline_miss_rate | timing | <= 0.01 1 | provisional | 0 | 证据不足 | GitHub #14 resolution 2026-09-04; deadline must match current measured boundary/config; threshold not accepted for this scope |

## 在线门控与约束

- QP：success=1，失败=0，缺失/无效=0
- 准入：{'unmeasured': 2154}；重叠：{'unmeasured': 2154}
- 状态事件：{}；限制因素：{0: 413, 2: 1741}
- 几何裕度、原始约束残差和松弛分别报告；不同量纲不相加。

- legacy_orientation_error 是旧控制误差诊断；delta_slack/qp_primal_residual 是跨类求解诊断，不能当作米解释，物理量请使用逐类数据。

```json
{
  "esdf.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 2154,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2154
  },
  "esdf.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 2154,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2154
  },
  "joint_angular.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "rad/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2154,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_angular.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "rad",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2154,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0302288678080919,
      "rms": 0.04959980004435787,
      "p95": 0.13604771984918498,
      "minimum": 0.01038454194306838,
      "maximum": 0.16212463904191599
    },
    "inactive_count": 0
  },
  "joint_linear.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2154,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_linear.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2154,
      "missing": 0,
      "invalid": 0,
      "mean": 0.01729031599516978,
      "rms": 0.036679092743495866,
      "p95": 0.10339585537700156,
      "minimum": 0.0017633701247606968,
      "maximum": 0.1089111407694164
    },
    "inactive_count": 0
  },
  "obstacle.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 2154,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2154
  },
  "obstacle.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 2154,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2154
  },
  "self_collision.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2154,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "self_collision.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2154,
      "missing": 0,
      "invalid": 0,
      "mean": 0.2599713446617061,
      "rms": 0.2601863432246582,
      "p95": 0.2765396245928477,
      "minimum": 0.2392260942148357,
      "maximum": 0.27851535088605267
    },
    "inactive_count": 0
  },
  "singularity.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "model_manipulability/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2154,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "singularity.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "model_manipulability",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2154,
      "missing": 0,
      "invalid": 0,
      "mean": 0.7458093321481281,
      "rms": 0.7462467578011918,
      "p95": 0.7912557621495189,
      "minimum": 0.7077970422735167,
      "maximum": 0.7970066336052227
    },
    "inactive_count": 0
  }
}
```

## 数据与范围限制

- declared interval has not been validly completed

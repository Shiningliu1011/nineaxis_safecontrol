# M10 oscbf_controller 性能证据

- 控制频率: 100.0 Hz
- 步数: 2195
- `path_tracking_step` 延迟 p50: 7.755 ms
- `path_tracking_step` 延迟 p95: 8.518 ms（01B 口径: 50Hz 预算 = 20 ms）
- 单步最大: 10.497 ms
- 超预算(>20ms)步数: 0 (miss rate = 0.00%, 上限 1%)
- QP 失败次数: 0

# 路径跟踪评价报告

- 任务质量：不通过；在线门控：证据不足
- 全部所需判据：不通过（仅限下述证据范围，不授予实机准入）
- 证据：model；测量边界：kernel_candidate
- 运行：oscbf-runtime-20260923T151619.401955Z-3f364b53e82e44dc8b74cfb30e3d7540；工况：configured path; obstacles=False
- 测量定义：post-integration model q_next and command reference; QP rows at solve input; before command filter; no execution feedback；时间基准：perf_counter sample start; step_once includes kernel and host diagnostics
- 模型 / 配置 / 路径 / 数据身份：/home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151555Z-61793/state-20-command-20/runtime_snapshots/oscbf-runtime-20260923T151619.401955Z-3f364b53e82e44dc8b74cfb30e3d7540.json#software / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151555Z-61793/state-20-command-20/runtime_snapshots/oscbf-runtime-20260923T151619.401955Z-3f364b53e82e44dc8b74cfb30e3d7540.json / sha256:a4aa60dbde62d798d37266882556a6103ba401d1f3e449b6eb9d7cc1641bfc91 / /home/lsn/robot/robot_safecontrol/output/i13-qos-latency/20260923T151555Z-61793/state-20-command-20/runtime_snapshots/oscbf-runtime-20260923T151619.401955Z-3f364b53e82e44dc8b74cfb30e3d7540.json#kernel_step_sequence
- 总样本：2177；终止原因：interrupted
- 样本记录 SHA-256：7d93b354cb7c422f004ebed32b17f83045ea9795664984ae9aa8535390abefc9
- 声明范围：EvaluationScope(total_length_m=1.8167634936816308, start_m=0.0, end_m=1.8167634936816308)；初始/最终投影弧长：0 / 0.186189 m
- 绝对弧长比：0.102484；本次区间覆盖比：0.102484
- 本次区间完成：False；整条路径覆盖：False；全部所需判据下整条路径验证：False
- 采样耗时：22.0499 s；计算 deadline：20 ms；超期率：0
- 未采集边界：filtered_command, simulated_state, real_feedback

## 误差及诊断统计

统计按样本等权；部分有效样本仍可供诊断，缺失/无效样本阻止对应指标通过。

| 指标（单位见定义） | 有效/缺失/无效 | 均值 | RMS | p95 | 最小 | 最大 |
|---|---|---|---|---|---|---|
| actual_tangent_speed_m_s | 2177/0/0 | 0.0341595 | 0.057983 | 0.145892 | 0.00806872 | 0.150927 |
| cross_track_m | 2177/0/0 | 0.000110147 | 0.000523337 | 0.000142221 | 1.33179e-05 | 0.00562074 |
| delta_slack | 2177/0/0 | 5.28416e-11 | 1.26391e-10 | 3.53832e-10 | 6.41953e-13 | 4.25932e-10 |
| feedrate_m_s | 2177/0/0 | 0.0610081 | 0.104705 | 0.266125 | 0.0142469 | 0.269958 |
| legacy_orientation_error | 2177/0/0 | 0.0069413 | 0.0114567 | 0.0302807 | 0.000205356 | 0.035684 |
| obstacle_clearance_m | 0/2177/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| obstacle_margin_m | 0/2177/0 | 未测 | 未测 | 未测 | 未测 | 未测 |
| online_cross_track_m | 2177/0/0 | 0.00015649 | 0.000694501 | 0.000308902 | 1.76679e-06 | 0.00696081 |
| pos_error_m | 2177/0/0 | 0.00997734 | 0.00999847 | 0.0100142 | 0.000738129 | 0.0133235 |
| qp_primal_residual | 2177/0/0 | 0 | 0 | 0 | 0 | 0 |
| source_time_s | 2177/0/0 | 2.72757 | 2.79801 | 3.22642 | 0.298154 | 3.25555 |
| step_latency_ms | 2177/0/0 | 7.89154 | 7.90749 | 8.71255 | 6.04434 | 12.9946 |
| tool_axis_error_rad | 2177/0/0 | 0.0069419 | 0.0114582 | 0.0302854 | 0.000205356 | 0.0356915 |

## 逐项判据与来源

| 指标 | 类别 | 阈值/单位 | 状态 | 测量值 | 结论 | 来源/原因 |
|---|---|---|---|---|---|---|
| cross_track_m.rms | task | <= 0.00015 m | accepted | 0.000523337 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.p95 | task | <= 0.0005 m | accepted | 0.000142221 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| cross_track_m.maximum | task | <= 0.002 m | accepted | 0.00562074 | 不通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| tool_axis_error_rad.rms | task | <= 0.000872665 rad | accepted | 0.0114582 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| tool_axis_error_rad.maximum | task | <= 0.00872665 rad | accepted | 0.0356915 | 不通过 | GitHub #14 resolution 2026-09-04; OFF-15 user decision: true axis angle 2026-09-12; complete samples compared with sourced threshold |
| qp_success_rate | task | >= 0.999 1 | accepted | 1 | 通过 | GitHub #14 resolution 2026-09-04; complete samples compared with sourced threshold |
| obstacle_clearance_nonnegative | safety | >= 0 m | accepted | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; nonnegative clearance alone does not prove non-overlap; required samples missing or invalid |
| obstacle_clearance_m.minimum | safety | >= 0.03 m | provisional | 未测 | 证据不足 | GitHub #14 resolution 2026-09-04; geometry/scope pending #8/#18; threshold not accepted for this scope |
| deadline_miss_rate | timing | <= 0.01 1 | provisional | 0 | 证据不足 | GitHub #14 resolution 2026-09-04; deadline must match current measured boundary/config; threshold not accepted for this scope |

## 在线门控与约束

- QP：success=1，失败=0，缺失/无效=0
- 准入：{'unmeasured': 2177}；重叠：{'unmeasured': 2177}
- 状态事件：{}；限制因素：{0: 403, 2: 1774}
- 几何裕度、原始约束残差和松弛分别报告；不同量纲不相加。

- legacy_orientation_error 是旧控制误差诊断；delta_slack/qp_primal_residual 是跨类求解诊断，不能当作米解释，物理量请使用逐类数据。

```json
{
  "esdf.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 2177,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2177
  },
  "esdf.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 2177,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2177
  },
  "joint_angular.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "rad/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2177,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_angular.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "rad",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2177,
      "missing": 0,
      "invalid": 0,
      "mean": 0.02975537633044024,
      "rms": 0.048904827734667054,
      "p95": 0.13491986712867743,
      "minimum": 0.01038124596146118,
      "maximum": 0.1617225416128103
    },
    "inactive_count": 0
  },
  "joint_linear.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2177,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "joint_linear.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2177,
      "missing": 0,
      "invalid": 0,
      "mean": 0.016646300147840982,
      "rms": 0.03578815018485608,
      "p95": 0.1022903809510555,
      "minimum": 0.0017551948702577789,
      "maximum": 0.1089111407694164
    },
    "inactive_count": 0
  },
  "obstacle.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 0,
      "missing": 2177,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2177
  },
  "obstacle.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 0,
      "missing": 2177,
      "invalid": 0,
      "mean": null,
      "rms": null,
      "p95": null,
      "minimum": null,
      "maximum": null
    },
    "inactive_count": 2177
  },
  "self_collision.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "m/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2177,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "self_collision.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "m",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2177,
      "missing": 0,
      "invalid": 0,
      "mean": 0.2604078349114708,
      "rms": 0.26062916041007567,
      "p95": 0.2772481411781256,
      "minimum": 0.2392260942148357,
      "maximum": 0.27911522387083665
    },
    "inactive_count": 0
  },
  "singularity.residual": {
    "quantity": "max_positive_unrelaxed_G_u_candidate_minus_h",
    "unit": "model_manipulability/s",
    "source": "QP solve state; dynamic-corrected RHS; before health gate/integration/filter",
    "statistics": {
      "count": 2177,
      "missing": 0,
      "invalid": 0,
      "mean": 0.0,
      "rms": 0.0,
      "p95": 0.0,
      "minimum": 0.0,
      "maximum": 0.0
    },
    "inactive_count": 0
  },
  "singularity.static_margin": {
    "quantity": "static_cbf_rhs_div_baseline_alpha",
    "unit": "model_manipulability",
    "source": "QP solve state; static RHS before dynamic correction; model metric, not physical clearance",
    "statistics": {
      "count": 2177,
      "missing": 0,
      "invalid": 0,
      "mean": 0.7468027139773367,
      "rms": 0.7472653344795471,
      "p95": 0.793313142343839,
      "minimum": 0.7076020772690935,
      "maximum": 0.7985205168750309
    },
    "inactive_count": 0
  }
}
```

## 数据与范围限制

- declared interval has not been validly completed
